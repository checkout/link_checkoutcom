'use strict';

/**
 * API includes.
 */
var Transaction = require('dw/system/Transaction');
var OrderMgr = require('dw/order/OrderMgr');
var Logger = require('dw/system/Logger');
var PaymentMgr = require('dw/order/PaymentMgr');
var SystemObjectMgr = require('dw/object/SystemObjectMgr');
var Resource = require('dw/web/Resource');
var Site = require('dw/system/Site');
var Locale = require('dw/util/Locale');

// Card Currency Config
var ckoCurrencyConfig = require('*/cartridge/config/ckoCurrencyConfig');

/* Sensitive Data Helper */
var sensitiveDataHelper = require('*/cartridge/scripts/helpers/sensitiveDataHelper.js');

/** Checkout Data Configuration File **/
var constants = require('*/cartridge/config/constants');

/**
 * Module ckoHelper.
 */
var ckoHelper = {
    /**
     * CKO Response object.
     * @param {Object} data Format a gateway response
     * @returns {string} The response JSON string
     */
    ckoResponse: function(data) {
        response.setBuffered(false); // eslint-disable-line
        response.setContentType('text/plain'); // eslint-disable-line
        var out = response.writer; // eslint-disable-line

        return out.println(JSON.stringify(data)); // eslint-disable-line
    },

    /**
     * Get the required value for each mode.
     * @param {string} sandboxValue The sandbox value
     * @param {string} liveValue The live value
     * @returns {string} The APM mode
     */
    getAppModeValue: function(sandboxValue, liveValue) {
        var appMode = this.getValue(constants.CKO_MODE);
        if (appMode === 'sandbox') {
            return sandboxValue;
        }
        return liveValue;
    },

    /**
     * Get user language
     * @returns {string} The user language.
     */
    getLanguage: function() {
        // eslint-disable-next-line
        return request.locale.replace('_', '-');
    },

    /**
     * Get Site Name
     * @returns {string} The site name.
     */
    getSiteName: function() {
        return Site.getCurrent().name;
    },

    /**
     * Get site Hostname
     * @returns {string} The site host name.
     */
    getSiteHostName: function() {
        return Site.getCurrent().httpHostName;
    },

    /**
     * Check if the gateway response is valid
     * @returns {boolean} The gateway response status.
     */
    isValidResponse: function() {
        // eslint-disable-next-line
        var requestKey = request.httpHeaders.get('authorization');
        var privateSharedKey = this.getAccountKeys().privateSharedKey;

        // No key configured authenticates nothing (a request without the header
        // would otherwise match an unset preference)
        if (!privateSharedKey || !requestKey) {
            return false;
        }

        return this.safeEquals(String(requestKey), String(privateSharedKey));
    },

    /**
     * Compare two strings in constant time (for their length).
     * @param {string} a The first string
     * @param {string} b The second string
     * @returns {boolean} True when equal
     */
    safeEquals: function(a, b) {
        if (a.length !== b.length) {
            return false;
        }

        var diff = 0;

        for (var i = 0; i < a.length; i += 1) {
            diff |= a.charCodeAt(i) ^ b.charCodeAt(i); // eslint-disable-line no-bitwise
        }

        return diff === 0;
    },

    /**
     * Get value from custom preferences
     * @param {string} field The field id
     * @returns {string} The field value
     */
    getValue: function(field) {
        return Site.getCurrent().getCustomPreferenceValue(field);
    },

    /**
     * Change the first letter of a string to upper case.
     * @param {string} data The string to process
     * @returns {string} The processed string
     */
    upperCaseFirst: function(data) {
        if (data) {
            var upperChar = data.charAt(0).toUpperCase();
            return data.replace(data.charAt(0), upperChar);
        }

        return '';
    },

    /**
     * Handles string translation with language resource files.
     * @param {string} strValue The string value
     * @param {string} strFile The file name
     * @returns {string} The translated string value
     */
    _: function(strValue, strFile) {
        return Resource.msg(strValue, strFile, null);
    },

    /**
     * Write gateway information to the website's custom log file.
     * @param {string} dataType The data type
     * @param {Object} gatewayData The gateway data
     */
    log: function(dataType, gatewayData) {
        if (this.getValue(constants.CKO_DEBUG_ENABLED) === true) {
            // Create's a deep copy gatewayData, this will prevent data being deleted.
            var cloneGatewayData = JSON.parse(JSON.stringify(gatewayData));

            var logger = Logger.getLogger('ckodebug');

            // Remove sensitive data
            var cleanData = this.removeSensitiveData(cloneGatewayData);

            if (logger) {
                logger.debug(
                    this._('cko.gateway.name', 'cko') + ' ' + dataType + ' : {0}',
                    JSON.stringify(cleanData)
                );
            }
        }
    },

    /**
     * Remove sentitive data from the logs.
     * @param {Object} rawData The log data
     * @returns {Object} The filtered data
     */
    removeSensitiveData: function(rawData) {
        var data = rawData;
        if (data) {
            if (Object.prototype.hasOwnProperty.call(data, 'response_data')) {
                if (Object.prototype.hasOwnProperty.call(data.response_data, 'mandate_reference')) { data.response_data.mandate_reference = String.prototype.replace.call(data.response_data.mandate_reference, /\w/gi, '*'); }
            }
            if (Object.prototype.hasOwnProperty.call(data, 'source_data')) {
                data.source_data = sensitiveDataHelper.cleanSourceDataObject(data.source_data);
            }
            if (Object.prototype.hasOwnProperty.call(data, 'source')) {
                data.source = sensitiveDataHelper.cleanSourceObject(data.source);
            }

            if (Object.prototype.hasOwnProperty.call(data, 'customer')) {
                data.customer = sensitiveDataHelper.cleanCustomerObject(data.customer);
            }

            if (Object.prototype.hasOwnProperty.call(data, 'shipping')) {
                data.shipping = sensitiveDataHelper.cleanShippingObject(data.shipping);
            }

            if (Object.prototype.hasOwnProperty.call(data, 'billing_address')) {
                data.billing_address = sensitiveDataHelper.cleanBillingAddress(data.billing_address);
            }
        }

        return data;
    },

    /**
     * Return an order id.
     * @returns {string} The order id
     */
    getOrderId: function() {
        // The order this session sent to payment (set by the payment processors).
        // Never the request's reference parameter: it would let a shopper name
        // another order, its currency for their charge, or its return
        // eslint-disable-next-line
        return session.privacy.ckoOrderId || null;
    },

    /**
     * Get the cartridge metadata.
     * @returns {string} The platform data
     */
    getCartridgeMeta: function() {
        return this.getValue(constants.CKO_SG_PLATFORM_DATA);
    },

    /**
     * Get the account API keys.
     * @returns {Object} The account keys object
     */
    getAccountKeys: function() {
        var keys = {};
        var str = this.getValue(constants.CKO_MODE) === 'live' ? 'Live' : 'Sandbox';
        var liveOrSandboxPreference = (str === 'Live') ? constants.CKO_LIVE_NAS_ENABLED : constants.CKO_SANDBOX_NAS_ENABLED;
        var nasEnabled = this.getValue(liveOrSandboxPreference);

        keys.publicKey = this.getValue('cko' + str + nasEnabled + 'PublicKey');
        keys.secretKey = this.getValue('cko' + str + nasEnabled + 'SecretKey');
        keys.privateSharedKey = this.getValue('cko' + str + nasEnabled + 'PrivateSharedKey');

        return keys;
    },

    /**
     * Get live or sandbox nas enabled value.
     * @returns {Object} The NAS value
     */
    getNasEnabled: function() {
        var str = this.getValue(constants.CKO_MODE) === 'live' ? 'Live' : 'Sandbox';
        var liveOrSandboxPreference = (str === 'Live') ? constants.CKO_LIVE_NAS_ENABLED : constants.CKO_SANDBOX_NAS_ENABLED;
        var nasEnabled = this.getValue(liveOrSandboxPreference);
        return nasEnabled;
    },

    /**
     * Create an HTTP client to handle request to gateway.
     * @param {string} serviceId The service id
     * @param {Object} data The request data
     * @param {string} method The HTTP request method
     * @returns {Object} The HTTP response object
     */
    gatewayClientRequest: function(serviceId, data, method) {
        // eslint-disable-next-line
        method = method || 'POST';
        var serv = this.getService(serviceId);
        var requestData = data;

        // Prepare the request URL and data
        if (Object.prototype.hasOwnProperty.call(requestData, 'chargeId')) {
            var requestUrl = serv.getURL().replace('chargeId', requestData.chargeId);
            serv.setURL(requestUrl);
            delete requestData.chargeId;
        }

        // Set the request method
        serv.setRequestMethod(method);

        // Call the service
        var resp = serv.call(requestData);
        if (resp.status !== 'OK') {
            return false;
        }

        return resp.object;
    },

    /**
     * Get an HTTP service.
     * @param {string} serviceId The service id
     * @returns {Object} The HTTP service instance
     */
    getService: function(serviceId) {
        var parts = serviceId.split('.');
        var entity = parts[1];
        var action = parts[2];
        var mode = parts[3];
        var svcFile = entity + action.charAt(0).toUpperCase() + action.slice(1);
        var svcClass = require('*/cartridge/scripts/services/' + svcFile);

        return svcClass[mode]();
    },

    /**
     * Currency conversion mapping.
     * @param {string} currency The currency code
     * @returns {number} The conversion factor
     */
    getCkoFormatedValue: function(currency) {
        if (ckoCurrencyConfig.x1.currencies.match(currency)) {
            return ckoCurrencyConfig.x1.multiple;
        } else if (ckoCurrencyConfig.x1000.currencies.match(currency)) {
            return ckoCurrencyConfig.x1000.multiple;
        }
        return 100;
    },

    /**
     * Format a price for a gateway request.
     * @param {number} price The price to format
     * @param {string} currency The currency code
     * @returns {number} The formatted price
     */
    getFormattedPrice: function(price, currency) {
        var ckoFormateBy = this.getCkoFormatedValue(currency);
        var orderTotalFormated = price * ckoFormateBy;

        return orderTotalFormated.toFixed();
    },

    /**
     * Get the Checkout.com orders.
     * @param {string} orderNo The order number
     * @returns {Array} The list of orders
     */
    getOrders: function(orderNo) {
        // Prepare the output array
        var data = [];

        // Query the orders
        var result = SystemObjectMgr.querySystemObjects('Order', 'orderNo = {0}', 'creationDate desc', orderNo);

        // Loop through the results
        while (result.hasNext()) {
            // Get the payment instruments
            var item = result.next();
            var paymentInstruments = item.getPaymentInstruments();

            // Loop through the payment instruments
            for (var i = 0; i < paymentInstruments.length; i++) {
                if (this.isCkoItem(paymentInstruments[i].paymentMethod) && !this.containsObject(item, data)) {
                    data.push(item);
                }
            }
        }

        return data;
    },

    /**
     * Checks if an object already exists in an array.
     * @param {Object} obj The object
     * @param {Array} list The list of objects
     * @returns {boolean} If the object is found
     */
    containsObject: function(obj, list) {
        var i;
        for (i = 0; i < list.length; i++) {
            if (list[i] === obj) {
                return true;
            }
        }

        return false;
    },

    /**
     * Checks if a payment instrument is Checkout.com.
     * @param {Object} item The payment instrument instance
     * @returns {boolean} If the instance matches conditions
     */
    isCkoItem: function(item) {
        return item.length > 0 && item.indexOf('CHECKOUTCOM_') >= 0;
    },

    /**
     * Return the order currency code.
     * @returns {string} The currency code
     */
    getCurrency: function() {
        var orderId = this.getOrderId();

        // load the card and order information
        var order = OrderMgr.getOrder(orderId);
        var currency = order.getCurrencyCode();

        return currency;
    },

    /**
     * Strip spaces form a card number.
     * @param {string} cardNumber The number to process
     * @returns {string} The processed number
     */
    getFormattedNumber: function(cardNumber) {
        return cardNumber.replace(/\s/g, '');
    },

    /**
     * Confirm is a payment is valid from API response code.
     * @param {Object} gatewayResponse The gateway response
     * @returns {boolean} The payment success or failure
     */
    paymentSuccess: function(gatewayResponse) {
        if (!gatewayResponse || typeof gatewayResponse !== 'object' || gatewayResponse.approved === false) {
            return false;
        }

        // A payment declined, cancelled, expired or reversed is never a success
        if (['Declined', 'Canceled', 'Cancelled', 'Expired', 'Voided', 'Refunded'].indexOf(gatewayResponse.status) !== -1) {
            return false;
        }

        if (Object.prototype.hasOwnProperty.call(gatewayResponse, 'response_code')) {
            return gatewayResponse.response_code === '10000' || gatewayResponse.response_code === '10100' || gatewayResponse.response_code === '10200';
        // eslint-disable-next-line no-undef
        } else if (Object.prototype.hasOwnProperty.call(gatewayResponse, 'actions') && !empty(gatewayResponse.actions)) {
            return gatewayResponse.actions[0].response_code === '10000' || gatewayResponse.actions[0].response_code === '10100' || gatewayResponse.actions[0].response_code === '10200';
        } else if (Object.prototype.hasOwnProperty.call(gatewayResponse, 'source')) {
            return gatewayResponse.source.type === 'sofort' || gatewayResponse.source.type === 'bancontact' || gatewayResponse.source.type === 'boleto' || gatewayResponse.source.type === 'oxxo' || gatewayResponse.source.type === 'token';
        } else if (Object.prototype.hasOwnProperty.call(gatewayResponse, 'reference')) {
            // A payment that redirects the shopper (3DS, redirect APMs): its outcome
            // is verified on the return (paysOrder), never taken from this response
            // eslint-disable-next-line no-underscore-dangle
            var redirects = !!gatewayResponse._links && Object.prototype.hasOwnProperty.call(gatewayResponse._links, 'redirect');

            return redirects && gatewayResponse.reference === this.getOrderId();
        }

        return false;
    },

    /**
     * Whether a payment read back from Checkout.com pays this order: made for it
     * (its reference), approved, authorized or captured (or pending, when
     * allowed: the order then waits for it), for its amount and currency.
     * @param {dw.order.Order} order The order
     * @param {Object} payment The payment read back from Checkout.com
     * @param {Object} [options] allowPending
     * @returns {boolean} True when the payment pays the order
     */
    paysOrder: function(order, payment, options) {
        if (!order || !payment || typeof payment !== 'object' || !payment.id || payment.approved === false) {
            return false;
        }

        if (String(payment.reference || '') !== String(order.getOrderNo())) {
            return false;
        }

        var statuses = ['Authorized', 'Captured', 'Partially Captured', 'Paid'].concat(options && options.allowPending ? ['Pending'] : []);
        var currency = String(order.getCurrencyCode());

        if (statuses.indexOf(payment.status) === -1 || String(payment.currency || '').toUpperCase() !== currency.toUpperCase()) {
            return false;
        }

        // The order total, or the Checkout.com instrument's amount (the rest paid by gift certificate)
        var self = this;
        var amounts = [Number(this.getAmount(order))];

        order.getPaymentInstruments().toArray().forEach(function(instrument) {
            var amount = instrument.getPaymentTransaction() ? instrument.getPaymentTransaction().getAmount() : null;

            if (instrument.getPaymentMethod() !== 'GIFT_CERTIFICATE' && amount && amount.isAvailable()) {
                amounts.push(Number(self.getFormattedPrice(amount.getValue().toFixed(2), currency)));
            }
        });

        return amounts.indexOf(Number(payment.amount)) !== -1;
    },

    /**
     * Write the order information to session for the current shopper.
     * @param {Object} gatewayResponse The gateway response
     */
    updateCustomerData: function(gatewayResponse) {
        if ((gatewayResponse) && Object.prototype.hasOwnProperty.call(gatewayResponse, 'card')) {
            Transaction.wrap(function() {
                // eslint-disable-next-line
                if (session.customer.profile !== null) {
                    // eslint-disable-next-line
                    session.customer.profile.custom.ckoCustomerId = gatewayResponse.card.customerId;
                }
            });
        }
    },

    /**
     * Return the customer data.
     * @param {Object} args The method arguments
     * @returns {Object} The customer data
     */
    getCustomer: function(args) {
        // Load the card and order information
        var order = OrderMgr.getOrder(args.OrderNo);

        // Customer object
        var customer = {
            email: order.customerEmail,
            name: order.customerName,
        };

        return customer;
    },

    /**
     * Get the basket quantities.
     * @param {Object} args The method arguments
     * @returns {number} The basked quantities
     */
    getQuantity: function(args) {
        // load the card and order information
        var order = OrderMgr.getOrder(args.OrderNo);
        var quantity = order.getProductQuantityTotal();

        return quantity;
    },

    /**
     * Get the billing descriptor object from custom preferences.
     * @returns {Object} The billing descriptor data
     */
    getBillingDescriptorObject: function() {
        var billingDescriptor = {
            name: this.getValue(constants.CKO_BILLING_DESCRIPTOR1),
            city: this.getValue(constants.CKO_BILLING_DESCRIPTOR2),
        };

        return billingDescriptor;
    },

    /**
     * Get the products information.
     * @param {Object} args The method arguments
     * @returns {Object} The product information
     */
    getProductInformation: function(args) {
        // Load the card and order information
        var order = OrderMgr.getOrder(args.OrderNo);
        var it = order.productLineItems.iterator();
        var products = [];

        // Loop through the itemd
        while (it.hasNext()) {
            var pli = it.next();

            // product id
            var product = {
                product_id: pli.productID,
                quantity: pli.quantityValue,
                price: this.getFormattedPrice(pli.basePrice.value.toFixed(2), this.getCurrency()),
                description: pli.productName,
            };

            // Push to products array
            products.push(product);
        }
        if (this.getShippingValue(args)) {
            products.push(this.getShippingValue(args));
        }

        if (this.getTaxObject(args)) {
            products.push(this.getTaxObject(args));
        }

        return products;
    },

    /**
     * Return the tax object.
     * @param {Object} args The method arguments
     * @returns {Object} The tax data
     */
    getTaxObject: function(args) {
        // Load the card and order information
        var order = OrderMgr.getOrder(args.OrderNo);

        // Prepare the tax data
        var tax = {
            product_id: args.OrderNo,
            quantity: 1,
            price: this.getFormattedPrice(order.getTotalTax().valueOf().toFixed(2), this.getCurrency()),
            description: 'Order Tax',
        };

        // Test the order
        if (order.getTotalTax().valueOf() > 0) {
            return tax;
        }

        return {};
    },

    /**
     * Return the shipping object.
     * @param {Object} args The method arguments
     * @returns {Object} The shipping data
     */
    getShippingValue: function(args) {
        // Load the card and order information
        var order = OrderMgr.getOrder(args.OrderNo);

        // Get shipping address object
        var shipping = order.getDefaultShipment();

        // Check if shipping cost is applicable to this order
        if (shipping.getShippingTotalPrice().valueOf() > 0) {
            var shippment = {
                product_id: shipping.getShippingMethod().getID(),
                quantity: 1,
                price: this.getFormattedPrice(shipping.adjustedShippingTotalPrice.value.toFixed(2), this.getCurrency()),
                description: shipping.getShippingMethod().getDisplayName() + ' Shipping : ' + shipping.getShippingMethod().getDescription(),
            };

            return shippment;
        }

        return false;
    },

    /**
     * Return the order currency code.
     * @param {Object} args The method arguments
     * @returns {string} The currency code
     */
    getCurrencyCode: function(args) {
        // Get the order
        var order = OrderMgr.getOrder(args.OrderNo);

        // Get shipping address object
        var shipping = order.getDefaultShipment().getShippingMethod();
        var shippingCurrency = shipping.getCurrencyCode();

        return shippingCurrency;
    },

    /**
     * Get the product names.
     * @param {Object} args The method arguments
     * @returns {Array} The products list
     */
    getProductNames: function(args) {
        // Load the card and order information
        var order = OrderMgr.getOrder(args.OrderNo);

        // Prepare the iterator
        var it = order.productLineItems.iterator();

        // Prepare the product array
        var products = [];
        while (it.hasNext()) {
            var pli = it.next();
            products.push(pli.productName);
        }

        return products;
    },

    /**
     * Get the product price array.
     * @param {Object} args The method arguments
     * @returns {Array} The prices list
     */
    getProductPrices: function(args) {
        // Load the card and order information
        var order = OrderMgr.getOrder(args.OrderNo);

        // Get the product itemas
        var items = order.productLineItems.iterator();

        // Prepare the product array
        var products = [];
        while (items.hasNext()) {
            var item = items.next();
            products.push(item.getPriceValue());
        }

        return products;
    },

    /**
     * Get the product IDs.
     * @param {Object} args The method arguments
     * @returns {Array} The product ids list
     */
    getProductIds: function(args) {
        // Load the card and order information
        var order = OrderMgr.getOrder(args.OrderNo);
        var it = order.productLineItems.iterator();
        var productIds = [];
        while (it.hasNext()) {
            var pli = it.next();
            productIds.push(pli.productID);
        }

        return productIds;
    },

    /**
     * Get each product quantity.
     * @param {Object} args The method arguments
     * @returns {Array} The product quantities list
     */
    getProductQuantity: function(args) {
        // Load the card and order information
        var order = OrderMgr.getOrder(args.OrderNo);

        // Prepare the iterator
        var it = order.productLineItems.iterator();

        // Loop through the items
        var productsQuantites = 0;
        while (it.hasNext()) {
            var pli = it.next();
            productsQuantites += pli.quantityValue;
        }

        return productsQuantites;
    },

    /**
     * Return the host IP.
     * @param {Object} args The method arguments
     * @returns {string} The host IP
     */
    getHost: function(args) {
        // Load the card and order information
        var order = OrderMgr.getOrder(args.OrderNo);
        var host = order.getRemoteHost();

        return host;
    },

    /**
     * Return an order amount.
     * @param {Object} order The order instance
     * @returns {number} The amount
     */
    getAmount: function(order) {
        var amount = this.getFormattedPrice(order.totalGrossPrice.value.toFixed(2), order.getCurrencyCode());

        return amount;
    },

    /**
     * Return a phone object.
     * @param {Object} args The method arguments
     * @returns {Object} The phone object
     */
    getPhoneObject: function(args) {
        // Load the card and order information
        var order = OrderMgr.getOrder(args.OrderNo);

        // Get billing address information
        var billingAddress = order.getBillingAddress();

        // Creating phone object
        var phone = {
            country_code: null,
            number: billingAddress.getPhone(),
        };

        return phone;
    },

    /**
     * Get a customer full name.
     * @param {Object} args The method arguments
     * @returns {string} The customer full name
     */
    getCustomerName: function(args) {
        // Load the card and order information
        var order = OrderMgr.getOrder(args.OrderNo);

        // Get billing address information
        var billingAddress = order.getBillingAddress();
        var fullname = billingAddress.getFullName();

        return fullname;
    },

    /**
     * Get a customer first name.
     * @param {Object} args The method arguments
     * @returns {string} The customer first name
     */
    getCustomerFirstName: function(args) {
        // Load the card and order information
        var order = OrderMgr.getOrder(args.OrderNo);

        // Get billing address information
        var billingAddress = order.getBillingAddress();
        var firstname = billingAddress.getFirstName();

        return firstname;
    },

    /**
     * Get a customer last name.
     * @param {Object} args The method arguments
     * @returns {string} The customer last name
     */
    getCustomerLastName: function(args) {
        // Load the card and order information
        var order = OrderMgr.getOrder(args.OrderNo);

        // Get billing address information
        var billingAddress = order.getBillingAddress();
        var lastname = billingAddress.getLastName();

        return lastname;
    },

    /**
     * Return the capture time.
     * @returns {Object} The capture time
     */
    getCaptureTime: function() {
        // Get the current date/time in milliseconds
        var now = Date.now();

        // Get the capture time configured, or min time 0.5 minute if 0
        var configCaptureTime = this.getValue(constants.CKO_AUTO_CAPTURE_TIME);
        var captureOnMin = configCaptureTime < 2 ? 2 : configCaptureTime;

        // Convert the capture time from minutes to milliseconds
        var captureOnMs = now + (parseInt(captureOnMin) * 60000);

        // Convert the capture time to ISO 8601 format
        return new Date(captureOnMs).toISOString();
    },

    /**
     * Build a 3ds object.
     * @returns {Object} The 3ds data
     */
    get3Ds: function() {
        // 3ds object
        var ds = {
            enabled: this.getValue(constants.CKO_3DS),
            attempt_n3d: this.getValue(constants.CKO_N3DS),
        };

        return ds;
    },

    /**
     * Build a Google Pay 3ds object.
     * @returns {Object} The 3ds data
     */
    getGooglePay3Ds: function() {
        var googlePay3ds = {
            enabled: this.getValue(constants.CKO_GOOGLE_PAY_3DS),
        };

        return googlePay3ds;
    },

    /**
     * Build the metadata object.
     * @param {Object} data The request data
     * @param {string} args The method arguments
     * @returns {Object} The metadata
     */
    getMetadataObject: function(data, args) {
        // Prepare the base metadata
        var meta = {
            integration_data: this.getCartridgeMeta(),
            platform_data: this.getValue(constants.CKO_SG_PLATFORM_DATA),
        };

        // Add the data info if needed
        if (Object.prototype.hasOwnProperty.call(data, 'type')) {
            meta.udf1 = data.type;
        }

        // Get the payment processor
        var paymentInstrument = args.PaymentInstrument;
        var paymentProcessorId = PaymentMgr.getPaymentMethod(paymentInstrument.getPaymentMethod()).getPaymentProcessor().getID();

        // Add the payment processor to the metadata
        meta.payment_processor = paymentProcessorId;

        return meta;
    },

    /**
     * Build metadata object.
     * @param {Object} data The request data
     * @param {string} processorId The processor id
     * @returns {Object} The metadata
     */
    getMetadata: function(data, processorId) {
        // Prepare the base metadata
        var meta = {
            integration_data: this.getCartridgeMeta(),
            platform_data: this.getValue(constants.CKO_SG_PLATFORM_DATA),
        };

        // Add the data info if needed
        if (Object.prototype.hasOwnProperty.call(data, 'type')) {
            meta.udf1 = data.type;
        }

        // Add the payment processor to the metadata
        meta.payment_processor = processorId;

        return meta;
    },

    /**
     * Get the site country code from locale.
     * @returns {string} The site  country code
     */
    getSiteCurrentCountryCode: function() {
        // return Site.getCurrent().defaultLocale.split('_')[1];
        var currentLocale = request.getLocale();
        var locale = Locale.getLocale(currentLocale);
        var countryCode = locale.getCountry();

        return countryCode;
    },

    /**
     * Build the metadata string.
     * @param {Object} data The request data
     * @param {string} args The method arguments
     * @returns {string} The metadata
     */
    getMetadataString: function(data, args) {
        // Prepare the base metadata
        var meta = 'integration_data' + this.getCartridgeMeta() + 'platform_data' + this.getValue(constants.CKO_SG_PLATFORM_DATA);

        // Add the data info if needed
        if (Object.prototype.hasOwnProperty.call(data, 'type')) {
            meta += 'udf1' + data.type;
        }

        // Get the payment processor
        var paymentInstrument = args.PaymentInstrument;
        var paymentProcessor = PaymentMgr.getPaymentMethod(paymentInstrument.getPaymentMethod()).getPaymentProcessor();

        // Add the payment processor to the metadata
        meta += 'payment_processor' + paymentProcessor.getID();

        return meta;
    },

    /**
     * Build metadata object.
     * @param {Object} data The request data
     * @param {string} processorId The processor id
     * @returns {Object} The metadata
     */
    getApplePayMetadata: function(data, processorId) {
        // Prepare the base metadata
        var meta = {
            integration_data: this.getCartridgeMeta(),
            platform_data: this.getValue(constants.CKO_SG_PLATFORM_DATA),
        };

        // Add the data info if needed
        if (Object.prototype.hasOwnProperty.call(data, 'type')) {
            meta.udf1 = data.type;
        }

        // Add the payment processor to the metadata
        meta.payment_processor = processorId;

        return meta;
    },

    /**
     * Return the billing object.
     * @param {Object} args The method arguments
     * @returns {Object} The billing data
     */
    getBillingObject: function(args) {
        // Load the card and order information
        var order = OrderMgr.getOrder(args.OrderNo);

        // Get billing address information
        var billingAddress = order.getBillingAddress();

        // Creating billing address object
        var billingDetails = {
            address_line1: billingAddress.getAddress1(),
            address_line2: billingAddress.getAddress2(),
            city: billingAddress.getCity(),
            state: billingAddress.getStateCode(),
            zip: billingAddress.getPostalCode(),
            country: billingAddress.getCountryCode().value,
        };

        return billingDetails;
    },

    /**
     * Get the billing country.
     * @param {Object} args The method arguments
     * @returns {string} The billing country code
     */
    getBillingCountry: function(args) {
        // Load the card and order information
        var order = OrderMgr.getOrder(args.OrderNo);

        // Get billing address information
        var billingAddress = order.getBillingAddress();
        var country = billingAddress.getCountryCode().value;

        return country;
    },

    /**
     * Return the shipping object.
     * @param {Object} args The method arguments
     * @returns {Object} The shipping data
     */
    getShippingObject: function(args) {
        // Load the card and order information
        var order = OrderMgr.getOrder(args.OrderNo);

        // Get shipping address object
        var shippingAddress = order.getDefaultShipment().getShippingAddress();

        // Creating address object
        var shippingDetails = {
            address_line1: shippingAddress.getAddress1(),
            address_line2: shippingAddress.getAddress2(),
            city: shippingAddress.getCity(),
            state: shippingAddress.getStateCode(),
            zip: shippingAddress.getPostalCode(),
            country: shippingAddress.getCountryCode().value,
        };

        // Shipping object
        var shipping = {
            address: shippingDetails,
            phone: this.getPhoneObject(args),
        };

        return shipping;
    },

    /**
     * Get product quantities from a basket.
     * @param {Object} basket The basket instance
     * @returns {Array} The list of quantities
     */
    getBasketObject: function(basket) {
        var currency = this.getAppModeValue('GBP', basket.getCurrencyCode());
        var productsQuantites = [];
        var it = basket.productLineItems.iterator();
        while (it.hasNext()) {
            var pli = it.next();
            var productTaxRate = pli.taxRate * 100 * 100;
            var productQuantity = pli.quantityValue;
            var unitPrice = Math.round(this.getFormattedPrice(pli.adjustedGrossPrice.value.toFixed(2), currency) / productQuantity);
            var totalAmount = this.getFormattedPrice(pli.adjustedGrossPrice.value, currency);
            var products = {
                name: pli.productName,
                quantity: productQuantity.toString(),
                unit_price: unitPrice.toString(),
                tax_rate: productTaxRate.toString(),
                total_amount: totalAmount.toString(),
                total_tax_amount: this.getFormattedPrice(pli.adjustedTax.value, currency),
            };

            productsQuantites.push(products);
        }
        var shippingTaxRate = basket.defaultShipment.standardShippingLineItem.getTaxRate() * 100 * 100;
        var shipping = {
            name: basket.defaultShipment.shippingMethod.displayName + ' Shipping',
            quantity: '1',
            unit_price: this.getFormattedPrice(basket.adjustedShippingTotalGrossPrice.value, currency),
            tax_rate: shippingTaxRate.toString(),
            total_amount: this.getFormattedPrice(basket.adjustedShippingTotalGrossPrice.value, currency),
            total_tax_amount: this.getFormattedPrice(basket.adjustedShippingTotalTax.value, currency),
        };

        if (basket.shippingTotalPrice.value > 0) {
            productsQuantites.push(shipping);
        }

        return productsQuantites;
    },

    /**
     * Get product quantities from an order.
     * @param {Object} args The method arguments
     * @returns {Array} The list of quantities
     */
    getOrderBasketObject: function(args) {
        // Prepare some variables
        var currency = this.getAppModeValue('GBP', this.getCurrencyCode(args));
        var order = OrderMgr.getOrder(args.OrderNo);
        var it = order.productLineItems.iterator();
        var productsQuantites = [];

        // Iterate through the products
        while (it.hasNext()) {
            var pli = it.next();
            var productTaxRate = pli.taxRate * 100 * 100;
            var productQuantity = pli.quantityValue;
            var unitPrice = Math.round(this.getFormattedPrice(pli.adjustedGrossPrice.value.toFixed(2), currency) / productQuantity);
            var totalAmount = this.getFormattedPrice(pli.adjustedGrossPrice.value, currency);
            var products = {
                name: pli.productName,
                quantity: productQuantity.toString(),
                unit_price: unitPrice.toString(),
                tax_rate: productTaxRate.toString(),
                total_amount: totalAmount.toString(),
                total_tax_amount: this.getFormattedPrice(pli.adjustedTax.value, currency),
            };

            productsQuantites.push(products);
        }

        // Set the shipping variables
        var shippingTaxRate = order.defaultShipment.standardShippingLineItem.getTaxRate() * 100 * 100;
        var shipping = {
            name: order.defaultShipment.shippingMethod.displayName + ' Shipping',
            quantity: '1',
            unit_price: this.getFormattedPrice(order.adjustedShippingTotalGrossPrice.value, currency),
            tax_rate: shippingTaxRate.toString(),
            total_amount: this.getFormattedPrice(order.adjustedShippingTotalGrossPrice.value, currency),
            total_tax_amount: this.getFormattedPrice(order.adjustedShippingTotalTax.value, currency),
        };

        if (order.shippingTotalPrice.value > 0) {
            productsQuantites.push(shipping);
        }

        return productsQuantites;
    },

    /**
     * Get the basket country code.
     * @param {Object} basket The basket instance
     * @returns {string} The site country code
     */
    getBasketCountyCode: function(basket) {
        var countyCode = basket.defaultShipment.shippingAddress.countryCode.valueOf();

        return countyCode;
    },

    /**
     * Get the basket address.
     * @param {Object} basket The basket instance
     * @returns {Object} The address
     */
    getBasketAddress: function(basket) {
        var address = {
            given_name: basket.defaultShipment.shippingAddress.firstName,
            family_name: basket.defaultShipment.shippingAddress.lastName,
            email: null,
            title: basket.defaultShipment.shippingAddress.title,
            street_address: basket.defaultShipment.shippingAddress.address1,
            street_address2: basket.defaultShipment.shippingAddress.address2,
            postal_code: basket.defaultShipment.shippingAddress.postalCode,
            city: basket.defaultShipment.shippingAddress.city,
            phone: basket.defaultShipment.shippingAddress.phone,
            country: basket.defaultShipment.shippingAddress.countryCode.valueOf(),
        };

        return address;
    },

    /**
     * Get the order address.
     * @param {Object} args The method arguments
     * @returns {Object} The address
     */
    getOrderBasketAddress: function(args) {
        var order = OrderMgr.getOrder(args.OrderNo);
        var address = {
            given_name: order.defaultShipment.shippingAddress.firstName,
            family_name: order.defaultShipment.shippingAddress.lastName,
            email: order.customerEmail,
            title: order.defaultShipment.shippingAddress.title,
            street_address: order.defaultShipment.shippingAddress.address1,
            street_address2: order.defaultShipment.shippingAddress.address2,
            postal_code: order.defaultShipment.shippingAddress.postalCode,
            city: order.defaultShipment.shippingAddress.city,
            phone: order.defaultShipment.shippingAddress.phone,
            country: order.defaultShipment.shippingAddress.countryCode.valueOf(),
        };

        return address;
    },

    /**
     * Build a gateway source object
     * @param {Object} tokenData The token data
     * @returns {Object} The gateway source
     */
    getSourceObject: function(tokenData) {
        // Source object
        var source = {
            type: 'token',
            token: tokenData.token,
        };

        return source;
    },

    /**
     * Returns true if card is a mada card
     * @param {string} card number
     * @param {Object} config - MADA Config
     * @returns {boolean} card type
     */
    isMadaCard: function(card, config) {
        // If MADA is disabled then return fales to process MADA Payments
        // eslint-disable-next-line no-undef
        var currentLocale = request.getLocale();
        var locale = Locale.getLocale(currentLocale);
        var countryCode = locale.getCountry();

        if (!this.isMADAPaymentsEnabled() || countryCode !== 'SA') {
            return false;
        }

        if (!config || !config.type) {
            return false;
        }

        var madaBinsConfig = require('*/cartridge/config/ckoMadaConfig');
        var madaBins = madaBinsConfig[config.type] || {};

        // First 6 card number
        var cardNumber = card.slice(0, 6);
        // First card number
        var firstNumber = card.charAt(0);

        switch (firstNumber) {
            case '4':
                return madaBins.four.some(function(element) { return element === cardNumber; });
            case '5':
                return madaBins.five.some(function(element) { return element === cardNumber; });
            case '6':
                return madaBins.six.some(function(element) { return element === cardNumber; });
            case '9':
                return madaBins.nine.some(function(element) { return element === cardNumber; });
            default:
                return false;
        }
    },
    /**
     * Check MADA Payments Enabled or not
     * @returns {boolean} MADA payments enabled or not
     */
    isMADAPaymentsEnabled: function() {
        return !!this.getValue(constants.CKO_MADA_PAYMENTS_ENABLED);
    },
};

// Module exports
module.exports = ckoHelper;
