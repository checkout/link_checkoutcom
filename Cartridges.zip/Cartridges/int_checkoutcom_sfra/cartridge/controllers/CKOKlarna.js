/**
 * Klarna controller.
 */

'use strict';

/* Server */
var server = require('server');

/* API Includes */
var BasketMgr = require('dw/order/BasketMgr');
var Resource = require('dw/web/Resource');

/** Utility **/
var ckoHelper = require('*/cartridge/scripts/helpers/ckoHelper');
var orderGuard = require('*/cartridge/scripts/helpers/orderGuard');
var csrfProtection = require('*/cartridge/scripts/middleware/csrf');

/** Checkout Data Configuration File **/
var constants = require('*/cartridge/config/constants');
var Logger = require('dw/system/Logger').getLogger('ckoPayments');

var errorCodeMapping = {
    billing_country_invalid: Resource.msg('cko.klarna.error.billing.country.invalid', 'cko', null),
    currency_not_supported: Resource.msg('cko.klarna.error.currency.invalid', 'cko', null),
    generic_error: Resource.msg('cko.klarna.generic.error', 'cko', null),
};

/**
 * Error Mapping
 * @param {Object} errorMessage service response
 * @returns {string} error message
 */
function getKlarnaErrorMessage(errorMessage) {
    var responseObj = JSON.parse(errorMessage);
    return (responseObj.error_codes && errorCodeMapping[responseObj.error_codes[0]]) || errorCodeMapping.generic_error;
}

/**
 * Handles Checkout.com Create Order Context API request
 * @returns {string} The controller response
 */
server.post('CreateContext', server.middleware.https, csrfProtection.validateAjaxRequest, function(req, res, next) {
    var currentBasket = BasketMgr.getCurrentBasket();
    var Site = require('dw/system/Site');
    var errorMessage;
    try {
        var billingCountryCode = '';

        if (req.form.billingCountry) {
            billingCountryCode = req.form.billingCountry;
        } else if (currentBasket.billingAddress && currentBasket.billingAddress.countryCode) {
            billingCountryCode = currentBasket.billingAddress.countryCode.value;
        } else if (currentBasket.defaultShipment.shippingAddress && currentBasket.defaultShipment.shippingAddress.countryCode) {
            billingCountryCode = currentBasket.defaultShipment.shippingAddress.countryCode.value;
        }
        var requestData = {
            currency: currentBasket.getCurrencyCode(),
            amount: currentBasket.totalGrossPrice.value * 100,
            source: {
                type: 'klarna',
                account_holder: {
                    billing_address: {
                        country: billingCountryCode,
                    },
                },
            },
            items: [
            ],
            processing: {
                locale: 'en-GB',
            },
            processing_channel_id: Site.getCurrent().getCustomPreferenceValue('ckoProcessingChannelId'),
        };

        var subTotal = 0;
        (currentBasket.allProductLineItems).toArray().forEach(function(item) {
            var itemQuantity = item.quantity.value;
            var itemProratedPrice = (item.proratedPrice.value / itemQuantity);
            var unitPrice = parseFloat((itemProratedPrice * 100).toFixed());
            if (unitPrice > 0) {
                var newItem = {
                    name: item.productName,
                    unit_price: unitPrice,
                    total_amount: unitPrice * itemQuantity,
                    quantity: itemQuantity,
                    reference: item.getUUID(),
                };
                subTotal += (unitPrice * itemQuantity);
                requestData.items.push(newItem);
            }
        });
        // Adjust shipping price to accomodate the rounding off error
        if (subTotal + requestData.processing.shipping_amount !== requestData.amount) {
            requestData.processing.shipping_amount = requestData.amount - subTotal;
        }

        var responseData = ckoHelper.createContext('cko.payment.contexts.' + ckoHelper.getValue(constants.CKO_MODE) + '.service', requestData, 'POST');
        if (responseData.status === 'OK') {
            res.json({
                success: true,
                id: responseData.object.id,
                partner_metadata: responseData.object.partner_metadata,
            });
            return next();
        }

        errorMessage = getKlarnaErrorMessage(responseData.errorMessage);
    } catch (error) {
        Logger.error('Error While Creating the context for Klarna. Error Details: ' + error.message);
        errorMessage = errorCodeMapping.generic_error;
    }

    var errorTitle = Resource.msg('cko.klarna.generic.error.title', 'cko', null);

    res.setStatusCode(500);
    res.json({
        error: true,
        message: errorMessage,
        errorTitle: errorTitle,
    });
    return next();
});

/**
 * Handles Checkout.com Create Order Context API request
 * @returns {string} The controller response
 */
server.post('OnApprove', csrfProtection.validateAjaxRequest, function(req, res, next) {
    var COHelpers = require('*/cartridge/scripts/checkout/checkoutHelpers');
    var addressHelpers = require('*/cartridge/scripts/helpers/addressHelpers');
    var orderId = req.form.orderID;
    var OrderMgr = require('dw/order/OrderMgr');
    var URLUtils = require('dw/web/URLUtils');
    var order = OrderMgr.getOrder(orderId);
    var authorizeKlarna = true;

    // Only the shopper's own order, and only once: a repeated approval (double
    // click, retry) must not authorize or place it again
    var shopper = req.currentCustomer && req.currentCustomer.raw;
    var isShopperOrder = !!order && !!shopper && !!order.getCustomer() && order.getCustomer().getID() === shopper.getID();

    // A session blocked by fraud detection places nothing
    if (!isShopperOrder || req.session.privacyCache.get('fraudDetectionStatus')) {
        res.json({ error: true, errorMessage: Resource.msg('error.technical', 'checkout', null) });
        return next();
    }

    // Only a Klarna order: authorizing another method's order here (Flow, ACH)
    // would place it without its payment
    var isKlarnaOrder = order.getPaymentInstruments(constants.CKO_KLARNA_PAYMENTINSTRUMENT).size() > 0
        && order.getPaymentInstruments().toArray().every(function(instrument) {
            return instrument.getPaymentMethod() === constants.CKO_KLARNA_PAYMENTINSTRUMENT || instrument.getPaymentMethod() === 'GIFT_CERTIFICATE';
        });

    if (!isKlarnaOrder) {
        res.json({ error: true, errorMessage: Resource.msg('error.technical', 'checkout', null) });
        return next();
    }

    var klarnaInstruments = order.getPaymentInstruments().toArray().filter(function(instrument) {
        return !!instrument.paymentTransaction.transactionID && instrument.paymentTransaction.transactionID !== order.orderNo;
    });

    if (orderGuard.isPlaced(orderGuard.reload(order))) {
        res.json({ error: false, orderID: order.orderNo, orderToken: order.orderToken, continueUrl: URLUtils.url('Order-Confirm').toString() });
        return next();
    }

    if (!orderGuard.isOpen(orderGuard.reload(order)) || klarnaInstruments.length > 0) {
        // Failed already, or authorized by a concurrent approval still being placed
        res.json({ error: true, errorMessage: Resource.msg('error.technical', 'checkout', null) });
        return next();
    }

    // Fraud detection before the Klarna authorization: a rejected order never
    // holds a payment that a concurrent request could place it with
    var fraudDetectionStatus = orderGuard.screenOrder(req, order, order);
    if (fraudDetectionStatus.status === 'fail') {
        res.json({
            error: true,
            cartError: true,
            redirectUrl: URLUtils.url('Error-ErrorCode', 'err', fraudDetectionStatus.errorCode).toString(),
            errorMessage: Resource.msg('error.technical', 'checkout', null),
        });

        return next();
    }

    var handlePaymentResult = COHelpers.handlePayments(order, order.orderNo, authorizeKlarna);
    if (handlePaymentResult.error) {
        res.json({
            error: true,
            errorMessage: Resource.msg('error.technical', 'checkout', null),
        });
        return next();
    }

    // Places the order (once: a concurrent approval placing it first is a success)
    var placeOrderResult = orderGuard.placeOrder(order, fraudDetectionStatus);
    if (placeOrderResult.error) {
        orderGuard.reverseStrayPayments(order.orderNo);
        orderGuard.failOrder(order);
        res.json({
            error: true,
            errorMessage: Resource.msg('error.technical', 'checkout', null),
        });
        this.emit('route:Complete', req, res);
        return;
    }

    if (req.currentCustomer.addressBook) {
        // save all used shipping addresses to address book of the logged in customer
        var allAddresses = addressHelpers.gatherShippingAddresses(order);
        allAddresses.forEach(function(address) {
            if (!addressHelpers.checkIfAddressStored(address, req.currentCustomer.addressBook.addresses)) {
                addressHelpers.saveAddress(address, req.currentCustomer, addressHelpers.generateAddressName(address));
            }
        });
    }

    if (order.getCustomerEmail() && !placeOrderResult.alreadyPlaced) {
        COHelpers.sendConfirmationEmail(order, req.locale.id);
    }

    // Reset usingMultiShip after successful Order placement
    req.session.privacyCache.set('usingMultiShipping', false);

    // TODO: Exposing a direct route to an Order, without at least encoding the orderID
    //  is a serious PII violation.  It enables looking up every customers orders, one at a
    //  time.
    res.json({
        error: false,
        orderID: order.orderNo,
        orderToken: order.orderToken,
        continueUrl: URLUtils.url('Order-Confirm').toString(),
    });

    this.emit('route:Complete', req, res);
    return;
});

/*
 * Module exports
 */
module.exports = server.exports();
