'use strict';

/**
 * Helper for Bizum asynchronous webhook notification storage.
 *
 * Reuses the `webhookNotification` SFCC custom object type (primary key: orderNo)
 * to bridge the server-to-server CKO webhook with the client-side polling loop.
 * The same custom object type is shared with MB Way.
 *
 * Required Business Manager setup:
 *   Object type: webhookNotification
 *   Attributes:  webhookPayload (Text), webhookType (String)
 */

var CustomObjectMgr = require('dw/object/CustomObjectMgr');
var Transaction = require('dw/system/Transaction');
var Logger = require('dw/system/Logger');

var CUSTOM_OBJECT_TYPE = 'webhookNotification';

/**
 * The record key: the type is organization-wide while order numbers are only
 * unique per site, so the key binds the site and one site's webhook can never
 * be read or deleted by another site's poll.
 * @param {string} orderNo The order number
 * @returns {string} The key
 */
function mailboxKey(orderNo) {
    return require('dw/system/Site').getCurrent().getID() + '_' + orderNo;
}

var bizumHelper = {
    /**
     * Persists a CKO webhook payload for a given order in the webhookNotification custom object.
     * Creates the object if it does not yet exist; overwrites if it does.
     *
     * @param {string} orderNo - SFCC order number used as the custom object key
     * @param {Object} hook    - Parsed webhook body from Checkout.com
     */
    storeWebhookNotification: function(orderNo, hook) {
        try {
            Transaction.wrap(function() {
                var obj = CustomObjectMgr.getCustomObject(CUSTOM_OBJECT_TYPE, mailboxKey(orderNo));
                if (!obj) {
                    obj = CustomObjectMgr.createCustomObject(CUSTOM_OBJECT_TYPE, mailboxKey(orderNo));
                }
                // Never replace a later state with an earlier one (out-of-order delivery)
                var orderGuard = require('*/cartridge/scripts/helpers/orderGuard');

                if (orderGuard.notificationRank(obj.custom.webhookType) > orderGuard.notificationRank(hook.type)) {
                    return;
                }

                obj.custom.webhookPayload = JSON.stringify(hook);
                obj.custom.webhookType = hook.type;
            });
        } catch (e) {
            Logger.error('bizumHelper.storeWebhookNotification failed for order {0}: {1}', orderNo, e.message);
            // The webhook then fails and is delivered again: the poll must see it
            throw e;
        }
    },

    /**
     * Retrieves the stored webhook notification for an order.
     *
     * @param {string} orderNo - SFCC order number
     * @returns {Object|null} Object with webhookType and webhookPayload, or null if not found
     */
    getWebhookNotification: function(orderNo) {
        var obj = CustomObjectMgr.getCustomObject(CUSTOM_OBJECT_TYPE, mailboxKey(orderNo));
        if (obj) {
            return {
                webhookType: obj.custom.webhookType,
                webhookPayload: obj.custom.webhookPayload,
            };
        }
        return null;
    },

    /**
     * Removes the webhookNotification custom object for an order (cleanup after processing).
     *
     * @param {string} orderNo - SFCC order number
     */
    deleteWebhookNotification: function(orderNo) {
        try {
            Transaction.wrap(function() {
                var obj = CustomObjectMgr.getCustomObject(CUSTOM_OBJECT_TYPE, mailboxKey(orderNo));
                if (obj) {
                    CustomObjectMgr.remove(obj);
                }
            });
        } catch (e) {
            Logger.error('bizumHelper.deleteWebhookNotification failed for order {0}: {1}', orderNo, e.message);
        }
    },
};

module.exports = bizumHelper;
