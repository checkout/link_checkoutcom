'use strict';

var collections = require('*/cartridge/scripts/util/collections');

var PaymentInstrument = require('dw/order/PaymentInstrument');
var PaymentMgr = require('dw/order/PaymentMgr');
var Resource = require('dw/web/Resource');
var Transaction = require('dw/system/Transaction');
var OrderMgr = require('dw/order/OrderMgr');

/** CKO Util */
var ckoHelper = require('*/cartridge/scripts/helpers/ckoHelper');
var orderGuard = require('*/cartridge/scripts/helpers/orderGuard');
var apmHelper = require('*/cartridge/scripts/helpers/apmHelper');
var apmConfig = require('*/cartridge/config/ckoApmConfig');

/**
 * Verifies that the payment data is valid.
 * @param {dw.order.Basket} basket Current users's basket
 * @param {Object} paymentInformation - the payment information
 * @param {string} paymentMethodID - paymentmethodID
 * @param {Object} req the request object
 * @returns {Object} The form validation result
 */
function Handle(basket, paymentInformation, paymentMethodID, req) {
    var currentBasket = basket;
    var apmErrors = {};
    var serverErrors = [];
    var invalidPaymentMethod;

    // Validate payment instrument
    if (paymentMethodID === 'CHECKOUTCOM_APM') {
        var apmPaymentMethod = PaymentMgr.getPaymentMethod('CHECKOUTCOM_APM');

        if (!apmPaymentMethod) {
            // Invalid Payment Method
            invalidPaymentMethod = Resource.msg('error.payment.not.valid', 'checkout', null);

            return { fieldErrors: [], serverErrors: [invalidPaymentMethod], error: true };
        }
    }

    // eslint-disable-next-line no-undef
    var country = require('dw/util/Locale').getLocale(request.getLocale()).getCountry();

    if (!paymentInformation.type.value || !apmHelper.isApmAvailable(paymentInformation.type.value, currentBasket.getCurrencyCode(), country)) {
        // Invalid, disabled or not offered for this currency or country
        invalidPaymentMethod = Resource.msg('error.payment.not.valid', 'checkout', null);

        return { fieldErrors: [], serverErrors: [invalidPaymentMethod], error: true };

        // Invalid Payment Type
        // apmErrors[paymentInformation.type.htmlName] =
        // Resource.msg('error.invalid.type.value', paymentInformation.type.htmlValue, null);

        // return { fieldErrors: [apmErrors], serverErrors: serverErrors, error: true };
    }

    Transaction.wrap(function() {
        currentBasket.removeAllPaymentInstruments();

        var paymentInstrument = currentBasket.createPaymentInstrument(
            'CHECKOUTCOM_APM', currentBasket.totalGrossPrice
        );

        paymentInstrument.custom.ckoPaymentData = JSON.stringify(paymentInformation);
    });

    return { fieldErrors: apmErrors, serverErrors: serverErrors, error: false };
}

/**
 * Authorizes a payment using an apm. Customizations may use other processors and custom
 *      logic to authorize apm payment.
 * @param {number} orderNumber - The current order's number
 * @param {dw.order.PaymentInstrument} paymentInstrument -  The payment instrument to authorize
 * @param {dw.order.PaymentProcessor} paymentProcessor -  The payment processor of the current
 *      payment method
 * @return {Object} returns an error object
 */
function Authorize(orderNumber, paymentInstrument, paymentProcessor) {
    var serverErrors = [];
    var fieldErrors = {};
    var error = false;

    // Get the order
    var order = OrderMgr.getOrder(orderNumber);
    var formData = JSON.parse(paymentInstrument.custom.ckoPaymentData);

    // Prepare the arguments
    var args = {
        order: order,
        processorId: paymentProcessor.ID,
        paymentData: formData,
    };

    var ckoPaymentRequest = null;

    try {
        // Checked again here: the payment data was posted by the browser
        var type = formData && formData.type ? formData.type.value : null;
        // eslint-disable-next-line no-undef
        var country = require('dw/util/Locale').getLocale(request.getLocale()).getCountry();

        if (!apmHelper.isApmAvailable(type, order.getCurrencyCode(), country)) {
            throw new Error('APM ' + type + ' is not available for order ' + orderNumber);
        }

        // Get the selected APM request data
        var apmConfigData = apmConfig[type + 'Authorization'](args);

        ckoPaymentRequest = apmHelper.handleRequest(apmConfigData, paymentProcessor.ID, orderNumber);

        // Handle errors
        if (ckoPaymentRequest.error) {
            error = true;
            serverErrors.push(
                ckoHelper.getPaymentFailureMessage()
            );
        }

        // A webhook may update the order at the same moment: a write conflict here
        // must not turn an approved payment into a failed order
        orderGuard.recordTransaction(orderNumber, paymentInstrument, paymentProcessor, ckoPaymentRequest.transactionID);
    } catch (e) {
        error = true;
        serverErrors.push(
            Resource.msg('error.technical', 'checkout', null)
        );
    }

    // On error the caller fails the order, after releasing any payment Checkout.com took for it
    // eslint-disable-next-line
    return { fieldErrors: fieldErrors, serverErrors: serverErrors, error: error, redirectUrl: ckoPaymentRequest ? ckoPaymentRequest.redirectUrl : null, awaitingPayment: !!(ckoPaymentRequest && ckoPaymentRequest.awaitingPayment) };
}

exports.Handle = Handle;
exports.Authorize = Authorize;
