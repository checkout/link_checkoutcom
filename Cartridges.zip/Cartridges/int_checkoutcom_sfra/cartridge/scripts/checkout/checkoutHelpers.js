'use strict';

var checkoutHelper = module.superModule || {};

var HookMgr = require('dw/system/HookMgr');
var OrderMgr = require('dw/order/OrderMgr');
var PaymentInstrument = require('dw/order/PaymentInstrument');
var PaymentMgr = require('dw/order/PaymentMgr');
var Transaction = require('dw/system/Transaction');
var ckoHelper = require('*/cartridge/scripts/helpers/ckoHelper');
var constants = require('*/cartridge/config/constants');

// static functions needed for Checkout Controller logic

// ////////////////////////////     Modified    ////////////////////////////////////////////////
/**
 * handles the payment authorization for each payment instrument
 * @param {dw.order.Order} order - the order object
 * @param {string} orderNumber - The order number for the order
 * @param {boolean} authorizeKlarna - The order number for the order
 * @returns {Object} an error object
 */
function handlePayments(order, orderNumber, authorizeKlarna) {
    var result = {};

    if (order.totalNetPrice !== 0.00) {
        var paymentInstruments = order.paymentInstruments;

        if (paymentInstruments.length === 0) {
            Transaction.wrap(function() { OrderMgr.failOrder(order, true); });
            result.error = true;
        }

        if (!result.error) {
            for (var i = 0; i < paymentInstruments.length; i++) {
                var paymentInstrument = paymentInstruments[i];
                var paymentProcessor = PaymentMgr
                    .getPaymentMethod(paymentInstrument.paymentMethod)
                    .paymentProcessor;
                var authorizationResult;
                if (paymentProcessor === null) {
                    Transaction.begin();
                    paymentInstrument.paymentTransaction.setTransactionID(orderNumber);
                    Transaction.commit();
                } else if (paymentProcessor.ID.toLowerCase() === constants.CKO_KLARNA_PAYMENTINSTRUMENT.toLowerCase() && !authorizeKlarna) {
                    result.action = true;
                    break;
                } else {
                    if (HookMgr.hasHook('app.payment.processor.' +
                            paymentProcessor.ID.toLowerCase())) {
                        Transaction.wrap(function() {
                            /* eslint-disable no-param-reassign */
                            order.custom.orderProcessedByABCorNAS = ckoHelper.getNasEnabled();
                        });

                        authorizationResult = HookMgr.callHook(
                            'app.payment.processor.' + paymentProcessor.ID.toLowerCase(),
                            'Authorize',
                            orderNumber,
                            paymentInstrument,
                            paymentProcessor
                        );
                    } else {
                        authorizationResult = HookMgr.callHook(
                            'app.payment.processor.default',
                            'Authorize'
                        );
                    }

                    if (authorizationResult.error) {
                        Transaction.wrap(function() { OrderMgr.failOrder(order, true); });
                        result.error = true;
                        break;
                    } else {
                        result = authorizationResult;
                    }
                }
            }
        }
    }

    return result;
}

/**
 * saves payment instruemnt to customers wallet
 * @param {Object} billingData - billing information entered by the user
 * @param {dw.order.Basket} currentBasket - The current basket
 * @param {dw.customer.Customer} customer - The current customer
 * @returns {dw.customer.CustomerPaymentInstrument} newly stored payment Instrument
 */
function savePaymentInstrumentToWallet(billingData, currentBasket, customer) {
    var wallet = customer.getProfile().getWallet();

    return Transaction.wrap(function() {
        var storedPaymentInstrument = wallet.createPaymentInstrument(PaymentInstrument.METHOD_CREDIT_CARD);

        storedPaymentInstrument.setCreditCardHolder(
            currentBasket.billingAddress.fullName
        );
        storedPaymentInstrument.setCreditCardNumber(
            billingData.paymentInformation.cardNumber.value
        );
        storedPaymentInstrument.setCreditCardType(
            billingData.paymentInformation.cardType.value
        );
        storedPaymentInstrument.setCreditCardExpirationMonth(
            billingData.paymentInformation.expirationMonth.value
        );
        storedPaymentInstrument.setCreditCardExpirationYear(
            billingData.paymentInformation.expirationYear.value
        );

        var processor = PaymentMgr.getPaymentMethod(PaymentInstrument.METHOD_CREDIT_CARD).getPaymentProcessor();
        var token;
        var currentPaymentInstrument = currentBasket.getPaymentInstruments(PaymentInstrument.METHOD_CREDIT_CARD)[0];
        var creditCardToken = currentPaymentInstrument.getCreditCardToken();
        var creditCardBin = (currentPaymentInstrument.custom && currentPaymentInstrument.custom.ckoPaymentData) ? JSON.parse(currentPaymentInstrument.custom.ckoPaymentData).cardBin : null;
        if(creditCardToken && creditCardBin) {
            token = {
                sourceId: creditCardToken,
                bin: creditCardBin
            };
        } else {
            token = HookMgr.callHook(
                'app.payment.processor.' + processor.ID.toLowerCase(),
                'createToken',
                {
                    cardNumber: billingData.paymentInformation.cardNumber.value,
                    expirationMonth: billingData.paymentInformation.expirationMonth.value,
                    expirationYear: billingData.paymentInformation.expirationYear.value,
                    name: currentBasket.billingAddress.fullName,
                    email: currentBasket.getCustomerEmail(),
                }
            );
        }


        storedPaymentInstrument.setCreditCardToken(token.sourceId);
        storedPaymentInstrument.custom.ckoCreditCardBin = token.bin;

        return storedPaymentInstrument;
    });
}

/**
 * Validates payment instruments against applicable payment methods.
 *
 * Overrides the base SFRA implementation to use billing address country code
 * instead of req.geolocation.countryCode (IP-based). This ensures
 * country-restricted payment methods (CHECKOUTCOM_BIZUM → ES,
 * CHECKOUTCOM_MBWAY → PT) are correctly included in the applicable set when
 * the shopper has selected a valid billing address, regardless of their IP.
 *
 * @param {Object} req - the request object
 * @param {dw.order.Basket} currentBasket - The current basket
 * @returns {Object} result object with error flag
 */
function validatePayment(req, currentBasket) {
    var applicablePaymentCards;
    var applicablePaymentMethods;
    var creditCardPaymentMethod = PaymentMgr.getPaymentMethod(PaymentInstrument.METHOD_CREDIT_CARD);
    var paymentAmount = currentBasket.totalGrossPrice.value;
    var currentCustomer = req.currentCustomer.raw;
    var paymentInstruments = currentBasket.paymentInstruments;
    var result = {};

    // Use billing address country when available; fall back to IP geolocation.
    var countryCode = (currentBasket.billingAddress && currentBasket.billingAddress.countryCode)
        ? currentBasket.billingAddress.countryCode.value
        : req.geolocation.countryCode;

    applicablePaymentMethods = PaymentMgr.getApplicablePaymentMethods(
        currentCustomer,
        countryCode,
        paymentAmount
    );
    applicablePaymentCards = creditCardPaymentMethod
        ? creditCardPaymentMethod.getApplicablePaymentCards(currentCustomer, countryCode, paymentAmount)
        : new dw.util.ArrayList();

    var invalid = true;

    for (var i = 0; i < paymentInstruments.length; i++) {
        var paymentInstrument = paymentInstruments[i];

        if (PaymentInstrument.METHOD_GIFT_CERTIFICATE.equals(paymentInstrument.paymentMethod)) {
            invalid = false;
        }

        var paymentMethod = PaymentMgr.getPaymentMethod(paymentInstrument.getPaymentMethod());

        if (paymentMethod && applicablePaymentMethods.contains(paymentMethod)) {
            if (PaymentInstrument.METHOD_CREDIT_CARD.equals(paymentInstrument.paymentMethod)) {
                var card = PaymentMgr.getPaymentCard(paymentInstrument.creditCardType);

                if (card && applicablePaymentCards.contains(card)) {
                    invalid = false;
                }
            } else {
                invalid = false;
            }
        }

        if (invalid) {
            break;
        }
    }

    result.error = invalid;
    return result;
}

checkoutHelper.handlePayments = handlePayments;
checkoutHelper.savePaymentInstrumentToWallet = savePaymentInstrumentToWallet;
checkoutHelper.validatePayment = validatePayment;

module.exports = checkoutHelper;
