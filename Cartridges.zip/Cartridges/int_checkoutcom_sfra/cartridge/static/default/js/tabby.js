/******/ (function() { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 17:
/***/ (function(module) {



function createTabbyContext() {
  var tabbyContextUrl = $('.tabbyCreateContextUrl').val();
  if (!tabbyContextUrl) {
    return;
  }
  var csrfToken = $('#tabby-content input[name="csrf_token"]').val();
  $.ajax({
    url: tabbyContextUrl,
    method: 'POST',
    dataType: 'json',
    data: {
      csrf_token: csrfToken
    },
    success: function success(response) {
      if (response && response.success) {
        $('button.submit-payment').prop('disabled', false).removeClass('disabled');
        $('.tabby-content .invalid-field-message').text('').hide();
        $('.tabby-tab').removeClass('disable-tabby-checkout');
      } else {
        showTabbyError(response && response.message);
      }
    },
    error: function error(xhr) {
      var msg = xhr.responseJSON && xhr.responseJSON.message ? xhr.responseJSON.message : '';
      showTabbyError(msg);
    }
  });
}
function showTabbyError(message) {
  $('.tabby-content .invalid-field-message').text(message || '').show();
  $('.tabby-tab').addClass('disable-tabby-checkout');
  if ($('.tabby-tab').hasClass('active')) {
    $('button.submit-payment').prop('disabled', true).addClass('disabled');
  }
}
$(document).on('click touch', '.payment-options a.nav-link', function () {
  if ($(this).hasClass('tabby-tab') && $(this).hasClass('disable-tabby-checkout')) {
    $('button.submit-payment').prop('disabled', true).addClass('disabled');
  } else if (!$(this).hasClass('tabby-tab') && $('.tabby-content').length) {
    $('button.submit-payment').prop('disabled', false).removeClass('disabled');
  }
});
$(document).ready(function () {
  var checkoutStage = $('.data-checkout-stage').data('checkout-stage');
  var isTabbyEnabled = $('.tabby-tab').length > 0;
  if ((checkoutStage === 'payment' || checkoutStage === 'placeOrder') && isTabbyEnabled) {
    createTabbyContext();
  }
});
$('body').on('checkout:updateCheckoutView', function () {
  if ($('.tabby-tab').length > 0) {
    $('.tabby-tab').removeClass('disable-tabby-checkout');
    $('.tabby-content .invalid-field-message').text('').hide();
    createTabbyContext();
  }
});
module.exports = {
  createTabbyContext: createTabbyContext
};

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = __webpack_require__(17);
/******/ 	
/******/ })()
;