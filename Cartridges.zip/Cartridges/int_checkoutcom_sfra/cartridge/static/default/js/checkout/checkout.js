/******/ (function() { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ([
/* 0 */,
/* 1 */,
/* 2 */,
/* 3 */,
/* 4 */
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

/* eslint-disable no-redeclare */
/* eslint-disable block-scoped-var */
/* eslint-disable no-lonely-if */


function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return e; }; var t, e = {}, r = Object.prototype, n = r.hasOwnProperty, o = Object.defineProperty || function (t, e, r) { t[e] = r.value; }, i = "function" == typeof Symbol ? Symbol : {}, a = i.iterator || "@@iterator", c = i.asyncIterator || "@@asyncIterator", u = i.toStringTag || "@@toStringTag"; function define(t, e, r) { return Object.defineProperty(t, e, { value: r, enumerable: !0, configurable: !0, writable: !0 }), t[e]; } try { define({}, ""); } catch (t) { define = function define(t, e, r) { return t[e] = r; }; } function wrap(t, e, r, n) { var i = e && e.prototype instanceof Generator ? e : Generator, a = Object.create(i.prototype), c = new Context(n || []); return o(a, "_invoke", { value: makeInvokeMethod(t, r, c) }), a; } function tryCatch(t, e, r) { try { return { type: "normal", arg: t.call(e, r) }; } catch (t) { return { type: "throw", arg: t }; } } e.wrap = wrap; var h = "suspendedStart", l = "suspendedYield", f = "executing", s = "completed", y = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var p = {}; define(p, a, function () { return this; }); var d = Object.getPrototypeOf, v = d && d(d(values([]))); v && v !== r && n.call(v, a) && (p = v); var g = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(p); function defineIteratorMethods(t) { ["next", "throw", "return"].forEach(function (e) { define(t, e, function (t) { return this._invoke(e, t); }); }); } function AsyncIterator(t, e) { function invoke(r, o, i, a) { var c = tryCatch(t[r], t, o); if ("throw" !== c.type) { var u = c.arg, h = u.value; return h && "object" == _typeof(h) && n.call(h, "__await") ? e.resolve(h.__await).then(function (t) { invoke("next", t, i, a); }, function (t) { invoke("throw", t, i, a); }) : e.resolve(h).then(function (t) { u.value = t, i(u); }, function (t) { return invoke("throw", t, i, a); }); } a(c.arg); } var r; o(this, "_invoke", { value: function value(t, n) { function callInvokeWithMethodAndArg() { return new e(function (e, r) { invoke(t, n, e, r); }); } return r = r ? r.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(e, r, n) { var o = h; return function (i, a) { if (o === f) throw Error("Generator is already running"); if (o === s) { if ("throw" === i) throw a; return { value: t, done: !0 }; } for (n.method = i, n.arg = a;;) { var c = n.delegate; if (c) { var u = maybeInvokeDelegate(c, n); if (u) { if (u === y) continue; return u; } } if ("next" === n.method) n.sent = n._sent = n.arg;else if ("throw" === n.method) { if (o === h) throw o = s, n.arg; n.dispatchException(n.arg); } else "return" === n.method && n.abrupt("return", n.arg); o = f; var p = tryCatch(e, r, n); if ("normal" === p.type) { if (o = n.done ? s : l, p.arg === y) continue; return { value: p.arg, done: n.done }; } "throw" === p.type && (o = s, n.method = "throw", n.arg = p.arg); } }; } function maybeInvokeDelegate(e, r) { var n = r.method, o = e.iterator[n]; if (o === t) return r.delegate = null, "throw" === n && e.iterator.return && (r.method = "return", r.arg = t, maybeInvokeDelegate(e, r), "throw" === r.method) || "return" !== n && (r.method = "throw", r.arg = new TypeError("The iterator does not provide a '" + n + "' method")), y; var i = tryCatch(o, e.iterator, r.arg); if ("throw" === i.type) return r.method = "throw", r.arg = i.arg, r.delegate = null, y; var a = i.arg; return a ? a.done ? (r[e.resultName] = a.value, r.next = e.nextLoc, "return" !== r.method && (r.method = "next", r.arg = t), r.delegate = null, y) : a : (r.method = "throw", r.arg = new TypeError("iterator result is not an object"), r.delegate = null, y); } function pushTryEntry(t) { var e = { tryLoc: t[0] }; 1 in t && (e.catchLoc = t[1]), 2 in t && (e.finallyLoc = t[2], e.afterLoc = t[3]), this.tryEntries.push(e); } function resetTryEntry(t) { var e = t.completion || {}; e.type = "normal", delete e.arg, t.completion = e; } function Context(t) { this.tryEntries = [{ tryLoc: "root" }], t.forEach(pushTryEntry, this), this.reset(!0); } function values(e) { if (e || "" === e) { var r = e[a]; if (r) return r.call(e); if ("function" == typeof e.next) return e; if (!isNaN(e.length)) { var o = -1, i = function next() { for (; ++o < e.length;) if (n.call(e, o)) return next.value = e[o], next.done = !1, next; return next.value = t, next.done = !0, next; }; return i.next = i; } } throw new TypeError(_typeof(e) + " is not iterable"); } return GeneratorFunction.prototype = GeneratorFunctionPrototype, o(g, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), o(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, u, "GeneratorFunction"), e.isGeneratorFunction = function (t) { var e = "function" == typeof t && t.constructor; return !!e && (e === GeneratorFunction || "GeneratorFunction" === (e.displayName || e.name)); }, e.mark = function (t) { return Object.setPrototypeOf ? Object.setPrototypeOf(t, GeneratorFunctionPrototype) : (t.__proto__ = GeneratorFunctionPrototype, define(t, u, "GeneratorFunction")), t.prototype = Object.create(g), t; }, e.awrap = function (t) { return { __await: t }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, c, function () { return this; }), e.AsyncIterator = AsyncIterator, e.async = function (t, r, n, o, i) { void 0 === i && (i = Promise); var a = new AsyncIterator(wrap(t, r, n, o), i); return e.isGeneratorFunction(r) ? a : a.next().then(function (t) { return t.done ? t.value : a.next(); }); }, defineIteratorMethods(g), define(g, u, "Generator"), define(g, a, function () { return this; }), define(g, "toString", function () { return "[object Generator]"; }), e.keys = function (t) { var e = Object(t), r = []; for (var n in e) r.push(n); return r.reverse(), function next() { for (; r.length;) { var t = r.pop(); if (t in e) return next.value = t, next.done = !1, next; } return next.done = !0, next; }; }, e.values = values, Context.prototype = { constructor: Context, reset: function reset(e) { if (this.prev = 0, this.next = 0, this.sent = this._sent = t, this.done = !1, this.delegate = null, this.method = "next", this.arg = t, this.tryEntries.forEach(resetTryEntry), !e) for (var r in this) "t" === r.charAt(0) && n.call(this, r) && !isNaN(+r.slice(1)) && (this[r] = t); }, stop: function stop() { this.done = !0; var t = this.tryEntries[0].completion; if ("throw" === t.type) throw t.arg; return this.rval; }, dispatchException: function dispatchException(e) { if (this.done) throw e; var r = this; function handle(n, o) { return a.type = "throw", a.arg = e, r.next = n, o && (r.method = "next", r.arg = t), !!o; } for (var o = this.tryEntries.length - 1; o >= 0; --o) { var i = this.tryEntries[o], a = i.completion; if ("root" === i.tryLoc) return handle("end"); if (i.tryLoc <= this.prev) { var c = n.call(i, "catchLoc"), u = n.call(i, "finallyLoc"); if (c && u) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } else if (c) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); } else { if (!u) throw Error("try statement without catch or finally"); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } } } }, abrupt: function abrupt(t, e) { for (var r = this.tryEntries.length - 1; r >= 0; --r) { var o = this.tryEntries[r]; if (o.tryLoc <= this.prev && n.call(o, "finallyLoc") && this.prev < o.finallyLoc) { var i = o; break; } } i && ("break" === t || "continue" === t) && i.tryLoc <= e && e <= i.finallyLoc && (i = null); var a = i ? i.completion : {}; return a.type = t, a.arg = e, i ? (this.method = "next", this.next = i.finallyLoc, y) : this.complete(a); }, complete: function complete(t, e) { if ("throw" === t.type) throw t.arg; return "break" === t.type || "continue" === t.type ? this.next = t.arg : "return" === t.type ? (this.rval = this.arg = t.arg, this.method = "return", this.next = "end") : "normal" === t.type && e && (this.next = e), y; }, finish: function finish(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.finallyLoc === t) return this.complete(r.completion, r.afterLoc), resetTryEntry(r), y; } }, catch: function _catch(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.tryLoc === t) { var n = r.completion; if ("throw" === n.type) { var o = n.arg; resetTryEntry(r); } return o; } } throw Error("illegal catch attempt"); }, delegateYield: function delegateYield(e, r, n) { return this.delegate = { iterator: values(e), resultName: r, nextLoc: n }, "next" === this.method && (this.arg = t), y; } }, e; }
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }
var customerHelpers = __webpack_require__(5);
var addressHelpers = __webpack_require__(9);
var shippingHelpers = __webpack_require__(10);
var billingHelpers = __webpack_require__(11);
var summaryHelpers = __webpack_require__(16);
var formHelpers = __webpack_require__(6);
var klarna = __webpack_require__(15);
var tabby = __webpack_require__(17);
var scrollAnimate = __webpack_require__(7);
var location = window.location;
var history = window.history;
var initiPaypalbutton = __webpack_require__(18);

/**
 * Initialize Checkout.com Risk.js.
 *
 * Loads Risk.js if enabled, retrieves NAS public key, 
 * and generates deviceSessionId for fraud assessment.
 */
var deviceSessionId;
var script = document.getElementById('risk-js');
if (script) {
  var publicKey = $('input[name="servicePublicKey"]').val();
  script.addEventListener('load', /*#__PURE__*/_asyncToGenerator(/*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
    var risk;
    return _regeneratorRuntime().wrap(function _callee$(_context) {
      while (1) switch (_context.prev = _context.next) {
        case 0:
          _context.next = 2;
          return window.Risk.create(publicKey);
        case 2:
          risk = _context.sent;
          _context.next = 5;
          return risk.publishRiskData();
        case 5:
          deviceSessionId = _context.sent;
        case 6:
        case "end":
          return _context.stop();
      }
    }, _callee);
  })));
}

/**
 * Create the jQuery Checkout Plugin.
 *
 * This jQuery plugin will be registered on the dom element in checkout.isml with the
 * id of "checkout-main".
 *
 * The checkout plugin will handle the different state the user interface is in as the user
 * progresses through the varying forms such as shipping and payment.
 *
 * Billing info and payment info are used a bit synonymously in this code.
 *
 */
(function ($) {
  $.fn.checkout = function () {
    // eslint-disable-line
    var plugin = this;

    //
    // Collect form data from user input
    //
    var formData = {
      // Customer Data
      customer: {},
      // Shipping Address
      shipping: {},
      // Billing Address
      billing: {},
      // Payment
      payment: {},
      // Gift Codes
      giftCode: {}
    };

    //
    // The different states/stages of checkout
    //
    var checkoutStages = ['customer', 'shipping', 'payment', 'placeOrder', 'submitted'];

    /**
     * Updates the URL to determine stage
     * @param {number} currentStage - The current stage the user is currently on in the checkout
     */
    function updateUrl(currentStage) {
      history.pushState(checkoutStages[currentStage], document.title, location.pathname + '?stage=' + checkoutStages[currentStage] + '#' + checkoutStages[currentStage]);
    }

    //
    // Local member methods of the Checkout plugin
    //
    var members = {
      // initialize the currentStage variable for the first time
      currentStage: 0,
      /**
       * Set or update the checkout stage (AKA the shipping, billing, payment, etc... steps)
       * @returns {Object} a promise
       */
      updateStage: function updateStage() {
        var stage = checkoutStages[members.currentStage];
        var defer = $.Deferred(); // eslint-disable-line

        if (stage === 'customer') {
          //
          // Clear Previous Errors
          //
          customerHelpers.methods.clearErrors();
          //
          // Submit the Customer Form
          //
          var customerFormSelector = customerHelpers.methods.isGuestFormActive() ? customerHelpers.vars.GUEST_FORM : customerHelpers.vars.REGISTERED_FORM;
          var customerForm = $(customerFormSelector);
          $.ajax({
            url: customerForm.attr('action'),
            type: 'post',
            data: customerForm.serialize(),
            success: function success(data) {
              if (data.redirectUrl) {
                window.location.href = data.redirectUrl;
              } else {
                customerHelpers.methods.customerFormResponse(defer, data);
              }
            },
            error: function error(err) {
              if (err.responseJSON && err.responseJSON.redirectUrl) {
                window.location.href = err.responseJSON.redirectUrl;
              }
              // Server error submitting form
              defer.reject(err.responseJSON);
            }
          });
          return defer;
        }
        if (stage === 'shipping') {
          //
          // Clear Previous Errors
          //
          formHelpers.clearPreviousErrors('.shipping-form');

          //
          // Submit the Shipping Address Form
          //
          var isMultiShip = $('#checkout-main').hasClass('multi-ship');
          var formSelector = isMultiShip ? '.multi-shipping .active form' : '.single-shipping .shipping-form';
          var form = $(formSelector);
          if (isMultiShip && form.length === 0) {
            // disable the next:Payment button here
            $('body').trigger('checkout:disableButton', '.next-step-button button');
            // in case the multi ship form is already submitted
            var url = $('#checkout-main').attr('data-checkout-get-url');
            $.ajax({
              url: url,
              method: 'GET',
              success: function success(data) {
                // enable the next:Payment button here
                $('body').trigger('checkout:enableButton', '.next-step-button button');
                if (!data.error) {
                  $('body').trigger('checkout:updateCheckoutView', {
                    order: data.order,
                    customer: data.customer
                  });
                  defer.resolve();
                } else if (data.message && $('.shipping-error .alert-danger').length < 1) {
                  var errorMsg = data.message;
                  var errorHtml = '<div class="alert alert-danger alert-dismissible valid-cart-error ' + 'fade show" role="alert">' + '<button type="button" class="close" data-dismiss="alert" aria-label="Close">' + '<span aria-hidden="true">&times;</span>' + '</button>' + errorMsg + '</div>';
                  $('.shipping-error').append(errorHtml);
                  scrollAnimate($('.shipping-error'));
                  defer.reject();
                } else if (data.redirectUrl) {
                  window.location.href = data.redirectUrl;
                }
              },
              error: function error() {
                // enable the next:Payment button here
                $('body').trigger('checkout:enableButton', '.next-step-button button');
                // Server error submitting form
                defer.reject();
              }
            });
          } else {
            var shippingFormData = form.serialize();
            $('body').trigger('checkout:serializeShipping', {
              form: form,
              data: shippingFormData,
              callback: function callback(data) {
                shippingFormData = data;
              }
            });
            // disable the next:Payment button here
            $('body').trigger('checkout:disableButton', '.next-step-button button');
            $.ajax({
              url: form.attr('action'),
              type: 'post',
              data: shippingFormData,
              success: function success(data) {
                // enable the next:Payment button here
                $('body').trigger('checkout:enableButton', '.next-step-button button');
                shippingHelpers.methods.shippingFormResponse(defer, data);
                klarna.initializeKlarna();
                if ($('.tabby-tab').length > 0) {
                  tabby.createTabbyContext();
                }
                if ($('.paypal-buttons').length === 0 && $('.payPal-tab').length > 0) {
                  initiPaypalbutton.initPayPalButton();
                }
              },
              error: function error(err) {
                // enable the next:Payment button here
                $('body').trigger('checkout:enableButton', '.next-step-button button');
                if (err.responseJSON && err.responseJSON.redirectUrl) {
                  window.location.href = err.responseJSON.redirectUrl;
                }
                // Server error submitting form
                defer.reject(err.responseJSON);
              }
            });
          }
          return defer;
        }
        if (stage === 'payment') {
          //
          // Submit the Billing Address Form
          //

          formHelpers.clearPreviousErrors('.payment-form');
          var billingAddressForm = $('#dwfrm_billing .billing-address-block :input').serialize();
          $('body').trigger('checkout:serializeBilling', {
            form: $('#dwfrm_billing .billing-address-block'),
            data: billingAddressForm,
            callback: function callback(data) {
              if (data) {
                billingAddressForm = data;
              }
            }
          });
          var contactInfoForm = $('#dwfrm_billing .contact-info-block :input').serialize();
          $('body').trigger('checkout:serializeBilling', {
            form: $('#dwfrm_billing .contact-info-block'),
            data: contactInfoForm,
            callback: function callback(data) {
              if (data) {
                contactInfoForm = data;
              }
            }
          });
          var activeTabId = $('.tab-pane.active').attr('id');
          var paymentInfoSelector = '#dwfrm_billing .' + activeTabId + ' .payment-form-fields :input';
          var paymentInfoForm = $(paymentInfoSelector).serialize();
          $('body').trigger('checkout:serializeBilling', {
            form: $(paymentInfoSelector),
            data: paymentInfoForm,
            callback: function callback(data) {
              if (data) {
                paymentInfoForm = data;
              }
            }
          });
          var paymentForm = billingAddressForm + '&' + contactInfoForm + '&' + paymentInfoForm;
          if ($('.data-checkout-stage').data('customer-type') === 'registered') {
            // if payment method is credit card
            if ($('.payment-information').data('payment-method-id') === 'CREDIT_CARD') {
              if (!$('.payment-information').data('is-new-payment')) {
                var cvvCode = $('.saved-payment-instrument.' + 'selected-payment .saved-payment-security-code').val();
                if (cvvCode === '') {
                  var cvvElement = $('.saved-payment-instrument.' + 'selected-payment ' + '.form-control');
                  cvvElement.addClass('is-invalid');
                  scrollAnimate(cvvElement);
                  defer.reject();
                  return defer;
                }
                var $savedPaymentInstrument = $('.saved-payment-instrument' + '.selected-payment');
                paymentForm += '&storedPaymentUUID=' + $savedPaymentInstrument.data('uuid');
                paymentForm += '&securityCode=' + cvvCode;
              }
            }
          }
          // disable the next:Place Order button here
          $('body').trigger('checkout:disableButton', '.next-step-button button');
          $.ajax({
            url: $('#dwfrm_billing').attr('action'),
            method: 'POST',
            data: paymentForm,
            success: function success(data) {
              // enable the next:Place Order button here
              $('body').trigger('checkout:enableButton', '.next-step-button button');
              // look for field validation errors
              if (data.error) {
                if (data.fieldErrors.length) {
                  data.fieldErrors.forEach(function (error) {
                    if (Object.keys(error).length) {
                      formHelpers.loadFormErrors('.payment-form', error);
                    }
                  });
                }
                if (data.serverErrors.length) {
                  data.serverErrors.forEach(function (error) {
                    $('.error-message').show();
                    $('.error-message-text').text(error);
                    scrollAnimate($('.error-message'));
                  });
                }
                if (data.cartError) {
                  window.location.href = data.redirectUrl;
                }
                defer.reject();
              } else {
                //
                // Populate the Address Summary
                //
                $('body').trigger('checkout:updateCheckoutView', {
                  order: data.order,
                  customer: data.customer
                });
                if (data.renderedPaymentInstruments) {
                  $('.stored-payments').empty().html(data.renderedPaymentInstruments);
                }
                if (data.customer.registeredUser && data.customer.customerPaymentInstruments.length) {
                  $('.cancel-new-payment').removeClass('checkout-hidden');
                }
                scrollAnimate();
                defer.resolve(data);
              }
            },
            error: function error(err) {
              // enable the next:Place Order button here
              $('body').trigger('checkout:enableButton', '.next-step-button button');
              if (err.responseJSON && err.responseJSON.redirectUrl) {
                window.location.href = err.responseJSON.redirectUrl;
              }
            }
          });
          return defer;
        } else if (stage === 'placeOrder') {
          // disable the placeOrder button here
          $('body').trigger('checkout:disableButton', '.next-step-button button');
          $.ajax({
            url: $('.place-order').data('action'),
            method: 'POST',
            data: {
              deviceSessionId: deviceSessionId
            },
            success: function success(data) {
              // enable the placeOrder button here
              $('body').trigger('checkout:enableButton', '.next-step-button button');
              if (data.error) {
                if (data.cartError) {
                  window.location.href = data.redirectUrl;
                  defer.reject();
                } else {
                  // go to appropriate stage and display error message
                  defer.reject(data);
                }
              } else {
                if (data.apm) {
                  var params = data.continueUrl.slice(data.continueUrl.indexOf('?') + 1).split('&');
                  var redirect = $('<form>').appendTo(document.body).attr({
                    method: 'GET',
                    action: data.continueUrl
                  });
                  Object.keys(params).forEach(function (keys) {
                    var param = params[keys].split('=');
                    $('<input>').appendTo(redirect).attr({
                      name: param[0],
                      value: param[1]
                    });
                  });
                  $('<input>').appendTo(redirect).attr({
                    name: 'orderID',
                    value: data.orderID
                  });
                  $('<input>').appendTo(redirect).attr({
                    name: 'orderToken',
                    value: data.orderToken
                  });
                  redirect.submit();
                  defer.resolve(data);
                } else if (data.order && data.action && data.order.orderNo) {
                  klarna.authorizeKlarna(data.order);
                } else {
                  var redirect = $('<form>').appendTo(document.body).attr({
                    method: 'POST',
                    action: data.continueUrl
                  });
                  $('<input>').appendTo(redirect).attr({
                    name: 'orderID',
                    value: data.orderID
                  });
                  $('<input>').appendTo(redirect).attr({
                    name: 'orderToken',
                    value: data.orderToken
                  });
                  redirect.submit();
                  defer.resolve(data);
                }
              }
            },
            error: function error() {
              // enable the placeOrder button here
              $('body').trigger('checkout:enableButton', $('.next-step-button button'));
            }
          });
          return defer;
        }
        var p = $('<div>').promise(); // eslint-disable-line
        setTimeout(function () {
          p.done(); // eslint-disable-line
        }, 500);
        return p; // eslint-disable-line
      },
      /**
       * Initialize the checkout stage.
       *
       * TODO: update this to allow stage to be set from server?
       */
      initialize: function initialize() {
        // set the initial state of checkout
        members.currentStage = checkoutStages.indexOf($('.data-checkout-stage').data('checkout-stage'));
        $(plugin).attr('data-checkout-stage', checkoutStages[members.currentStage]);
        $('body').on('click', '.submit-customer-login', function (e) {
          e.preventDefault();
          members.nextStage();
        });
        $('body').on('click', '.submit-customer', function (e) {
          e.preventDefault();
          members.nextStage();
        });

        //
        // Handle Payment option selection
        //
        $('input[name$="paymentMethod"]', plugin).on('change', function () {
          $('.credit-card-form').toggle($(this).val() === 'CREDIT_CARD');
        });

        //
        // Handle Next State button click
        //
        $(plugin).on('click', '.next-step-button button', function () {
          members.nextStage();
        });

        //
        // Handle Edit buttons on shipping and payment summary cards
        //
        $('.customer-summary .edit-button', plugin).on('click', function () {
          members.gotoStage('customer');
        });
        $('.shipping-summary .edit-button', plugin).on('click', function () {
          if (!$('#checkout-main').hasClass('multi-ship')) {
            $('body').trigger('shipping:selectSingleShipping');
          }
          members.gotoStage('shipping');
        });
        $('.payment-summary .edit-button', plugin).on('click', function () {
          members.gotoStage('payment');
        });
        $('#billingCountry').on('change', function () {
          klarna.initializeKlarna($('#billingCountry').val());
        });

        //
        // remember stage (e.g. shipping)
        //
        updateUrl(members.currentStage);

        //
        // Listen for foward/back button press and move to correct checkout-stage
        //
        $(window).on('popstate', function (e) {
          //
          // Back button when event state less than current state in ordered
          // checkoutStages array.
          //
          if (e.state === null || checkoutStages.indexOf(e.state) < members.currentStage) {
            members.handlePrevStage(false);
          } else if (checkoutStages.indexOf(e.state) > members.currentStage) {
            // Forward button  pressed
            members.handleNextStage(false);
          }
        });

        //
        // Set the form data
        //
        plugin.data('formData', formData);
      },
      /**
       * The next checkout state step updates the css for showing correct buttons etc...
       */
      nextStage: function nextStage() {
        var promise = members.updateStage();
        promise.done(function () {
          // Update UI with new stage
          $('.error-message').hide();
          members.handleNextStage(true);
        });
        promise.fail(function (data) {
          // show errors
          if (data) {
            if (data.errorStage) {
              members.gotoStage(data.errorStage.stage);
              if (data.errorStage.step === 'billingAddress') {
                var $billingAddressSameAsShipping = $('input[name$="_shippingAddressUseAsBillingAddress"]');
                if ($billingAddressSameAsShipping.is(':checked')) {
                  $billingAddressSameAsShipping.prop('checked', false);
                }
              }
            }
            if (data.errorMessage) {
              $('.error-message').show();
              $('.error-message-text').text(data.errorMessage);
            }
          }
        });
      },
      /**
       * The next checkout state step updates the css for showing correct buttons etc...
       *
       * @param {boolean} bPushState - boolean when true pushes state using the history api.
       */
      handleNextStage: function handleNextStage(bPushState) {
        if (members.currentStage < checkoutStages.length - 1) {
          // move stage forward
          members.currentStage++;

          //
          // show new stage in url (e.g.payment)
          //
          if (bPushState) {
            updateUrl(members.currentStage);
          }
        }

        // Set the next stage on the DOM
        $(plugin).attr('data-checkout-stage', checkoutStages[members.currentStage]);
      },
      /**
       * Previous State
       */
      handlePrevStage: function handlePrevStage() {
        if (members.currentStage > 0) {
          // move state back
          members.currentStage--;
          updateUrl(members.currentStage);
        }
        $(plugin).attr('data-checkout-stage', checkoutStages[members.currentStage]);
      },
      /**
       * Use window history to go to a checkout stage
       * @param {string} stageName - the checkout state to goto
       */
      gotoStage: function gotoStage(stageName) {
        members.currentStage = checkoutStages.indexOf(stageName);
        updateUrl(members.currentStage);
        $(plugin).attr('data-checkout-stage', checkoutStages[members.currentStage]);
      }
    };

    //
    // Initialize the checkout
    //
    members.initialize();
    return this;
  };
})(jQuery);
var exports = {
  showErrorMessage: function showErrorMessage() {
    var urlString = window.location.href;
    var url = new URL(urlString);
    var paymentError = url.searchParams.get('paymentError');
    if (paymentError) {
      $('.error-message').show();
      $('.error-message-text').text(paymentError);
    }
  },
  initialize: function initialize() {
    $('#checkout-main').checkout();
  },
  updateCheckoutView: function updateCheckoutView() {
    $('body').on('checkout:updateCheckoutView', function (e, data) {
      if (data.csrfToken) {
        $("input[name*='csrf_token']").val(data.csrfToken);
      }
      customerHelpers.methods.updateCustomerInformation(data.customer, data.order);
      shippingHelpers.methods.updateMultiShipInformation(data.order);
      summaryHelpers.updateTotals(data.order.totals);
      data.order.shipping.forEach(function (shipping) {
        shippingHelpers.methods.updateShippingInformation(shipping, data.order, data.customer, data.options);
      });
      billingHelpers.methods.updateBillingInformation(data.order, data.customer, data.options);
      billingHelpers.methods.updatePaymentInformation(data.order, data.options);
      summaryHelpers.updateOrderProductSummaryInformation(data.order, data.options);
      if (data && data.order && data.order.totalGrossPrice) {
        $('#ckoGooglePayAmount').val(data.order.totalGrossPrice);
      }
    });
  },
  disableButton: function disableButton() {
    $('body').on('checkout:disableButton', function (e, button) {
      $(button).prop('disabled', true);
    });
  },
  enableButton: function enableButton() {
    $('body').on('checkout:enableButton', function (e, button) {
      $(button).prop('disabled', false);
    });
  }
};
[customerHelpers, billingHelpers, shippingHelpers, addressHelpers].forEach(function (library) {
  Object.keys(library).forEach(function (item) {
    if (_typeof(library[item]) === 'object') {
      exports[item] = $.extend({}, exports[item], library[item]);
    } else {
      exports[item] = library[item];
    }
  });
});
module.exports = exports;

/***/ }),
/* 5 */
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {



var formHelpers = __webpack_require__(6);
var scrollAnimate = __webpack_require__(7);
var createErrorNotification = __webpack_require__(8);
var GUEST_FORM = '#guest-customer';
var REGISTERED_FORM = '#registered-customer';
var ERROR_SECTION = '.customer-error';

/**
 * @returns {boolean} If guest is active, registered is not visible
 */
function isGuestFormActive() {
  return $(REGISTERED_FORM).hasClass('d-none');
}

/**
 * Clear any previous errors in the customer form.
 */
function clearErrors() {
  $(ERROR_SECTION).children().remove();
  formHelpers.clearPreviousErrors('.customer-information-block');
}

/**
 * @param {Object} customerData - data includes checkout related customer information
 * @param {Object} orderData - data includes checkout related order information
 */
function updateCustomerInformation(customerData, orderData) {
  var $container = $('.customer-summary');
  var $summaryDetails = $container.find('.summary-details');
  var email = customerData.profile && customerData.profile.email ? customerData.profile.email : orderData.orderEmail;
  $summaryDetails.find('.customer-summary-email').text(email);
  if (customerData.registeredUser) {
    $container.find('.edit-button').hide();
  } else {
    $container.find('.edit-button').show();
  }
}

/**
 * Handle response from the server for valid or invalid form fields.
 * @param {Object} defer - the deferred object which will resolve on success or reject.
 * @param {Object} data - the response data with the invalid form fields or
 *  valid model data.
 */
function customerFormResponse(defer, data) {
  var parentForm = isGuestFormActive() ? GUEST_FORM : REGISTERED_FORM;
  var formSelector = '.customer-section ' + parentForm;

  // highlight fields with errors
  if (data.error) {
    if (data.fieldErrors.length) {
      data.fieldErrors.forEach(function (error) {
        if (Object.keys(error).length) {
          formHelpers.loadFormErrors(formSelector, error);
        }
      });
    }
    if (data.customerErrorMessage) {
      createErrorNotification(ERROR_SECTION, data.customerErrorMessage);
    }
    if (data.fieldErrors.length || data.customerErrorMessage || data.serverErrors && data.serverErrors.length) {
      defer.reject(data);
    }
    if (data.cartError) {
      window.location.href = data.redirectUrl;
      defer.reject();
    }
  } else {
    // Populate the Address Summary

    $('body').trigger('checkout:updateCheckoutView', {
      order: data.order,
      customer: data.customer,
      csrfToken: data.csrfToken
    });
    scrollAnimate($('.shipping-form'));
    defer.resolve(data);
  }
}

/**
 *
 * @param {boolean} registered - wether a registered login block will be used
 */
function chooseLoginBlock(registered) {
  $(ERROR_SECTION).find('.alert').remove();
  $('#password').val('');
  if (registered) {
    $(REGISTERED_FORM).removeClass('d-none');
    $(GUEST_FORM).addClass('d-none');
    $('#email').val($('#email-guest').val());
  } else {
    $(REGISTERED_FORM).addClass('d-none');
    $(GUEST_FORM).removeClass('d-none');
    $('#email').val('');
  }
}
module.exports = {
  /**
   * Listeners for customer form
   */
  initListeners: function initListeners() {
    // 1. password
    var customerLogin = '.js-login-customer';
    var cancelLogin = '.js-cancel-login';
    var registered;
    if (customerLogin.length !== 0) {
      $('body').on('click', customerLogin, function (e) {
        registered = true;
        e.preventDefault();
        chooseLoginBlock(registered);
      });
    }
    if (cancelLogin.length !== 0) {
      $('body').on('click', cancelLogin, function (e) {
        registered = false;
        e.preventDefault();
        chooseLoginBlock(registered);
      });
    }
  },
  methods: {
    clearErrors: clearErrors,
    updateCustomerInformation: updateCustomerInformation,
    customerFormResponse: customerFormResponse,
    isGuestFormActive: isGuestFormActive
  },
  vars: {
    GUEST_FORM: GUEST_FORM,
    REGISTERED_FORM: REGISTERED_FORM
  }
};

/***/ }),
/* 6 */
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {



var scrollAnimate = __webpack_require__(7);

/**
 * Display error messages and highlight form fields with errors.
 * @param {string} parentSelector - the form which contains the fields
 * @param {Object} fieldErrors - the fields with errors
 */
function loadFormErrors(parentSelector, fieldErrors) {
  // eslint-disable-line
  // Display error messages and highlight form fields with errors.
  $.each(fieldErrors, function (attr) {
    $('*[name=' + attr + ']', parentSelector).addClass('is-invalid').siblings('.invalid-feedback').html(fieldErrors[attr]);
  });
  // Animate to top of form that has errors
  scrollAnimate($(parentSelector));
}

/**
 * Clear the form errors.
 * @param {string} parentSelector - the parent form selector.
 */
function clearPreviousErrors(parentSelector) {
  $(parentSelector).find('.form-control.is-invalid').removeClass('is-invalid');
  $('.error-message').hide();
}
module.exports = {
  loadFormErrors: loadFormErrors,
  clearPreviousErrors: clearPreviousErrors
};

/***/ }),
/* 7 */
/***/ (function(module) {



module.exports = function (element) {
  var position = element && element.length ? element.offset().top : 0;
  $('html, body').animate({
    scrollTop: position
  }, 500);
  if (!element) {
    $('.logo-home').focus();
  }
};

/***/ }),
/* 8 */
/***/ (function(module) {



module.exports = function (element, message) {
  var errorHtml = '<div class="alert alert-danger alert-dismissible ' + 'fade show" role="alert">' + '<button type="button" class="close" data-dismiss="alert" aria-label="Close">' + '<span aria-hidden="true">&times;</span>' + '</button>' + message + '</div>';
  $(element).append(errorHtml);
};

/***/ }),
/* 9 */
/***/ (function(module) {



/**
 * Populate the Billing Address Summary View
 * @param {string} parentSelector - the top level DOM selector for a unique address summary
 * @param {Object} address - the address data
 */
function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
function populateAddressSummary(parentSelector, address) {
  $.each(address, function (attr) {
    var val = address[attr];
    $('.' + attr, parentSelector).text(val || '');
  });
}

/**
 * returns a formed <option /> element
 * @param {Object} shipping - the shipping object (shipment model)
 * @param {boolean} selected - current shipping is selected (for PLI)
 * @param {order} order - the Order model
 * @param {Object} [options] - options
 * @returns {Object} - the jQuery / DOMElement
 */
function optionValueForAddress(shipping, selected, order, options) {
  var safeOptions = options || {};
  var isBilling = safeOptions.type && safeOptions.type === 'billing';
  var className = safeOptions.className || '';
  var isSelected = selected;
  var isNew = !shipping;
  if (typeof shipping === 'string') {
    return $('<option class="' + className + '" disabled>' + shipping + '</option>');
  }
  var safeShipping = shipping || {};
  var shippingAddress = safeShipping.shippingAddress || {};
  if (isBilling && isNew && !order.billing.matchingAddressId) {
    shippingAddress = order.billing.billingAddress.address || {};
    isNew = false;
    isSelected = true;
    safeShipping.UUID = 'manual-entry';
  }
  var uuid = safeShipping.UUID ? safeShipping.UUID : 'new';
  var optionEl = $('<option class="' + className + '" />');
  optionEl.val(uuid);
  var title;
  if (isNew) {
    title = order.resources.addNewAddress;
  } else {
    title = [];
    if (shippingAddress.firstName) {
      title.push(shippingAddress.firstName);
    }
    if (shippingAddress.lastName) {
      title.push(shippingAddress.lastName);
    }
    if (shippingAddress.address1) {
      title.push(shippingAddress.address1);
    }
    if (shippingAddress.address2) {
      title.push(shippingAddress.address2);
    }
    if (shippingAddress.city) {
      if (shippingAddress.state) {
        title.push(shippingAddress.city + ',');
      } else {
        title.push(shippingAddress.city);
      }
    }
    if (shippingAddress.stateCode) {
      title.push(shippingAddress.stateCode);
    }
    if (shippingAddress.postalCode) {
      title.push(shippingAddress.postalCode);
    }
    if (!isBilling && safeShipping.selectedShippingMethod) {
      title.push('-');
      title.push(safeShipping.selectedShippingMethod.displayName);
    }
    if (title.length > 2) {
      title = title.join(' ');
    } else {
      title = order.resources.newAddress;
    }
  }
  optionEl.text(title);
  var keyMap = {
    'data-first-name': 'firstName',
    'data-last-name': 'lastName',
    'data-address1': 'address1',
    'data-address2': 'address2',
    'data-city': 'city',
    'data-state-code': 'stateCode',
    'data-postal-code': 'postalCode',
    'data-country-code': 'countryCode',
    'data-phone': 'phone'
  };
  $.each(keyMap, function (key) {
    var mappedKey = keyMap[key];
    var mappedValue = shippingAddress[mappedKey];
    // In case of country code
    if (mappedValue && _typeof(mappedValue) === 'object') {
      mappedValue = mappedValue.value;
    }
    optionEl.attr(key, mappedValue || '');
  });
  var giftObj = {
    'data-is-gift': 'isGift',
    'data-gift-message': 'giftMessage'
  };
  $.each(giftObj, function (key) {
    var mappedKey = giftObj[key];
    var mappedValue = safeShipping[mappedKey];
    optionEl.attr(key, mappedValue || '');
  });
  if (isSelected) {
    optionEl.attr('selected', true);
  }
  return optionEl;
}

/**
 * returns address properties from a UI form
 * @param {Form} form - the Form element
 * @returns {Object} - a JSON object with all values
 */
function getAddressFieldsFromUI(form) {
  var address = {
    firstName: $('input[name$=_firstName]', form).val(),
    lastName: $('input[name$=_lastName]', form).val(),
    address1: $('input[name$=_address1]', form).val(),
    address2: $('input[name$=_address2]', form).val(),
    city: $('input[name$=_city]', form).val(),
    postalCode: $('input[name$=_postalCode]', form).val(),
    stateCode: $('select[name$=_stateCode],input[name$=_stateCode]', form).val(),
    countryCode: $('select[name$=_country]', form).val(),
    phone: $('input[name$=_phone]', form).val()
  };
  return address;
}
module.exports = {
  methods: {
    populateAddressSummary: populateAddressSummary,
    optionValueForAddress: optionValueForAddress,
    getAddressFieldsFromUI: getAddressFieldsFromUI
  },
  showDetails: function showDetails() {
    $('.btn-show-details').on('click', function () {
      var form = $(this).closest('form');
      form.attr('data-address-mode', 'details');
      form.find('.multi-ship-address-actions').removeClass('d-none');
      form.find('.multi-ship-action-buttons .col-12.btn-save-multi-ship').addClass('d-none');
    });
  },
  addNewAddress: function addNewAddress() {
    $('.btn-add-new').on('click', function () {
      var $el = $(this);
      if ($el.parents('#dwfrm_billing').length > 0) {
        // Handle billing address case
        $('body').trigger('checkout:clearBillingForm');
        var $option = $($el.parents('form').find('.addressSelector option')[0]);
        $option.attr('value', 'new');
        var $newTitle = $('#dwfrm_billing input[name=localizedNewAddressTitle]').val();
        $option.text($newTitle);
        $option.prop('selected', 'selected');
        $el.parents('[data-address-mode]').attr('data-address-mode', 'new');
      } else {
        // Handle shipping address case
        var $newEl = $el.parents('form').find('.addressSelector option[value=new]');
        $newEl.prop('selected', 'selected');
        $newEl.parent().trigger('change');
      }
    });
  }
};

/***/ }),
/* 10 */
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {



function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
var addressHelpers = __webpack_require__(9);
var formHelpers = __webpack_require__(6);
var scrollAnimate = __webpack_require__(7);

/**
 * updates the shipping address selector within shipping forms
 * @param {Object} productLineItem - the productLineItem model
 * @param {Object} shipping - the shipping (shipment model) model
 * @param {Object} order - the order model
 * @param {Object} customer - the customer model
 */
function updateShippingAddressSelector(productLineItem, shipping, order, customer) {
  var uuidEl = $('input[value=' + productLineItem.UUID + ']');
  var shippings = order.shipping;
  var form;
  var $shippingAddressSelector;
  var hasSelectedAddress = false;
  if (uuidEl && uuidEl.length > 0) {
    form = uuidEl[0].form;
    $shippingAddressSelector = $('.addressSelector', form);
  }
  if ($shippingAddressSelector && $shippingAddressSelector.length === 1) {
    $shippingAddressSelector.empty();
    // Add New Address option
    $shippingAddressSelector.append(addressHelpers.methods.optionValueForAddress(null, false, order));
    if (customer.addresses && customer.addresses.length > 0) {
      $shippingAddressSelector.append(addressHelpers.methods.optionValueForAddress(order.resources.accountAddresses, false, order));
      customer.addresses.forEach(function (address) {
        var isSelected = shipping.matchingAddressId === address.ID;
        $shippingAddressSelector.append(addressHelpers.methods.optionValueForAddress({
          UUID: 'ab_' + address.ID,
          shippingAddress: address
        }, isSelected, order));
      });
    }
    // Separator -
    $shippingAddressSelector.append(addressHelpers.methods.optionValueForAddress(order.resources.shippingAddresses, false, order, {
      className: 'multi-shipping'
    }));
    shippings.forEach(function (aShipping) {
      var isSelected = shipping.UUID === aShipping.UUID;
      hasSelectedAddress = hasSelectedAddress || isSelected;
      var addressOption = addressHelpers.methods.optionValueForAddress(aShipping, isSelected, order, {
        className: 'multi-shipping'
      });
      var newAddress = addressOption.html() === order.resources.addNewAddress;
      var matchingUUID = aShipping.UUID === shipping.UUID;
      if (newAddress && matchingUUID || !newAddress && matchingUUID || !newAddress && !matchingUUID) {
        $shippingAddressSelector.append(addressOption);
      }
      if (newAddress && !matchingUUID) {
        $(addressOption[0]).remove();
      }
    });
  }
  if (!hasSelectedAddress) {
    // show
    $(form).addClass('hide-details');
  } else {
    $(form).removeClass('hide-details');
  }
  $('body').trigger('shipping:updateShippingAddressSelector', {
    productLineItem: productLineItem,
    shipping: shipping,
    order: order,
    customer: customer
  });
}

/**
 * updates the shipping address form values within shipping forms
 * @param {Object} shipping - the shipping (shipment model) model
 */
function updateShippingAddressFormValues(shipping) {
  var addressObject = $.extend({}, shipping.shippingAddress);
  if (!addressObject) {
    addressObject = {
      firstName: null,
      lastName: null,
      address1: null,
      address2: null,
      city: null,
      postalCode: null,
      stateCode: null,
      countryCode: null,
      phone: null
    };
  }
  addressObject.isGift = shipping.isGift;
  addressObject.giftMessage = shipping.giftMessage;
  $('input[value=' + shipping.UUID + ']').each(function (formIndex, el) {
    var form = el.form;
    if (!form) return;
    var countryCode = addressObject.countryCode;
    $('input[name$=_firstName]', form).val(addressObject.firstName);
    $('input[name$=_lastName]', form).val(addressObject.lastName);
    $('input[name$=_address1]', form).val(addressObject.address1);
    $('input[name$=_address2]', form).val(addressObject.address2);
    $('input[name$=_city]', form).val(addressObject.city);
    $('input[name$=_postalCode]', form).val(addressObject.postalCode);
    $('select[name$=_stateCode],input[name$=_stateCode]', form).val(addressObject.stateCode);
    if (countryCode && _typeof(countryCode) === 'object') {
      $('select[name$=_country]', form).val(addressObject.countryCode.value);
    } else {
      $('select[name$=_country]', form).val(addressObject.countryCode);
    }
    $('input[name$=_phone]', form).val(addressObject.phone);
    $('input[name$=_isGift]', form).prop('checked', addressObject.isGift);
    $('textarea[name$=_giftMessage]', form).val(addressObject.isGift && addressObject.giftMessage ? addressObject.giftMessage : '');
  });
  $('body').trigger('shipping:updateShippingAddressFormValues', {
    shipping: shipping
  });
}

/**
 * updates the shipping method radio buttons within shipping forms
 * @param {Object} shipping - the shipping (shipment model) model
 */
function updateShippingMethods(shipping) {
  var uuidEl = $('input[value=' + shipping.UUID + ']');
  if (uuidEl && uuidEl.length > 0) {
    $.each(uuidEl, function (shipmentIndex, el) {
      var form = el.form;
      if (!form) return;
      var $shippingMethodList = $('.shipping-method-list', form);
      if ($shippingMethodList && $shippingMethodList.length > 0) {
        $shippingMethodList.empty();
        var shippingMethods = shipping.applicableShippingMethods;
        var selected = shipping.selectedShippingMethod || {};
        var shippingMethodFormID = form.name + '_shippingAddress_shippingMethodID';
        //
        // Create the new rows for each shipping method
        //
        $.each(shippingMethods, function (methodIndex, shippingMethod) {
          var tmpl = $('#shipping-method-template').clone();
          var lineItemUUIDPart = '';
          if ($(el).parents('.multi-shipping').length) {
            lineItemUUIDPart = '-' + shipping.productLineItems.items[0].UUID;
          }

          // set input
          $('input', tmpl).prop('id', 'shippingMethod-' + shippingMethod.ID + '-' + shipping.UUID + lineItemUUIDPart).prop('name', shippingMethodFormID).prop('value', shippingMethod.ID).attr('checked', shippingMethod.ID === selected.ID);
          $('label', tmpl).prop('for', 'shippingMethod-' + shippingMethod.ID + '-' + shipping.UUID + lineItemUUIDPart);
          // set shipping method name
          $('.display-name', tmpl).text(shippingMethod.displayName);
          // set or hide arrival time
          if (shippingMethod.estimatedArrivalTime) {
            $('.arrival-time', tmpl).text('(' + shippingMethod.estimatedArrivalTime + ')').show();
          }
          // set shipping cost
          $('.shipping-cost', tmpl).text(shippingMethod.shippingCost);
          $shippingMethodList.append(tmpl.html());
        });
      }
    });
  }
  $('body').trigger('shipping:updateShippingMethods', {
    shipping: shipping
  });
}

/**
 * Update list of available shipping methods whenever user modifies shipping address details.
 * @param {jQuery} $shippingForm - current shipping form
 */
function updateShippingMethodList($shippingForm) {
  // delay for autocomplete!
  setTimeout(function () {
    var $shippingMethodList = $shippingForm.find('.shipping-method-list');
    var urlParams = addressHelpers.methods.getAddressFieldsFromUI($shippingForm);
    var shipmentUUID = $shippingForm.find('[name=shipmentUUID]').val();
    var url = $shippingMethodList.data('actionUrl');
    urlParams.shipmentUUID = shipmentUUID;
    $shippingMethodList.spinner().start();
    $.ajax({
      url: url,
      type: 'post',
      dataType: 'json',
      data: urlParams,
      success: function success(data) {
        if (data.error) {
          window.location.href = data.redirectUrl;
        } else {
          $('body').trigger('checkout:updateCheckoutView', {
            order: data.order,
            customer: data.customer,
            options: {
              keepOpen: true
            }
          });
          $shippingMethodList.spinner().stop();
        }
      }
    });
  }, 300);
}

/**
 * updates the order shipping summary for an order shipment model
 * @param {Object} shipping - the shipping (shipment model) model
 * @param {Object} order - the order model
 */
function updateShippingSummaryInformation(shipping, order) {
  $('[data-shipment-summary=' + shipping.UUID + ']').each(function (i, el) {
    var $container = $(el);
    var $shippingAddressLabel = $container.find('.shipping-addr-label');
    var $addressContainer = $container.find('.address-summary');
    var $shippingPhone = $container.find('.shipping-phone');
    var $methodTitle = $container.find('.shipping-method-title');
    var $methodArrivalTime = $container.find('.shipping-method-arrival-time');
    var $methodPrice = $container.find('.shipping-method-price');
    var $shippingSummaryLabel = $container.find('.shipping-method-label');
    var $summaryDetails = $container.find('.row.summary-details');
    var giftMessageSummary = $container.find('.gift-summary');
    var address = shipping.shippingAddress;
    var selectedShippingMethod = shipping.selectedShippingMethod;
    var isGift = shipping.isGift;
    addressHelpers.methods.populateAddressSummary($addressContainer, address);
    if (address && address.phone) {
      $shippingPhone.text(address.phone);
    } else {
      $shippingPhone.empty();
    }
    if (selectedShippingMethod) {
      $('body').trigger('shipping:updateAddressLabelText', {
        selectedShippingMethod: selectedShippingMethod,
        resources: order.resources,
        shippingAddressLabel: $shippingAddressLabel
      });
      $shippingSummaryLabel.show();
      $summaryDetails.show();
      $methodTitle.text(selectedShippingMethod.displayName);
      if (selectedShippingMethod.estimatedArrivalTime) {
        $methodArrivalTime.text('( ' + selectedShippingMethod.estimatedArrivalTime + ' )');
      } else {
        $methodArrivalTime.empty();
      }
      $methodPrice.text(selectedShippingMethod.shippingCost);
    }
    if (isGift) {
      giftMessageSummary.find('.gift-message-summary').text(shipping.giftMessage);
      giftMessageSummary.removeClass('d-none');
    } else {
      giftMessageSummary.addClass('d-none');
    }
  });
  $('body').trigger('shipping:updateShippingSummaryInformation', {
    shipping: shipping,
    order: order
  });
}

/**
 * Update the read-only portion of the shipment display (per PLI)
 * @param {Object} productLineItem - the productLineItem model
 * @param {Object} shipping - the shipping (shipment model) model
 * @param {Object} order - the order model
 * @param {Object} [options] - options for updating PLI summary info
 * @param {Object} [options.keepOpen] - if true, prevent changing PLI view mode to 'view'
 */
function updatePLIShippingSummaryInformation(productLineItem, shipping, order, options) {
  var $pli = $('input[value=' + productLineItem.UUID + ']');
  var form = $pli && $pli.length > 0 ? $pli[0].form : null;
  if (!form) return;
  var $viewBlock = $('.view-address-block', form);
  var address = shipping.shippingAddress || {};
  var selectedMethod = shipping.selectedShippingMethod;
  var nameLine = address.firstName ? address.firstName + ' ' : '';
  if (address.lastName) nameLine += address.lastName;
  var address1Line = address.address1;
  var address2Line = address.address2;
  var phoneLine = address.phone;
  var shippingCost = selectedMethod ? selectedMethod.shippingCost : '';
  var methodNameLine = selectedMethod ? selectedMethod.displayName : '';
  var methodArrivalTime = selectedMethod && selectedMethod.estimatedArrivalTime ? '(' + selectedMethod.estimatedArrivalTime + ')' : '';
  var tmpl = $('#pli-shipping-summary-template').clone();
  $('.ship-to-name', tmpl).text(nameLine);
  $('.ship-to-address1', tmpl).text(address1Line);
  $('.ship-to-address2', tmpl).text(address2Line);
  $('.ship-to-city', tmpl).text(address.city);
  if (address.stateCode) {
    $('.ship-to-st', tmpl).text(address.stateCode);
  }
  $('.ship-to-zip', tmpl).text(address.postalCode);
  $('.ship-to-phone', tmpl).text(phoneLine);
  if (!address2Line) {
    $('.ship-to-address2', tmpl).hide();
  }
  if (!phoneLine) {
    $('.ship-to-phone', tmpl).hide();
  }
  if (shipping.selectedShippingMethod) {
    $('.display-name', tmpl).text(methodNameLine);
    $('.arrival-time', tmpl).text(methodArrivalTime);
    $('.price', tmpl).text(shippingCost);
  }
  if (shipping.isGift) {
    $('.gift-message-summary', tmpl).text(shipping.giftMessage);
    var shipment = $('.gift-message-' + shipping.UUID);
    $(shipment).val(shipping.giftMessage);
  } else {
    $('.gift-summary', tmpl).addClass('d-none');
  }
  // checking h5 title shipping to or pickup
  var $shippingAddressLabel = $('.shipping-header-text', tmpl);
  $('body').trigger('shipping:updateAddressLabelText', {
    selectedShippingMethod: selectedMethod,
    resources: order.resources,
    shippingAddressLabel: $shippingAddressLabel
  });
  $viewBlock.html(tmpl.html());
  $('body').trigger('shipping:updatePLIShippingSummaryInformation', {
    productLineItem: productLineItem,
    shipping: shipping,
    order: order,
    options: options
  });
}

/**
 * Update the hidden form values that associate shipping info with product line items
 * @param {Object} productLineItem - the productLineItem model
 * @param {Object} shipping - the shipping (shipment model) model
 */
function updateProductLineItemShipmentUUIDs(productLineItem, shipping) {
  $('input[value=' + productLineItem.UUID + ']').each(function (key, pli) {
    var form = pli.form;
    $('[name=shipmentUUID]', form).val(shipping.UUID);
    $('[name=originalShipmentUUID]', form).val(shipping.UUID);
    $(form).closest('.card').attr('data-shipment-uuid', shipping.UUID);
  });
  $('body').trigger('shipping:updateProductLineItemShipmentUUIDs', {
    productLineItem: productLineItem,
    shipping: shipping
  });
}

/**
 * Update the shipping UI for a single shipping info (shipment model)
 * @param {Object} shipping - the shipping (shipment model) model
 * @param {Object} order - the order/basket model
 * @param {Object} customer - the customer model
 * @param {Object} [options] - options for updating PLI summary info
 * @param {Object} [options.keepOpen] - if true, prevent changing PLI view mode to 'view'
 */
function updateShippingInformation(shipping, order, customer, options) {
  // First copy over shipmentUUIDs from response, to each PLI form
  order.shipping.forEach(function (aShipping) {
    aShipping.productLineItems.items.forEach(function (productLineItem) {
      updateProductLineItemShipmentUUIDs(productLineItem, aShipping);
    });
  });

  // Now update shipping information, based on those associations
  updateShippingMethods(shipping);
  updateShippingAddressFormValues(shipping);
  updateShippingSummaryInformation(shipping, order);

  // And update the PLI-based summary information as well
  shipping.productLineItems.items.forEach(function (productLineItem) {
    updateShippingAddressSelector(productLineItem, shipping, order, customer);
    updatePLIShippingSummaryInformation(productLineItem, shipping, order, options);
  });
  $('body').trigger('shipping:updateShippingInformation', {
    order: order,
    shipping: shipping,
    customer: customer,
    options: options
  });
}

/**
 * Update the checkout state (single vs. multi-ship)
 * @param {Object} order - checkout model to use as basis of new truth
 */
function updateMultiShipInformation(order) {
  var $checkoutMain = $('#checkout-main');
  var $checkbox = $('[name=usingMultiShipping]');
  var $submitShippingBtn = $('button.submit-shipping');
  $('.shipping-error .alert-danger').remove();
  if (order.usingMultiShipping) {
    $checkoutMain.addClass('multi-ship');
    $checkbox.prop('checked', true);
  } else {
    $checkoutMain.removeClass('multi-ship');
    $checkbox.prop('checked', null);
    $submitShippingBtn.prop('disabled', null);
  }
  $('body').trigger('shipping:updateMultiShipInformation', {
    order: order
  });
}

/**
  * Create an alert to display the error message
  * @param {Object} message - Error message to display
  */
function createErrorNotification(message) {
  var errorHtml = '<div class="alert alert-danger alert-dismissible valid-cart-error ' + 'fade show" role="alert">' + '<button type="button" class="close" data-dismiss="alert" aria-label="Close">' + '<span aria-hidden="true">&times;</span>' + '</button>' + message + '</div>';
  $('.shipping-error').append(errorHtml);
  scrollAnimate($('.shipping-error'));
}

/**
 * Handle response from the server for valid or invalid form fields.
 * @param {Object} defer - the deferred object which will resolve on success or reject.
 * @param {Object} data - the response data with the invalid form fields or
 *  valid model data.
 */
function shippingFormResponse(defer, data) {
  var isMultiShip = $('#checkout-main').hasClass('multi-ship');
  var formSelector = isMultiShip ? '.multi-shipping .active form' : '.single-shipping form';

  // highlight fields with errors
  if (data.error) {
    if (data.fieldErrors.length) {
      data.fieldErrors.forEach(function (error) {
        if (Object.keys(error).length) {
          formHelpers.loadFormErrors(formSelector, error);
        }
      });
      defer.reject(data);
    }
    if (data.serverErrors && data.serverErrors.length) {
      $.each(data.serverErrors, function (index, element) {
        createErrorNotification(element);
      });
      defer.reject(data);
    }
    if (data.cartError) {
      window.location.href = data.redirectUrl;
      defer.reject();
    }
  } else {
    // Populate the Address Summary

    $('body').trigger('checkout:updateCheckoutView', {
      order: data.order,
      customer: data.customer
    });
    scrollAnimate($('.payment-form'));
    defer.resolve(data);
  }
}
/**
 * Clear out all the shipping form values and select the new address in the drop down
 * @param {Object} order - the order object
 */
function clearShippingForms(order) {
  order.shipping.forEach(function (shipping) {
    $('input[value=' + shipping.UUID + ']').each(function (formIndex, el) {
      var form = el.form;
      if (!form) return;
      $('input[name$=_firstName]', form).val('');
      $('input[name$=_lastName]', form).val('');
      $('input[name$=_address1]', form).val('');
      $('input[name$=_address2]', form).val('');
      $('input[name$=_city]', form).val('');
      $('input[name$=_postalCode]', form).val('');
      $('select[name$=_stateCode],input[name$=_stateCode]', form).val('');
      $('select[name$=_country]', form).val('');
      $('input[name$=_phone]', form).val('');
      $('input[name$=_isGift]', form).prop('checked', false);
      $('textarea[name$=_giftMessage]', form).val('');
      $(form).find('.gift-message').addClass('d-none');
      $(form).attr('data-address-mode', 'new');
      var addressSelectorDropDown = $('.addressSelector option[value=new]', form);
      $(addressSelectorDropDown).prop('selected', true);
    });
  });
  $('body').trigger('shipping:clearShippingForms', {
    order: order
  });
}

/**
 * Does Ajax call to create a server-side shipment w/ pliUUID & URL
 * @param {string} url - string representation of endpoint URL
 * @param {Object} shipmentData - product line item UUID
 * @returns {Object} - promise value for async call
 */
function createNewShipment(url, shipmentData) {
  $.spinner().start();
  return $.ajax({
    url: url,
    type: 'post',
    dataType: 'json',
    data: shipmentData
  });
}

/**
 * Does Ajax call to select shipping method
 * @param {string} url - string representation of endpoint URL
 * @param {Object} urlParams - url params
 * @param {Object} el - element that triggered this call
 */
function selectShippingMethodAjax(url, urlParams, el) {
  $.spinner().start();
  $('body').trigger('checkout:beforeShippingMethodSelected');
  $.ajax({
    url: url,
    type: 'post',
    dataType: 'json',
    data: urlParams
  }).done(function (data) {
    if (data.error) {
      window.location.href = data.redirectUrl;
    } else {
      $('body').trigger('checkout:updateCheckoutView', {
        order: data.order,
        customer: data.customer,
        options: {
          keepOpen: true
        },
        urlParams: urlParams
      });
      $('body').trigger('checkout:postUpdateCheckoutView', {
        el: el
      });
    }
    $('body').trigger('checkout:shippingMethodSelected', data);
    $.spinner().stop();
  }).fail(function () {
    $.spinner().stop();
  });
}

/**
 * Hide and show to appropriate elements to show the multi ship shipment cards in the enter view
 * @param {jQuery} element - The shipping content
 */
function enterMultishipView(element) {
  element.find('.btn-enter-multi-ship').removeClass('d-none');
  element.find('.view-address-block').addClass('d-none');
  element.find('.shipping-address').addClass('d-none');
  element.find('.btn-save-multi-ship.save-shipment').addClass('d-none');
  element.find('.btn-edit-multi-ship').addClass('d-none');
  element.find('.multi-ship-address-actions').addClass('d-none');
}

/**
 * Hide and show to appropriate elements to show the multi ship shipment cards in the view mode
 * @param {jQuery} element - The shipping content
 */
function viewMultishipAddress(element) {
  element.find('.view-address-block').removeClass('d-none');
  element.find('.btn-edit-multi-ship').removeClass('d-none');
  element.find('.shipping-address').addClass('d-none');
  element.find('.btn-save-multi-ship.save-shipment').addClass('d-none');
  element.find('.btn-enter-multi-ship').addClass('d-none');
  element.find('.multi-ship-address-actions').addClass('d-none');
}

/**
 * Hide and show to appropriate elements that allows the user to edit multi ship address information
 * @param {jQuery} element - The shipping content
 */
function editMultiShipAddress(element) {
  // Show
  element.find('.shipping-address').removeClass('d-none');
  element.find('.btn-save-multi-ship.save-shipment').removeClass('d-none');

  // Hide
  element.find('.view-address-block').addClass('d-none');
  element.find('.btn-enter-multi-ship').addClass('d-none');
  element.find('.btn-edit-multi-ship').addClass('d-none');
  element.find('.multi-ship-address-actions').addClass('d-none');
  $('body').trigger('shipping:editMultiShipAddress', {
    element: element,
    form: element.find('.shipping-form')
  });
}

/**
 * perform the proper actions once a user has clicked enter address or edit address for a shipment
 * @param {jQuery} element - The shipping content
 * @param {string} mode - the address mode
 */
function editOrEnterMultiShipInfo(element, mode) {
  var form = $(element).closest('form');
  var root = $(element).closest('.shipping-content');
  $('body').trigger('shipping:updateDataAddressMode', {
    form: form,
    mode: mode
  });
  editMultiShipAddress(root);
  var addressInfo = addressHelpers.methods.getAddressFieldsFromUI(form);
  var savedState = {
    UUID: $('input[name=shipmentUUID]', form).val(),
    shippingAddress: addressInfo
  };
  root.data('saved-state', JSON.stringify(savedState));
}
module.exports = {
  methods: {
    updateShippingAddressSelector: updateShippingAddressSelector,
    updateShippingAddressFormValues: updateShippingAddressFormValues,
    updateShippingMethods: updateShippingMethods,
    updateShippingSummaryInformation: updateShippingSummaryInformation,
    updatePLIShippingSummaryInformation: updatePLIShippingSummaryInformation,
    updateProductLineItemShipmentUUIDs: updateProductLineItemShipmentUUIDs,
    updateShippingInformation: updateShippingInformation,
    updateMultiShipInformation: updateMultiShipInformation,
    shippingFormResponse: shippingFormResponse,
    createNewShipment: createNewShipment,
    selectShippingMethodAjax: selectShippingMethodAjax,
    updateShippingMethodList: updateShippingMethodList,
    clearShippingForms: clearShippingForms,
    editMultiShipAddress: editMultiShipAddress,
    editOrEnterMultiShipInfo: editOrEnterMultiShipInfo,
    createErrorNotification: createErrorNotification,
    viewMultishipAddress: viewMultishipAddress
  },
  selectShippingMethod: function selectShippingMethod() {
    var baseObj = this;
    $('.shipping-method-list').change(function () {
      var $shippingForm = $(this).parents('form');
      var methodID = $(':checked', this).val();
      var shipmentUUID = $shippingForm.find('[name=shipmentUUID]').val();
      var urlParams = addressHelpers.methods.getAddressFieldsFromUI($shippingForm);
      urlParams.shipmentUUID = shipmentUUID;
      urlParams.methodID = methodID;
      urlParams.isGift = $shippingForm.find('.gift').prop('checked');
      urlParams.giftMessage = $shippingForm.find('textarea[name$=_giftMessage]').val();
      var url = $(this).data('select-shipping-method-url');
      if (baseObj.methods && baseObj.methods.selectShippingMethodAjax) {
        baseObj.methods.selectShippingMethodAjax(url, urlParams, $(this));
      } else {
        selectShippingMethodAjax(url, urlParams, $(this));
      }
    });
  },
  toggleMultiship: function toggleMultiship() {
    var baseObj = this;
    $('input[name="usingMultiShipping"]').on('change', function () {
      var url = $('.multi-shipping-checkbox-block form').attr('action');
      var usingMultiShip = this.checked;
      $.ajax({
        url: url,
        type: 'post',
        dataType: 'json',
        data: {
          usingMultiShip: usingMultiShip
        },
        success: function success(response) {
          if (response.error) {
            window.location.href = response.redirectUrl;
          } else {
            $('body').trigger('checkout:updateCheckoutView', {
              order: response.order,
              customer: response.customer
            });
            if ($('#checkout-main').data('customer-type') === 'guest') {
              if (baseObj.methods && baseObj.methods.clearShippingForms) {
                baseObj.methods.clearShippingForms(response.order);
              } else {
                clearShippingForms(response.order);
              }
            } else {
              response.order.shipping.forEach(function (shipping) {
                $('input[value=' + shipping.UUID + ']').each(function (formIndex, el) {
                  var form = el.form;
                  if (!form) return;
                  $(form).attr('data-address-mode', 'edit');
                  var addressSelectorDropDown = $(form).find('.addressSelector option[value="ab_' + shipping.matchingAddressId + '"]');
                  $(addressSelectorDropDown).prop('selected', true);
                  $('input[name$=_isGift]', form).prop('checked', false);
                  $('textarea[name$=_giftMessage]', form).val('');
                  $(form).find('.gift-message').addClass('d-none');
                });
              });
            }
            if (usingMultiShip) {
              $('body').trigger('shipping:selectMultiShipping', {
                data: response
              });
            } else {
              $('body').trigger('shipping:selectSingleShipping', {
                data: response
              });
            }
          }
          $.spinner().stop();
        },
        error: function error() {
          $.spinner().stop();
        }
      });
    });
  },
  selectSingleShipping: function selectSingleShipping() {
    $('body').on('shipping:selectSingleShipping', function () {
      $('.single-shipping .shipping-address').removeClass('d-none');
    });
  },
  selectMultiShipping: function selectMultiShipping() {
    var baseObj = this;
    $('body').on('shipping:selectMultiShipping', function (e, data) {
      $('.multi-shipping .shipping-address').addClass('d-none');
      data.data.order.shipping.forEach(function (shipping) {
        var element = $('.multi-shipping .card[data-shipment-uuid="' + shipping.UUID + '"]');
        if (shipping.shippingAddress) {
          if (baseObj.methods && baseObj.methods.viewMultishipAddress) {
            baseObj.methods.viewMultishipAddress($(element));
          } else {
            viewMultishipAddress($(element));
          }
        } else {
          /* eslint-disable no-lonely-if */
          if (baseObj.methods && baseObj.methods.enterMultishipView) {
            baseObj.methods.enterMultishipView($(element));
          } else {
            enterMultishipView($(element));
          }
          /* eslint-enable no-lonely-if */
        }
      });
    });
  },
  selectSingleShipAddress: function selectSingleShipAddress() {
    $('.single-shipping .addressSelector').on('change', function () {
      var form = $(this).parents('form')[0];
      var selectedOption = $('option:selected', this);
      var attrs = selectedOption.data();
      var shipmentUUID = selectedOption[0].value;
      var originalUUID = $('input[name=shipmentUUID]', form).val();
      var element;
      Object.keys(attrs).forEach(function (attr) {
        element = attr === 'countryCode' ? 'country' : attr;
        $('[name$=' + element + ']', form).val(attrs[attr]);
      });
      $('[name$=stateCode]', form).trigger('change');
      if (shipmentUUID === 'new') {
        $(form).attr('data-address-mode', 'new');
        $(form).find('.shipping-address-block').removeClass('d-none');
      } else if (shipmentUUID === originalUUID) {
        $(form).attr('data-address-mode', 'shipment');
      } else if (shipmentUUID.indexOf('ab_') === 0) {
        $(form).attr('data-address-mode', 'customer');
      } else {
        $(form).attr('data-address-mode', 'edit');
      }
    });
  },
  selectMultiShipAddress: function selectMultiShipAddress() {
    var baseObj = this;
    $('.multi-shipping .addressSelector').on('change', function () {
      var form = $(this).closest('form');
      var selectedOption = $('option:selected', this);
      var attrs = selectedOption.data();
      var shipmentUUID = selectedOption[0].value;
      var originalUUID = $('input[name=shipmentUUID]', form).val();
      var pliUUID = $('input[name=productLineItemUUID]', form).val();
      var createNewShipmentScoped = baseObj.methods && baseObj.methods.createNewShipment ? baseObj.methods.createNewShipment : createNewShipment;
      var element;
      Object.keys(attrs).forEach(function (attr) {
        if (attr === 'isGift') {
          $('[name$=' + attr + ']', form).prop('checked', attrs[attr]);
          $('[name$=' + attr + ']', form).trigger('change');
        } else {
          element = attr === 'countryCode' ? 'country' : attr;
          $('[name$=' + element + ']', form).val(attrs[attr]);
        }
      });
      if (shipmentUUID === 'new' && pliUUID) {
        var createShipmentUrl = $(this).attr('data-create-shipment-url');
        createNewShipmentScoped(createShipmentUrl, {
          productLineItemUUID: pliUUID
        }).done(function (response) {
          $.spinner().stop();
          if (response.error) {
            if (response.redirectUrl) {
              window.location.href = response.redirectUrl;
            }
            return;
          }
          $('body').trigger('checkout:updateCheckoutView', {
            order: response.order,
            customer: response.customer,
            options: {
              keepOpen: true
            }
          });
          $(form).attr('data-address-mode', 'new');
        }).fail(function () {
          $.spinner().stop();
        });
      } else if (shipmentUUID === originalUUID) {
        $('select[name$=stateCode]', form).trigger('change');
        $(form).attr('data-address-mode', 'shipment');
      } else if (shipmentUUID.indexOf('ab_') === 0) {
        var url = $(form).attr('action');
        var serializedData = $(form).serialize();
        createNewShipmentScoped(url, serializedData).done(function (response) {
          $.spinner().stop();
          if (response.error) {
            if (response.redirectUrl) {
              window.location.href = response.redirectUrl;
            }
            return;
          }
          $('body').trigger('checkout:updateCheckoutView', {
            order: response.order,
            customer: response.customer,
            options: {
              keepOpen: true
            }
          });
          $(form).attr('data-address-mode', 'customer');
          var $rootEl = $(form).closest('.shipping-content');
          editMultiShipAddress($rootEl);
        }).fail(function () {
          $.spinner().stop();
        });
      } else {
        var updatePLIShipmentUrl = $(form).attr('action');
        var serializedAddress = $(form).serialize();
        createNewShipmentScoped(updatePLIShipmentUrl, serializedAddress).done(function (response) {
          $.spinner().stop();
          if (response.error) {
            if (response.redirectUrl) {
              window.location.href = response.redirectUrl;
            }
            return;
          }
          $('body').trigger('checkout:updateCheckoutView', {
            order: response.order,
            customer: response.customer,
            options: {
              keepOpen: true
            }
          });
          $(form).attr('data-address-mode', 'edit');
        }).fail(function () {
          $.spinner().stop();
        });
      }
    });
  },
  updateShippingList: function updateShippingList() {
    var baseObj = this;
    $('select[name$="shippingAddress_addressFields_states_stateCode"]').on('change', function (e) {
      if (baseObj.methods && baseObj.methods.updateShippingMethodList) {
        baseObj.methods.updateShippingMethodList($(e.currentTarget.form));
      } else {
        updateShippingMethodList($(e.currentTarget.form));
      }
    });
  },
  updateDataAddressMode: function updateDataAddressMode() {
    $('body').on('shipping:updateDataAddressMode', function (e, data) {
      $(data.form).attr('data-address-mode', data.mode);
    });
  },
  enterMultiShipInfo: function enterMultiShipInfo() {
    var baseObj = this;
    $('.btn-enter-multi-ship').on('click', function (e) {
      e.preventDefault();
      if (baseObj.methods && baseObj.methods.editOrEnterMultiShipInfo) {
        baseObj.methods.editOrEnterMultiShipInfo($(this), 'new');
      } else {
        editOrEnterMultiShipInfo($(this), 'new');
      }
    });
  },
  editMultiShipInfo: function editMultiShipInfo() {
    var baseObj = this;
    $('.btn-edit-multi-ship').on('click', function (e) {
      e.preventDefault();
      if (baseObj.methods && baseObj.methods.editOrEnterMultiShipInfo) {
        baseObj.methods.editOrEnterMultiShipInfo($(this), 'edit');
      } else {
        editOrEnterMultiShipInfo($(this), 'edit');
      }
    });
  },
  saveMultiShipInfo: function saveMultiShipInfo() {
    var baseObj = this;
    $('.btn-save-multi-ship').on('click', function (e) {
      e.preventDefault();

      // Save address to checkoutAddressBook
      var form = $(this).closest('form');
      var $rootEl = $(this).closest('.shipping-content');
      var data = $(form).serialize();
      var url = $(form).attr('action');
      $rootEl.spinner().start();
      $.ajax({
        url: url,
        type: 'post',
        dataType: 'json',
        data: data
      }).done(function (response) {
        formHelpers.clearPreviousErrors(form);
        if (response.error) {
          if (response.fieldErrors && response.fieldErrors.length) {
            response.fieldErrors.forEach(function (error) {
              if (Object.keys(error).length) {
                formHelpers.loadFormErrors(form, error);
              }
            });
          } else if (response.serverErrors && response.serverErrors.length) {
            $.each(response.serverErrors, function (index, element) {
              createErrorNotification(element);
            });
          } else if (response.redirectUrl) {
            window.location.href = response.redirectUrl;
          }
        } else {
          // Update UI from response
          $('body').trigger('checkout:updateCheckoutView', {
            order: response.order,
            customer: response.customer
          });
          if (baseObj.methods && baseObj.methods.viewMultishipAddress) {
            baseObj.methods.viewMultishipAddress($rootEl);
          } else {
            viewMultishipAddress($rootEl);
          }
        }
        if (response.order && response.order.shippable) {
          $('button.submit-shipping').attr('disabled', null);
        }
        $rootEl.spinner().stop();
      }).fail(function (err) {
        if (err.responseJSON.redirectUrl) {
          window.location.href = err.responseJSON.redirectUrl;
        }
        $rootEl.spinner().stop();
      });
      return false;
    });
  },
  cancelMultiShipAddress: function cancelMultiShipAddress() {
    var baseObj = this;
    $('.btn-cancel-multi-ship-address').on('click', function (e) {
      e.preventDefault();
      var form = $(this).closest('form');
      var $rootEl = $(this).closest('.shipping-content');
      var restoreState = $rootEl.data('saved-state');

      // Should clear out changes / restore previous state
      if (restoreState) {
        var restoreStateObj = JSON.parse(restoreState);
        var originalStateCode = restoreStateObj.shippingAddress.stateCode;
        var stateCode = $('[name$=_stateCode]', form).val();
        if (baseObj.methods && baseObj.methods.updateShippingAddressFormValues) {
          baseObj.methods.updateShippingAddressFormValues(restoreStateObj);
        } else {
          updateShippingAddressFormValues(restoreStateObj);
        }
        if (stateCode !== originalStateCode) {
          $('[data-action=save]', form).trigger('click');
        } else {
          $(form).attr('data-address-mode', 'edit');
          if (baseObj.methods && baseObj.methods.editMultiShipAddress) {
            baseObj.methods.editMultiShipAddress($rootEl);
          } else {
            editMultiShipAddress($rootEl);
          }
        }
      }
      return false;
    });
  },
  isGift: function isGift() {
    $('.gift').on('change', function (e) {
      e.preventDefault();
      var form = $(this).closest('form');
      if (this.checked) {
        $(form).find('.gift-message').removeClass('d-none');
      } else {
        $(form).find('.gift-message').addClass('d-none');
        $(form).find('.gift-message').val('');
      }
    });
  }
};

/***/ }),
/* 11 */
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {



var base = __webpack_require__(12);
var klarna = __webpack_require__(15);

/**
 * returns the payment method name
 * @param {Object} applicablePaymentMethods - applicable payment methods
 * @param {Object} selectedPaymentMethod - selected payment method
 * @returns {string} paymentMethodName - payment method name
 */
function getPaymentMethodName(applicablePaymentMethods, selectedPaymentMethod) {
  var paymentMethodName;
  for (var i = 0; i < applicablePaymentMethods.length; i += 1) {
    if (applicablePaymentMethods[i].ID === selectedPaymentMethod) {
      paymentMethodName = applicablePaymentMethods[i].name;
      break;
    }
  }
  return paymentMethodName;
}

/**
 * Updates the payment information in checkout, based on the supplied order model
 * @param {Object} order - checkout model to use as basis of new truth
 */
base.methods.updatePaymentInformation = function (order) {
  // update payment details
  var $paymentSummary = $('.payment-details');
  var htmlToAppend = '';
  var selectedPaymentInstrument;
  if (order.billing.payment && order.billing.payment.selectedPaymentInstruments && order.billing.payment.selectedPaymentInstruments.length > 0) {
    for (var i = 0; i < order.billing.payment.selectedPaymentInstruments.length; i += 1) {
      selectedPaymentInstrument = order.billing.payment.selectedPaymentInstruments[i];
    }
    // CREDIT_CARD
    if (selectedPaymentInstrument.paymentMethod === 'CREDIT_CARD') {
      htmlToAppend += '<span>' + order.resources.cardType + ' ' + selectedPaymentInstrument.type + '</span><div>' + selectedPaymentInstrument.maskedCreditCardNumber + '</div><div><span>' + order.resources.cardEnding + ' ' + selectedPaymentInstrument.expirationMonth + '/' + selectedPaymentInstrument.expirationYear + '</span></div>';
    } else {
      htmlToAppend += '<div><p>' + getPaymentMethodName(order.billing.payment.applicablePaymentMethods, selectedPaymentInstrument.paymentMethod) + '</p>' + '<p>' + order.priceTotal + '</p></div>';
    }
  }
  $paymentSummary.empty().append(htmlToAppend);
};
base.selectBillingAddress = function () {
  $('.payment-form .addressSelector').on('change', function () {
    var form = $(this).parents('form')[0];
    var selectedOption = $('option:selected', this);
    var optionID = selectedOption[0].value;
    if (optionID === 'new') {
      // Show Address
      $(form).attr('data-address-mode', 'new');
    } else {
      // Hide Address
      $(form).attr('data-address-mode', 'shipment');
    }

    // Copy fields
    var attrs = selectedOption.data();
    var element;

    // Customize Klarna to reload the widget
    // whenever the billing country changes through the address selector dropdown.

    var initKlarna = false;
    if (attrs.countryCode !== $('#billingCountry').val()) {
      initKlarna = true;
    }
    Object.keys(attrs).forEach(function (attr) {
      element = attr === 'countryCode' ? 'country' : attr;
      if (element === 'cardNumber') {
        $('.cardNumber').data('cleave').setRawValue(attrs[attr]);
      } else {
        $('[name$=' + element + ']', form).val(attrs[attr]);
      }
    });
    if (initKlarna) {
      klarna.initializeKlarna($('#billingCountry').val());
    }
  });
};
module.exports = base;

/***/ }),
/* 12 */
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {



var addressHelpers = __webpack_require__(9);
var cleave = __webpack_require__(13);

/**
 * updates the billing address selector within billing forms
 * @param {Object} order - the order model
 * @param {Object} customer - the customer model
 */
function updateBillingAddressSelector(order, customer) {
  var shippings = order.shipping;
  var form = $('form[name$=billing]')[0];
  var $billingAddressSelector = $('.addressSelector', form);
  var hasSelectedAddress = false;
  if ($billingAddressSelector && $billingAddressSelector.length === 1) {
    $billingAddressSelector.empty();
    // Add New Address option
    $billingAddressSelector.append(addressHelpers.methods.optionValueForAddress(null, false, order, {
      type: 'billing'
    }));

    // Separator -
    $billingAddressSelector.append(addressHelpers.methods.optionValueForAddress(order.resources.shippingAddresses, false, order, {
      // className: 'multi-shipping',
      type: 'billing'
    }));
    shippings.forEach(function (aShipping) {
      var isSelected = order.billing.matchingAddressId === aShipping.UUID;
      hasSelectedAddress = hasSelectedAddress || isSelected;
      // Shipping Address option
      $billingAddressSelector.append(addressHelpers.methods.optionValueForAddress(aShipping, isSelected, order, {
        // className: 'multi-shipping',
        type: 'billing'
      }));
    });
    if (customer.addresses && customer.addresses.length > 0) {
      $billingAddressSelector.append(addressHelpers.methods.optionValueForAddress(order.resources.accountAddresses, false, order));
      customer.addresses.forEach(function (address) {
        var isSelected = order.billing.matchingAddressId === address.ID;
        hasSelectedAddress = hasSelectedAddress || isSelected;
        // Customer Address option
        $billingAddressSelector.append(addressHelpers.methods.optionValueForAddress({
          UUID: 'ab_' + address.ID,
          shippingAddress: address
        }, isSelected, order, {
          type: 'billing'
        }));
      });
    }
  }
  if (hasSelectedAddress || !order.billing.matchingAddressId && order.billing.billingAddress.address) {
    // show
    $(form).attr('data-address-mode', 'edit');
  } else {
    $(form).attr('data-address-mode', 'new');
  }
  $billingAddressSelector.show();
}

/**
 * Updates the billing address form values within payment forms without any payment instrument validation
 * @param {Object} order - the order model
 */
function updateBillingAddress(order) {
  var billing = order.billing;
  if (!billing.billingAddress || !billing.billingAddress.address) return;
  var form = $('form[name=dwfrm_billing]');
  if (!form) return;
  $('input[name$=_firstName]', form).val(billing.billingAddress.address.firstName);
  $('input[name$=_lastName]', form).val(billing.billingAddress.address.lastName);
  $('input[name$=_address1]', form).val(billing.billingAddress.address.address1);
  $('input[name$=_address2]', form).val(billing.billingAddress.address.address2);
  $('input[name$=_city]', form).val(billing.billingAddress.address.city);
  $('input[name$=_postalCode]', form).val(billing.billingAddress.address.postalCode);
  $('select[name$=_stateCode],input[name$=_stateCode]', form).val(billing.billingAddress.address.stateCode);
  $('select[name$=_country]', form).val(billing.billingAddress.address.countryCode.value);
  $('input[name$=_phone]', form).val(billing.billingAddress.address.phone);
  $('input[name$=_email]', form).val(order.orderEmail);
}

/**
 * Validate and update payment instrument form fields
 * @param {Object} order - the order model
 */
function validateAndUpdateBillingPaymentInstrument(order) {
  var billing = order.billing;
  if (!billing.payment || !billing.payment.selectedPaymentInstruments || billing.payment.selectedPaymentInstruments.length <= 0) return;
  var form = $('form[name=dwfrm_billing]');
  if (!form) return;
  var instrument = billing.payment.selectedPaymentInstruments[0];
  $('select[name$=expirationMonth]', form).val(instrument.expirationMonth);
  $('select[name$=expirationYear]', form).val(instrument.expirationYear);
  // Force security code and card number clear
  $('input[name$=securityCode]', form).val('');
  $('input[name$=cardNumber]').data('cleave').setRawValue('');
}

/**
 * Updates the billing address form values within payment forms
 * @param {Object} order - the order model
 */
function updateBillingAddressFormValues(order) {
  module.exports.methods.updateBillingAddress(order);
  module.exports.methods.validateAndUpdateBillingPaymentInstrument(order);
}

/**
 * clears the billing address form values
 */
function clearBillingAddressFormValues() {
  updateBillingAddressFormValues({
    billing: {
      billingAddress: {
        address: {
          countryCode: {}
        }
      }
    }
  });
}

/**
 * update billing address summary and contact information
 * @param {Object} order - checkout model to use as basis of new truth
 */
function updateBillingAddressSummary(order) {
  // update billing address summary
  addressHelpers.methods.populateAddressSummary('.billing .address-summary', order.billing.billingAddress.address);

  // update billing parts of order summary
  $('.order-summary-email').text(order.orderEmail);
  if (order.billing.billingAddress.address) {
    $('.order-summary-phone').text(order.billing.billingAddress.address.phone);
  }
}

/**
 * Updates the billing information in checkout, based on the supplied order model
 * @param {Object} order - checkout model to use as basis of new truth
 * @param {Object} customer - customer model to use as basis of new truth
 * @param {Object} [options] - options
 */
function updateBillingInformation(order, customer) {
  updateBillingAddressSelector(order, customer);

  // update billing address form
  updateBillingAddressFormValues(order);

  // update billing address summary and billing parts of order summary
  updateBillingAddressSummary(order);
}

/**
 * Updates the payment information in checkout, based on the supplied order model
 * @param {Object} order - checkout model to use as basis of new truth
 */
function updatePaymentInformation(order) {
  // update payment details
  var $paymentSummary = $('.payment-details');
  var htmlToAppend = '';
  if (order.billing.payment && order.billing.payment.selectedPaymentInstruments && order.billing.payment.selectedPaymentInstruments.length > 0) {
    htmlToAppend += '<span>' + order.resources.cardType + ' ' + order.billing.payment.selectedPaymentInstruments[0].type + '</span><div>' + order.billing.payment.selectedPaymentInstruments[0].maskedCreditCardNumber + '</div><div><span>' + order.resources.cardEnding + ' ' + order.billing.payment.selectedPaymentInstruments[0].expirationMonth + '/' + order.billing.payment.selectedPaymentInstruments[0].expirationYear + '</span></div>';
  }
  $paymentSummary.empty().append(htmlToAppend);
}

/**
 * clears the credit card form
 */
function clearCreditCardForm() {
  $('input[name$="_cardNumber"]').data('cleave').setRawValue('');
  $('select[name$="_expirationMonth"]').val('');
  $('select[name$="_expirationYear"]').val('');
  $('input[name$="_securityCode"]').val('');
}
module.exports = {
  methods: {
    updateBillingAddressSelector: updateBillingAddressSelector,
    updateBillingAddressFormValues: updateBillingAddressFormValues,
    clearBillingAddressFormValues: clearBillingAddressFormValues,
    updateBillingInformation: updateBillingInformation,
    updatePaymentInformation: updatePaymentInformation,
    clearCreditCardForm: clearCreditCardForm,
    updateBillingAddress: updateBillingAddress,
    validateAndUpdateBillingPaymentInstrument: validateAndUpdateBillingPaymentInstrument,
    updateBillingAddressSummary: updateBillingAddressSummary
  },
  showBillingDetails: function showBillingDetails() {
    $('.btn-show-billing-details').on('click', function () {
      $(this).parents('[data-address-mode]').attr('data-address-mode', 'new');
    });
  },
  hideBillingDetails: function hideBillingDetails() {
    $('.btn-hide-billing-details').on('click', function () {
      $(this).parents('[data-address-mode]').attr('data-address-mode', 'shipment');
    });
  },
  selectBillingAddress: function selectBillingAddress() {
    $('.payment-form .addressSelector').on('change', function () {
      var form = $(this).parents('form')[0];
      var selectedOption = $('option:selected', this);
      var optionID = selectedOption[0].value;
      if (optionID === 'new') {
        // Show Address
        $(form).attr('data-address-mode', 'new');
      } else {
        // Hide Address
        $(form).attr('data-address-mode', 'shipment');
      }

      // Copy fields
      var attrs = selectedOption.data();
      var element;
      Object.keys(attrs).forEach(function (attr) {
        element = attr === 'countryCode' ? 'country' : attr;
        if (element === 'cardNumber') {
          $('.cardNumber').data('cleave').setRawValue(attrs[attr]);
        } else {
          $('[name$=' + element + ']', form).val(attrs[attr]);
        }
      });
    });
  },
  handleCreditCardNumber: function handleCreditCardNumber() {
    cleave.handleCreditCardNumber('.cardNumber', '#cardType');
  },
  santitizeForm: function santitizeForm() {
    $('body').on('checkout:serializeBilling', function (e, data) {
      var serializedForm = cleave.serializeData(data.form);
      data.callback(serializedForm);
    });
  },
  selectSavedPaymentInstrument: function selectSavedPaymentInstrument() {
    $(document).on('click', '.saved-payment-instrument', function (e) {
      e.preventDefault();
      $('.saved-payment-security-code').val('');
      $('.saved-payment-instrument').removeClass('selected-payment');
      $(this).addClass('selected-payment');
      $('.saved-payment-instrument .card-image').removeClass('checkout-hidden');
      $('.saved-payment-instrument .security-code-input').addClass('checkout-hidden');
      $('.saved-payment-instrument.selected-payment' + ' .card-image').addClass('checkout-hidden');
      $('.saved-payment-instrument.selected-payment ' + '.security-code-input').removeClass('checkout-hidden');
    });
  },
  addNewPaymentInstrument: function addNewPaymentInstrument() {
    $('.btn.add-payment').on('click', function (e) {
      e.preventDefault();
      $('.payment-information').data('is-new-payment', true);
      clearCreditCardForm();
      $('.credit-card-form').removeClass('checkout-hidden');
      $('.user-payment-instruments').addClass('checkout-hidden');
    });
  },
  cancelNewPayment: function cancelNewPayment() {
    $('.cancel-new-payment').on('click', function (e) {
      e.preventDefault();
      $('.payment-information').data('is-new-payment', false);
      clearCreditCardForm();
      $('.user-payment-instruments').removeClass('checkout-hidden');
      $('.credit-card-form').addClass('checkout-hidden');
    });
  },
  clearBillingForm: function clearBillingForm() {
    $('body').on('checkout:clearBillingForm', function () {
      clearBillingAddressFormValues();
    });
  },
  paymentTabs: function paymentTabs() {
    $('.payment-options .nav-item').on('click', function (e) {
      e.preventDefault();
      var methodID = $(this).data('method-id');
      $('.payment-information').data('payment-method-id', methodID);
    });
  }
};

/***/ }),
/* 13 */
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {



var Cleave = (__webpack_require__(14)["default"]);
module.exports = {
  handleCreditCardNumber: function handleCreditCardNumber(cardFieldSelector, cardTypeSelector) {
    var cleave = new Cleave(cardFieldSelector, {
      creditCard: true,
      onCreditCardTypeChanged: function onCreditCardTypeChanged(type) {
        var creditCardTypes = {
          visa: 'Visa',
          mastercard: 'Master Card',
          amex: 'Amex',
          discover: 'Discover',
          unknown: 'Unknown'
        };
        var cardType = creditCardTypes[Object.keys(creditCardTypes).indexOf(type) > -1 ? type : 'unknown'];
        $(cardTypeSelector).val(cardType);
        $('.card-number-wrapper').attr('data-type', type);
        if (type === 'visa' || type === 'mastercard' || type === 'discover') {
          $('#securityCode').attr('maxlength', 3);
        } else {
          $('#securityCode').attr('maxlength', 4);
        }
      }
    });
    $(cardFieldSelector).data('cleave', cleave);
  },
  serializeData: function serializeData(form) {
    var serializedArray = form.serializeArray();
    serializedArray.forEach(function (item) {
      if (item.name.indexOf('cardNumber') > -1) {
        item.value = $('#cardNumber').data('cleave').getRawValue(); // eslint-disable-line
      }
    });
    return $.param(serializedArray);
  }
};

/***/ }),
/* 14 */
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
var commonjsGlobal = typeof window !== 'undefined' ? window : typeof __webpack_require__.g !== 'undefined' ? __webpack_require__.g : typeof self !== 'undefined' ? self : {};

var NumeralFormatter = function (numeralDecimalMark,
                                 numeralIntegerScale,
                                 numeralDecimalScale,
                                 numeralThousandsGroupStyle,
                                 numeralPositiveOnly,
                                 stripLeadingZeroes,
                                 prefix,
                                 signBeforePrefix,
                                 tailPrefix,
                                 delimiter) {
    var owner = this;

    owner.numeralDecimalMark = numeralDecimalMark || '.';
    owner.numeralIntegerScale = numeralIntegerScale > 0 ? numeralIntegerScale : 0;
    owner.numeralDecimalScale = numeralDecimalScale >= 0 ? numeralDecimalScale : 2;
    owner.numeralThousandsGroupStyle = numeralThousandsGroupStyle || NumeralFormatter.groupStyle.thousand;
    owner.numeralPositiveOnly = !!numeralPositiveOnly;
    owner.stripLeadingZeroes = stripLeadingZeroes !== false;
    owner.prefix = (prefix || prefix === '') ? prefix : '';
    owner.signBeforePrefix = !!signBeforePrefix;
    owner.tailPrefix = !!tailPrefix;
    owner.delimiter = (delimiter || delimiter === '') ? delimiter : ',';
    owner.delimiterRE = delimiter ? new RegExp('\\' + delimiter, 'g') : '';
};

NumeralFormatter.groupStyle = {
    thousand: 'thousand',
    lakh:     'lakh',
    wan:      'wan',
    none:     'none'    
};

NumeralFormatter.prototype = {
    getRawValue: function (value) {
        return value.replace(this.delimiterRE, '').replace(this.numeralDecimalMark, '.');
    },

    format: function (value) {
        var owner = this, parts, partSign, partSignAndPrefix, partInteger, partDecimal = '';

        // strip alphabet letters
        value = value.replace(/[A-Za-z]/g, '')
            // replace the first decimal mark with reserved placeholder
            .replace(owner.numeralDecimalMark, 'M')

            // strip non numeric letters except minus and "M"
            // this is to ensure prefix has been stripped
            .replace(/[^\dM-]/g, '')

            // replace the leading minus with reserved placeholder
            .replace(/^\-/, 'N')

            // strip the other minus sign (if present)
            .replace(/\-/g, '')

            // replace the minus sign (if present)
            .replace('N', owner.numeralPositiveOnly ? '' : '-')

            // replace decimal mark
            .replace('M', owner.numeralDecimalMark);

        // strip any leading zeros
        if (owner.stripLeadingZeroes) {
            value = value.replace(/^(-)?0+(?=\d)/, '$1');
        }

        partSign = value.slice(0, 1) === '-' ? '-' : '';
        if (typeof owner.prefix != 'undefined') {
            if (owner.signBeforePrefix) {
                partSignAndPrefix = partSign + owner.prefix;
            } else {
                partSignAndPrefix = owner.prefix + partSign;
            }
        } else {
            partSignAndPrefix = partSign;
        }
        
        partInteger = value;

        if (value.indexOf(owner.numeralDecimalMark) >= 0) {
            parts = value.split(owner.numeralDecimalMark);
            partInteger = parts[0];
            partDecimal = owner.numeralDecimalMark + parts[1].slice(0, owner.numeralDecimalScale);
        }

        if(partSign === '-') {
            partInteger = partInteger.slice(1);
        }

        if (owner.numeralIntegerScale > 0) {
          partInteger = partInteger.slice(0, owner.numeralIntegerScale);
        }

        switch (owner.numeralThousandsGroupStyle) {
        case NumeralFormatter.groupStyle.lakh:
            partInteger = partInteger.replace(/(\d)(?=(\d\d)+\d$)/g, '$1' + owner.delimiter);

            break;

        case NumeralFormatter.groupStyle.wan:
            partInteger = partInteger.replace(/(\d)(?=(\d{4})+$)/g, '$1' + owner.delimiter);

            break;

        case NumeralFormatter.groupStyle.thousand:
            partInteger = partInteger.replace(/(\d)(?=(\d{3})+$)/g, '$1' + owner.delimiter);

            break;
        }

        if (owner.tailPrefix) {
            return partSign + partInteger.toString() + (owner.numeralDecimalScale > 0 ? partDecimal.toString() : '') + owner.prefix;
        }

        return partSignAndPrefix + partInteger.toString() + (owner.numeralDecimalScale > 0 ? partDecimal.toString() : '');
    }
};

var NumeralFormatter_1 = NumeralFormatter;

var DateFormatter = function (datePattern, dateMin, dateMax) {
    var owner = this;

    owner.date = [];
    owner.blocks = [];
    owner.datePattern = datePattern;
    owner.dateMin = dateMin
      .split('-')
      .reverse()
      .map(function(x) {
        return parseInt(x, 10);
      });
    if (owner.dateMin.length === 2) owner.dateMin.unshift(0);

    owner.dateMax = dateMax
      .split('-')
      .reverse()
      .map(function(x) {
        return parseInt(x, 10);
      });
    if (owner.dateMax.length === 2) owner.dateMax.unshift(0);
    
    owner.initBlocks();
};

DateFormatter.prototype = {
    initBlocks: function () {
        var owner = this;
        owner.datePattern.forEach(function (value) {
            if (value === 'Y') {
                owner.blocks.push(4);
            } else {
                owner.blocks.push(2);
            }
        });
    },

    getISOFormatDate: function () {
        var owner = this,
            date = owner.date;

        return date[2] ? (
            date[2] + '-' + owner.addLeadingZero(date[1]) + '-' + owner.addLeadingZero(date[0])
        ) : '';
    },

    getBlocks: function () {
        return this.blocks;
    },

    getValidatedDate: function (value) {
        var owner = this, result = '';

        value = value.replace(/[^\d]/g, '');

        owner.blocks.forEach(function (length, index) {
            if (value.length > 0) {
                var sub = value.slice(0, length),
                    sub0 = sub.slice(0, 1),
                    rest = value.slice(length);

                switch (owner.datePattern[index]) {
                case 'd':
                    if (sub === '00') {
                        sub = '01';
                    } else if (parseInt(sub0, 10) > 3) {
                        sub = '0' + sub0;
                    } else if (parseInt(sub, 10) > 31) {
                        sub = '31';
                    }

                    break;

                case 'm':
                    if (sub === '00') {
                        sub = '01';
                    } else if (parseInt(sub0, 10) > 1) {
                        sub = '0' + sub0;
                    } else if (parseInt(sub, 10) > 12) {
                        sub = '12';
                    }

                    break;
                }

                result += sub;

                // update remaining string
                value = rest;
            }
        });

        return this.getFixedDateString(result);
    },

    getFixedDateString: function (value) {
        var owner = this, datePattern = owner.datePattern, date = [],
            dayIndex = 0, monthIndex = 0, yearIndex = 0,
            dayStartIndex = 0, monthStartIndex = 0, yearStartIndex = 0,
            day, month, year, fullYearDone = false;

        // mm-dd || dd-mm
        if (value.length === 4 && datePattern[0].toLowerCase() !== 'y' && datePattern[1].toLowerCase() !== 'y') {
            dayStartIndex = datePattern[0] === 'd' ? 0 : 2;
            monthStartIndex = 2 - dayStartIndex;
            day = parseInt(value.slice(dayStartIndex, dayStartIndex + 2), 10);
            month = parseInt(value.slice(monthStartIndex, monthStartIndex + 2), 10);

            date = this.getFixedDate(day, month, 0);
        }

        // yyyy-mm-dd || yyyy-dd-mm || mm-dd-yyyy || dd-mm-yyyy || dd-yyyy-mm || mm-yyyy-dd
        if (value.length === 8) {
            datePattern.forEach(function (type, index) {
                switch (type) {
                case 'd':
                    dayIndex = index;
                    break;
                case 'm':
                    monthIndex = index;
                    break;
                default:
                    yearIndex = index;
                    break;
                }
            });

            yearStartIndex = yearIndex * 2;
            dayStartIndex = (dayIndex <= yearIndex) ? dayIndex * 2 : (dayIndex * 2 + 2);
            monthStartIndex = (monthIndex <= yearIndex) ? monthIndex * 2 : (monthIndex * 2 + 2);

            day = parseInt(value.slice(dayStartIndex, dayStartIndex + 2), 10);
            month = parseInt(value.slice(monthStartIndex, monthStartIndex + 2), 10);
            year = parseInt(value.slice(yearStartIndex, yearStartIndex + 4), 10);

            fullYearDone = value.slice(yearStartIndex, yearStartIndex + 4).length === 4;

            date = this.getFixedDate(day, month, year);
        }

        // mm-yy || yy-mm
        if (value.length === 4 && (datePattern[0] === 'y' || datePattern[1] === 'y')) {
            monthStartIndex = datePattern[0] === 'm' ? 0 : 2;
            yearStartIndex = 2 - monthStartIndex;
            month = parseInt(value.slice(monthStartIndex, monthStartIndex + 2), 10);
            year = parseInt(value.slice(yearStartIndex, yearStartIndex + 2), 10);

            fullYearDone = value.slice(yearStartIndex, yearStartIndex + 2).length === 2;

            date = [0, month, year];
        }

        // mm-yyyy || yyyy-mm
        if (value.length === 6 && (datePattern[0] === 'Y' || datePattern[1] === 'Y')) {
            monthStartIndex = datePattern[0] === 'm' ? 0 : 4;
            yearStartIndex = 2 - 0.5 * monthStartIndex;
            month = parseInt(value.slice(monthStartIndex, monthStartIndex + 2), 10);
            year = parseInt(value.slice(yearStartIndex, yearStartIndex + 4), 10);

            fullYearDone = value.slice(yearStartIndex, yearStartIndex + 4).length === 4;

            date = [0, month, year];
        }

        date = owner.getRangeFixedDate(date);
        owner.date = date;

        var result = date.length === 0 ? value : datePattern.reduce(function (previous, current) {
            switch (current) {
            case 'd':
                return previous + (date[0] === 0 ? '' : owner.addLeadingZero(date[0]));
            case 'm':
                return previous + (date[1] === 0 ? '' : owner.addLeadingZero(date[1]));
            case 'y':
                return previous + (fullYearDone ? owner.addLeadingZeroForYear(date[2], false) : '');
            case 'Y':
                return previous + (fullYearDone ? owner.addLeadingZeroForYear(date[2], true) : '');
            }
        }, '');

        return result;
    },

    getRangeFixedDate: function (date) {
        var owner = this,
            datePattern = owner.datePattern,
            dateMin = owner.dateMin || [],
            dateMax = owner.dateMax || [];

        if (!date.length || (dateMin.length < 3 && dateMax.length < 3)) return date;

        if (
          datePattern.find(function(x) {
            return x.toLowerCase() === 'y';
          }) &&
          date[2] === 0
        ) return date;

        if (dateMax.length && (dateMax[2] < date[2] || (
          dateMax[2] === date[2] && (dateMax[1] < date[1] || (
            dateMax[1] === date[1] && dateMax[0] < date[0]
          ))
        ))) return dateMax;

        if (dateMin.length && (dateMin[2] > date[2] || (
          dateMin[2] === date[2] && (dateMin[1] > date[1] || (
            dateMin[1] === date[1] && dateMin[0] > date[0]
          ))
        ))) return dateMin;

        return date;
    },

    getFixedDate: function (day, month, year) {
        day = Math.min(day, 31);
        month = Math.min(month, 12);
        year = parseInt((year || 0), 10);

        if ((month < 7 && month % 2 === 0) || (month > 8 && month % 2 === 1)) {
            day = Math.min(day, month === 2 ? (this.isLeapYear(year) ? 29 : 28) : 30);
        }

        return [day, month, year];
    },

    isLeapYear: function (year) {
        return ((year % 4 === 0) && (year % 100 !== 0)) || (year % 400 === 0);
    },

    addLeadingZero: function (number) {
        return (number < 10 ? '0' : '') + number;
    },

    addLeadingZeroForYear: function (number, fullYearMode) {
        if (fullYearMode) {
            return (number < 10 ? '000' : (number < 100 ? '00' : (number < 1000 ? '0' : ''))) + number;
        }

        return (number < 10 ? '0' : '') + number;
    }
};

var DateFormatter_1 = DateFormatter;

var TimeFormatter = function (timePattern, timeFormat) {
    var owner = this;

    owner.time = [];
    owner.blocks = [];
    owner.timePattern = timePattern;
    owner.timeFormat = timeFormat;
    owner.initBlocks();
};

TimeFormatter.prototype = {
    initBlocks: function () {
        var owner = this;
        owner.timePattern.forEach(function () {
            owner.blocks.push(2);
        });
    },

    getISOFormatTime: function () {
        var owner = this,
            time = owner.time;

        return time[2] ? (
            owner.addLeadingZero(time[0]) + ':' + owner.addLeadingZero(time[1]) + ':' + owner.addLeadingZero(time[2])
        ) : '';
    },

    getBlocks: function () {
        return this.blocks;
    },

    getTimeFormatOptions: function () {
        var owner = this;
        if (String(owner.timeFormat) === '12') {
            return {
                maxHourFirstDigit: 1,
                maxHours: 12,
                maxMinutesFirstDigit: 5,
                maxMinutes: 60
            };
        }

        return {
            maxHourFirstDigit: 2,
            maxHours: 23,
            maxMinutesFirstDigit: 5,
            maxMinutes: 60
        };
    },

    getValidatedTime: function (value) {
        var owner = this, result = '';

        value = value.replace(/[^\d]/g, '');

        var timeFormatOptions = owner.getTimeFormatOptions();

        owner.blocks.forEach(function (length, index) {
            if (value.length > 0) {
                var sub = value.slice(0, length),
                    sub0 = sub.slice(0, 1),
                    rest = value.slice(length);

                switch (owner.timePattern[index]) {

                case 'h':
                    if (parseInt(sub0, 10) > timeFormatOptions.maxHourFirstDigit) {
                        sub = '0' + sub0;
                    } else if (parseInt(sub, 10) > timeFormatOptions.maxHours) {
                        sub = timeFormatOptions.maxHours + '';
                    }

                    break;

                case 'm':
                case 's':
                    if (parseInt(sub0, 10) > timeFormatOptions.maxMinutesFirstDigit) {
                        sub = '0' + sub0;
                    } else if (parseInt(sub, 10) > timeFormatOptions.maxMinutes) {
                        sub = timeFormatOptions.maxMinutes + '';
                    }
                    break;
                }

                result += sub;

                // update remaining string
                value = rest;
            }
        });

        return this.getFixedTimeString(result);
    },

    getFixedTimeString: function (value) {
        var owner = this, timePattern = owner.timePattern, time = [],
            secondIndex = 0, minuteIndex = 0, hourIndex = 0,
            secondStartIndex = 0, minuteStartIndex = 0, hourStartIndex = 0,
            second, minute, hour;

        if (value.length === 6) {
            timePattern.forEach(function (type, index) {
                switch (type) {
                case 's':
                    secondIndex = index * 2;
                    break;
                case 'm':
                    minuteIndex = index * 2;
                    break;
                case 'h':
                    hourIndex = index * 2;
                    break;
                }
            });

            hourStartIndex = hourIndex;
            minuteStartIndex = minuteIndex;
            secondStartIndex = secondIndex;

            second = parseInt(value.slice(secondStartIndex, secondStartIndex + 2), 10);
            minute = parseInt(value.slice(minuteStartIndex, minuteStartIndex + 2), 10);
            hour = parseInt(value.slice(hourStartIndex, hourStartIndex + 2), 10);

            time = this.getFixedTime(hour, minute, second);
        }

        if (value.length === 4 && owner.timePattern.indexOf('s') < 0) {
            timePattern.forEach(function (type, index) {
                switch (type) {
                case 'm':
                    minuteIndex = index * 2;
                    break;
                case 'h':
                    hourIndex = index * 2;
                    break;
                }
            });

            hourStartIndex = hourIndex;
            minuteStartIndex = minuteIndex;

            second = 0;
            minute = parseInt(value.slice(minuteStartIndex, minuteStartIndex + 2), 10);
            hour = parseInt(value.slice(hourStartIndex, hourStartIndex + 2), 10);

            time = this.getFixedTime(hour, minute, second);
        }

        owner.time = time;

        return time.length === 0 ? value : timePattern.reduce(function (previous, current) {
            switch (current) {
            case 's':
                return previous + owner.addLeadingZero(time[2]);
            case 'm':
                return previous + owner.addLeadingZero(time[1]);
            case 'h':
                return previous + owner.addLeadingZero(time[0]);
            }
        }, '');
    },

    getFixedTime: function (hour, minute, second) {
        second = Math.min(parseInt(second || 0, 10), 60);
        minute = Math.min(minute, 60);
        hour = Math.min(hour, 60);

        return [hour, minute, second];
    },

    addLeadingZero: function (number) {
        return (number < 10 ? '0' : '') + number;
    }
};

var TimeFormatter_1 = TimeFormatter;

var PhoneFormatter = function (formatter, delimiter) {
    var owner = this;

    owner.delimiter = (delimiter || delimiter === '') ? delimiter : ' ';
    owner.delimiterRE = delimiter ? new RegExp('\\' + delimiter, 'g') : '';

    owner.formatter = formatter;
};

PhoneFormatter.prototype = {
    setFormatter: function (formatter) {
        this.formatter = formatter;
    },

    format: function (phoneNumber) {
        var owner = this;

        owner.formatter.clear();

        // only keep number and +
        phoneNumber = phoneNumber.replace(/[^\d+]/g, '');

        // strip non-leading +
        phoneNumber = phoneNumber.replace(/^\+/, 'B').replace(/\+/g, '').replace('B', '+');

        // strip delimiter
        phoneNumber = phoneNumber.replace(owner.delimiterRE, '');

        var result = '', current, validated = false;

        for (var i = 0, iMax = phoneNumber.length; i < iMax; i++) {
            current = owner.formatter.inputDigit(phoneNumber.charAt(i));

            // has ()- or space inside
            if (/[\s()-]/g.test(current)) {
                result = current;

                validated = true;
            } else {
                if (!validated) {
                    result = current;
                }
                // else: over length input
                // it turns to invalid number again
            }
        }

        // strip ()
        // e.g. US: 7161234567 returns (716) 123-4567
        result = result.replace(/[()]/g, '');
        // replace library delimiter with user customized delimiter
        result = result.replace(/[\s-]/g, owner.delimiter);

        return result;
    }
};

var PhoneFormatter_1 = PhoneFormatter;

var CreditCardDetector = {
    blocks: {
        uatp:          [4, 5, 6],
        amex:          [4, 6, 5],
        diners:        [4, 6, 4],
        discover:      [4, 4, 4, 4],
        mastercard:    [4, 4, 4, 4],
        dankort:       [4, 4, 4, 4],
        instapayment:  [4, 4, 4, 4],
        jcb15:         [4, 6, 5],
        jcb:           [4, 4, 4, 4],
        maestro:       [4, 4, 4, 4],
        visa:          [4, 4, 4, 4],
        mir:           [4, 4, 4, 4],
        unionPay:      [4, 4, 4, 4],
        general:       [4, 4, 4, 4]
    },

    re: {
        // starts with 1; 15 digits, not starts with 1800 (jcb card)
        uatp: /^(?!1800)1\d{0,14}/,

        // starts with 34/37; 15 digits
        amex: /^3[47]\d{0,13}/,

        // starts with 6011/65/644-649; 16 digits
        discover: /^(?:6011|65\d{0,2}|64[4-9]\d?)\d{0,12}/,

        // starts with 300-305/309 or 36/38/39; 14 digits
        diners: /^3(?:0([0-5]|9)|[689]\d?)\d{0,11}/,

        // starts with 51-55/2221–2720; 16 digits
        mastercard: /^(5[1-5]\d{0,2}|22[2-9]\d{0,1}|2[3-7]\d{0,2})\d{0,12}/,

        // starts with 5019/4175/4571; 16 digits
        dankort: /^(5019|4175|4571)\d{0,12}/,

        // starts with 637-639; 16 digits
        instapayment: /^63[7-9]\d{0,13}/,

        // starts with 2131/1800; 15 digits
        jcb15: /^(?:2131|1800)\d{0,11}/,

        // starts with 2131/1800/35; 16 digits
        jcb: /^(?:35\d{0,2})\d{0,12}/,

        // starts with 50/56-58/6304/67; 16 digits
        maestro: /^(?:5[0678]\d{0,2}|6304|67\d{0,2})\d{0,12}/,

        // starts with 22; 16 digits
        mir: /^220[0-4]\d{0,12}/,

        // starts with 4; 16 digits
        visa: /^4\d{0,15}/,

        // starts with 62/81; 16 digits
        unionPay: /^(62|81)\d{0,14}/
    },

    getStrictBlocks: function (block) {
      var total = block.reduce(function (prev, current) {
        return prev + current;
      }, 0);

      return block.concat(19 - total);
    },

    getInfo: function (value, strictMode) {
        var blocks = CreditCardDetector.blocks,
            re = CreditCardDetector.re;

        // Some credit card can have up to 19 digits number.
        // Set strictMode to true will remove the 16 max-length restrain,
        // however, I never found any website validate card number like
        // this, hence probably you don't want to enable this option.
        strictMode = !!strictMode;

        for (var key in re) {
            if (re[key].test(value)) {
                var matchedBlocks = blocks[key];
                return {
                    type: key,
                    blocks: strictMode ? this.getStrictBlocks(matchedBlocks) : matchedBlocks
                };
            }
        }

        return {
            type: 'unknown',
            blocks: strictMode ? this.getStrictBlocks(blocks.general) : blocks.general
        };
    }
};

var CreditCardDetector_1 = CreditCardDetector;

var Util = {
    noop: function () {
    },

    strip: function (value, re) {
        return value.replace(re, '');
    },

    getPostDelimiter: function (value, delimiter, delimiters) {
        // single delimiter
        if (delimiters.length === 0) {
            return value.slice(-delimiter.length) === delimiter ? delimiter : '';
        }

        // multiple delimiters
        var matchedDelimiter = '';
        delimiters.forEach(function (current) {
            if (value.slice(-current.length) === current) {
                matchedDelimiter = current;
            }
        });

        return matchedDelimiter;
    },

    getDelimiterREByDelimiter: function (delimiter) {
        return new RegExp(delimiter.replace(/([.?*+^$[\]\\(){}|-])/g, '\\$1'), 'g');
    },

    getNextCursorPosition: function (prevPos, oldValue, newValue, delimiter, delimiters) {
      // If cursor was at the end of value, just place it back.
      // Because new value could contain additional chars.
      if (oldValue.length === prevPos) {
          return newValue.length;
      }

      return prevPos + this.getPositionOffset(prevPos, oldValue, newValue, delimiter ,delimiters);
    },

    getPositionOffset: function (prevPos, oldValue, newValue, delimiter, delimiters) {
        var oldRawValue, newRawValue, lengthOffset;

        oldRawValue = this.stripDelimiters(oldValue.slice(0, prevPos), delimiter, delimiters);
        newRawValue = this.stripDelimiters(newValue.slice(0, prevPos), delimiter, delimiters);
        lengthOffset = oldRawValue.length - newRawValue.length;

        return (lengthOffset !== 0) ? (lengthOffset / Math.abs(lengthOffset)) : 0;
    },

    stripDelimiters: function (value, delimiter, delimiters) {
        var owner = this;

        // single delimiter
        if (delimiters.length === 0) {
            var delimiterRE = delimiter ? owner.getDelimiterREByDelimiter(delimiter) : '';

            return value.replace(delimiterRE, '');
        }

        // multiple delimiters
        delimiters.forEach(function (current) {
            current.split('').forEach(function (letter) {
                value = value.replace(owner.getDelimiterREByDelimiter(letter), '');
            });
        });

        return value;
    },

    headStr: function (str, length) {
        return str.slice(0, length);
    },

    getMaxLength: function (blocks) {
        return blocks.reduce(function (previous, current) {
            return previous + current;
        }, 0);
    },

    // strip prefix
    // Before type  |   After type    |     Return value
    // PEFIX-...    |   PEFIX-...     |     ''
    // PREFIX-123   |   PEFIX-123     |     123
    // PREFIX-123   |   PREFIX-23     |     23
    // PREFIX-123   |   PREFIX-1234   |     1234
    getPrefixStrippedValue: function (value, prefix, prefixLength, prevResult, delimiter, delimiters, noImmediatePrefix, tailPrefix, signBeforePrefix) {
        // No prefix
        if (prefixLength === 0) {
          return value;
        }

        // Value is prefix
        if (value === prefix && value !== '') {
          return '';
        }

        if (signBeforePrefix && (value.slice(0, 1) == '-')) {
            var prev = (prevResult.slice(0, 1) == '-') ? prevResult.slice(1) : prevResult;
            return '-' + this.getPrefixStrippedValue(value.slice(1), prefix, prefixLength, prev, delimiter, delimiters, noImmediatePrefix, tailPrefix, signBeforePrefix);
        }

        // Pre result prefix string does not match pre-defined prefix
        if (prevResult.slice(0, prefixLength) !== prefix && !tailPrefix) {
            // Check if the first time user entered something
            if (noImmediatePrefix && !prevResult && value) return value;
            return '';
        } else if (prevResult.slice(-prefixLength) !== prefix && tailPrefix) {
            // Check if the first time user entered something
            if (noImmediatePrefix && !prevResult && value) return value;
            return '';
        }

        var prevValue = this.stripDelimiters(prevResult, delimiter, delimiters);

        // New value has issue, someone typed in between prefix letters
        // Revert to pre value
        if (value.slice(0, prefixLength) !== prefix && !tailPrefix) {
            return prevValue.slice(prefixLength);
        } else if (value.slice(-prefixLength) !== prefix && tailPrefix) {
            return prevValue.slice(0, -prefixLength - 1);
        }

        // No issue, strip prefix for new value
        return tailPrefix ? value.slice(0, -prefixLength) : value.slice(prefixLength);
    },

    getFirstDiffIndex: function (prev, current) {
        var index = 0;

        while (prev.charAt(index) === current.charAt(index)) {
            if (prev.charAt(index++) === '') {
                return -1;
            }
        }

        return index;
    },

    getFormattedValue: function (value, blocks, blocksLength, delimiter, delimiters, delimiterLazyShow) {
        var result = '',
            multipleDelimiters = delimiters.length > 0,
            currentDelimiter = '';

        // no options, normal input
        if (blocksLength === 0) {
            return value;
        }

        blocks.forEach(function (length, index) {
            if (value.length > 0) {
                var sub = value.slice(0, length),
                    rest = value.slice(length);

                if (multipleDelimiters) {
                    currentDelimiter = delimiters[delimiterLazyShow ? (index - 1) : index] || currentDelimiter;
                } else {
                    currentDelimiter = delimiter;
                }

                if (delimiterLazyShow) {
                    if (index > 0) {
                        result += currentDelimiter;
                    }

                    result += sub;
                } else {
                    result += sub;

                    if (sub.length === length && index < blocksLength - 1) {
                        result += currentDelimiter;
                    }
                }

                // update remaining string
                value = rest;
            }
        });

        return result;
    },

    // move cursor to the end
    // the first time user focuses on an input with prefix
    fixPrefixCursor: function (el, prefix, delimiter, delimiters) {
        if (!el) {
            return;
        }

        var val = el.value,
            appendix = delimiter || (delimiters[0] || ' ');

        if (!el.setSelectionRange || !prefix || (prefix.length + appendix.length) <= val.length) {
            return;
        }

        var len = val.length * 2;

        // set timeout to avoid blink
        setTimeout(function () {
            el.setSelectionRange(len, len);
        }, 1);
    },

    // Check if input field is fully selected
    checkFullSelection: function(value) {
      try {
        var selection = window.getSelection() || document.getSelection() || {};
        return selection.toString().length === value.length;
      } catch (ex) {
        // Ignore
      }

      return false;
    },

    setSelection: function (element, position, doc) {
        if (element !== this.getActiveElement(doc)) {
            return;
        }

        // cursor is already in the end
        if (element && element.value.length <= position) {
          return;
        }

        if (element.createTextRange) {
            var range = element.createTextRange();

            range.move('character', position);
            range.select();
        } else {
            try {
                element.setSelectionRange(position, position);
            } catch (e) {
                // eslint-disable-next-line
                console.warn('The input element type does not support selection');
            }
        }
    },

    getActiveElement: function(parent) {
        var activeElement = parent.activeElement;
        if (activeElement && activeElement.shadowRoot) {
            return this.getActiveElement(activeElement.shadowRoot);
        }
        return activeElement;
    },

    isAndroid: function () {
        return navigator && /android/i.test(navigator.userAgent);
    },

    // On Android chrome, the keyup and keydown events
    // always return key code 229 as a composition that
    // buffers the user’s keystrokes
    // see https://github.com/nosir/cleave.js/issues/147
    isAndroidBackspaceKeydown: function (lastInputValue, currentInputValue) {
        if (!this.isAndroid() || !lastInputValue || !currentInputValue) {
            return false;
        }

        return currentInputValue === lastInputValue.slice(0, -1);
    }
};

var Util_1 = Util;

/**
 * Props Assignment
 *
 * Separate this, so react module can share the usage
 */
var DefaultProperties = {
    // Maybe change to object-assign
    // for now just keep it as simple
    assign: function (target, opts) {
        target = target || {};
        opts = opts || {};

        // credit card
        target.creditCard = !!opts.creditCard;
        target.creditCardStrictMode = !!opts.creditCardStrictMode;
        target.creditCardType = '';
        target.onCreditCardTypeChanged = opts.onCreditCardTypeChanged || (function () {});

        // phone
        target.phone = !!opts.phone;
        target.phoneRegionCode = opts.phoneRegionCode || 'AU';
        target.phoneFormatter = {};

        // time
        target.time = !!opts.time;
        target.timePattern = opts.timePattern || ['h', 'm', 's'];
        target.timeFormat = opts.timeFormat || '24';
        target.timeFormatter = {};

        // date
        target.date = !!opts.date;
        target.datePattern = opts.datePattern || ['d', 'm', 'Y'];
        target.dateMin = opts.dateMin || '';
        target.dateMax = opts.dateMax || '';
        target.dateFormatter = {};

        // numeral
        target.numeral = !!opts.numeral;
        target.numeralIntegerScale = opts.numeralIntegerScale > 0 ? opts.numeralIntegerScale : 0;
        target.numeralDecimalScale = opts.numeralDecimalScale >= 0 ? opts.numeralDecimalScale : 2;
        target.numeralDecimalMark = opts.numeralDecimalMark || '.';
        target.numeralThousandsGroupStyle = opts.numeralThousandsGroupStyle || 'thousand';
        target.numeralPositiveOnly = !!opts.numeralPositiveOnly;
        target.stripLeadingZeroes = opts.stripLeadingZeroes !== false;
        target.signBeforePrefix = !!opts.signBeforePrefix;
        target.tailPrefix = !!opts.tailPrefix;

        // others
        target.swapHiddenInput = !!opts.swapHiddenInput;
        
        target.numericOnly = target.creditCard || target.date || !!opts.numericOnly;

        target.uppercase = !!opts.uppercase;
        target.lowercase = !!opts.lowercase;

        target.prefix = (target.creditCard || target.date) ? '' : (opts.prefix || '');
        target.noImmediatePrefix = !!opts.noImmediatePrefix;
        target.prefixLength = target.prefix.length;
        target.rawValueTrimPrefix = !!opts.rawValueTrimPrefix;
        target.copyDelimiter = !!opts.copyDelimiter;

        target.initValue = (opts.initValue !== undefined && opts.initValue !== null) ? opts.initValue.toString() : '';

        target.delimiter =
            (opts.delimiter || opts.delimiter === '') ? opts.delimiter :
                (opts.date ? '/' :
                    (opts.time ? ':' :
                        (opts.numeral ? ',' :
                            (opts.phone ? ' ' :
                                ' '))));
        target.delimiterLength = target.delimiter.length;
        target.delimiterLazyShow = !!opts.delimiterLazyShow;
        target.delimiters = opts.delimiters || [];

        target.blocks = opts.blocks || [];
        target.blocksLength = target.blocks.length;

        target.root = (typeof commonjsGlobal === 'object' && commonjsGlobal) ? commonjsGlobal : window;
        target.document = opts.document || target.root.document;

        target.maxLength = 0;

        target.backspace = false;
        target.result = '';

        target.onValueChanged = opts.onValueChanged || (function () {});

        return target;
    }
};

var DefaultProperties_1 = DefaultProperties;

/**
 * Construct a new Cleave instance by passing the configuration object
 *
 * @param {String | HTMLElement} element
 * @param {Object} opts
 */
var Cleave = function (element, opts) {
    var owner = this;
    var hasMultipleElements = false;

    if (typeof element === 'string') {
        owner.element = document.querySelector(element);
        hasMultipleElements = document.querySelectorAll(element).length > 1;
    } else {
      if (typeof element.length !== 'undefined' && element.length > 0) {
        owner.element = element[0];
        hasMultipleElements = element.length > 1;
      } else {
        owner.element = element;
      }
    }

    if (!owner.element) {
        throw new Error('[cleave.js] Please check the element');
    }

    if (hasMultipleElements) {
      try {
        // eslint-disable-next-line
        console.warn('[cleave.js] Multiple input fields matched, cleave.js will only take the first one.');
      } catch (e) {
        // Old IE
      }
    }

    opts.initValue = owner.element.value;

    owner.properties = Cleave.DefaultProperties.assign({}, opts);

    owner.init();
};

Cleave.prototype = {
    init: function () {
        var owner = this, pps = owner.properties;

        // no need to use this lib
        if (!pps.numeral && !pps.phone && !pps.creditCard && !pps.time && !pps.date && (pps.blocksLength === 0 && !pps.prefix)) {
            owner.onInput(pps.initValue);

            return;
        }

        pps.maxLength = Cleave.Util.getMaxLength(pps.blocks);

        owner.isAndroid = Cleave.Util.isAndroid();
        owner.lastInputValue = '';
        owner.isBackward = '';

        owner.onChangeListener = owner.onChange.bind(owner);
        owner.onKeyDownListener = owner.onKeyDown.bind(owner);
        owner.onFocusListener = owner.onFocus.bind(owner);
        owner.onCutListener = owner.onCut.bind(owner);
        owner.onCopyListener = owner.onCopy.bind(owner);

        owner.initSwapHiddenInput();

        owner.element.addEventListener('input', owner.onChangeListener);
        owner.element.addEventListener('keydown', owner.onKeyDownListener);
        owner.element.addEventListener('focus', owner.onFocusListener);
        owner.element.addEventListener('cut', owner.onCutListener);
        owner.element.addEventListener('copy', owner.onCopyListener);


        owner.initPhoneFormatter();
        owner.initDateFormatter();
        owner.initTimeFormatter();
        owner.initNumeralFormatter();

        // avoid touch input field if value is null
        // otherwise Firefox will add red box-shadow for <input required />
        if (pps.initValue || (pps.prefix && !pps.noImmediatePrefix)) {
            owner.onInput(pps.initValue);
        }
    },

    initSwapHiddenInput: function () {
        var owner = this, pps = owner.properties;
        if (!pps.swapHiddenInput) return;

        var inputFormatter = owner.element.cloneNode(true);
        owner.element.parentNode.insertBefore(inputFormatter, owner.element);

        owner.elementSwapHidden = owner.element;
        owner.elementSwapHidden.type = 'hidden';

        owner.element = inputFormatter;
        owner.element.id = '';
    },

    initNumeralFormatter: function () {
        var owner = this, pps = owner.properties;

        if (!pps.numeral) {
            return;
        }

        pps.numeralFormatter = new Cleave.NumeralFormatter(
            pps.numeralDecimalMark,
            pps.numeralIntegerScale,
            pps.numeralDecimalScale,
            pps.numeralThousandsGroupStyle,
            pps.numeralPositiveOnly,
            pps.stripLeadingZeroes,
            pps.prefix,
            pps.signBeforePrefix,
            pps.tailPrefix,
            pps.delimiter
        );
    },

    initTimeFormatter: function() {
        var owner = this, pps = owner.properties;

        if (!pps.time) {
            return;
        }

        pps.timeFormatter = new Cleave.TimeFormatter(pps.timePattern, pps.timeFormat);
        pps.blocks = pps.timeFormatter.getBlocks();
        pps.blocksLength = pps.blocks.length;
        pps.maxLength = Cleave.Util.getMaxLength(pps.blocks);
    },

    initDateFormatter: function () {
        var owner = this, pps = owner.properties;

        if (!pps.date) {
            return;
        }

        pps.dateFormatter = new Cleave.DateFormatter(pps.datePattern, pps.dateMin, pps.dateMax);
        pps.blocks = pps.dateFormatter.getBlocks();
        pps.blocksLength = pps.blocks.length;
        pps.maxLength = Cleave.Util.getMaxLength(pps.blocks);
    },

    initPhoneFormatter: function () {
        var owner = this, pps = owner.properties;

        if (!pps.phone) {
            return;
        }

        // Cleave.AsYouTypeFormatter should be provided by
        // external google closure lib
        try {
            pps.phoneFormatter = new Cleave.PhoneFormatter(
                new pps.root.Cleave.AsYouTypeFormatter(pps.phoneRegionCode),
                pps.delimiter
            );
        } catch (ex) {
            throw new Error('[cleave.js] Please include phone-type-formatter.{country}.js lib');
        }
    },

    onKeyDown: function (event) {
        var owner = this,
            charCode = event.which || event.keyCode;

        owner.lastInputValue = owner.element.value;
        owner.isBackward = charCode === 8;
    },

    onChange: function (event) {
        var owner = this, pps = owner.properties,
            Util = Cleave.Util;

        owner.isBackward = owner.isBackward || event.inputType === 'deleteContentBackward';

        var postDelimiter = Util.getPostDelimiter(owner.lastInputValue, pps.delimiter, pps.delimiters);

        if (owner.isBackward && postDelimiter) {
            pps.postDelimiterBackspace = postDelimiter;
        } else {
            pps.postDelimiterBackspace = false;
        }

        this.onInput(this.element.value);
    },

    onFocus: function () {
        var owner = this,
            pps = owner.properties;
        owner.lastInputValue = owner.element.value;

        if (pps.prefix && pps.noImmediatePrefix && !owner.element.value) {
            this.onInput(pps.prefix);
        }

        Cleave.Util.fixPrefixCursor(owner.element, pps.prefix, pps.delimiter, pps.delimiters);
    },

    onCut: function (e) {
        if (!Cleave.Util.checkFullSelection(this.element.value)) return;
        this.copyClipboardData(e);
        this.onInput('');
    },

    onCopy: function (e) {
        if (!Cleave.Util.checkFullSelection(this.element.value)) return;
        this.copyClipboardData(e);
    },

    copyClipboardData: function (e) {
        var owner = this,
            pps = owner.properties,
            Util = Cleave.Util,
            inputValue = owner.element.value,
            textToCopy = '';

        if (!pps.copyDelimiter) {
            textToCopy = Util.stripDelimiters(inputValue, pps.delimiter, pps.delimiters);
        } else {
            textToCopy = inputValue;
        }

        try {
            if (e.clipboardData) {
                e.clipboardData.setData('Text', textToCopy);
            } else {
                window.clipboardData.setData('Text', textToCopy);
            }

            e.preventDefault();
        } catch (ex) {
            //  empty
        }
    },

    onInput: function (value) {
        var owner = this, pps = owner.properties,
            Util = Cleave.Util;

        // case 1: delete one more character "4"
        // 1234*| -> hit backspace -> 123|
        // case 2: last character is not delimiter which is:
        // 12|34* -> hit backspace -> 1|34*
        // note: no need to apply this for numeral mode
        var postDelimiterAfter = Util.getPostDelimiter(value, pps.delimiter, pps.delimiters);
        if (!pps.numeral && pps.postDelimiterBackspace && !postDelimiterAfter) {
            value = Util.headStr(value, value.length - pps.postDelimiterBackspace.length);
        }

        // phone formatter
        if (pps.phone) {
            if (pps.prefix && (!pps.noImmediatePrefix || value.length)) {
                pps.result = pps.prefix + pps.phoneFormatter.format(value).slice(pps.prefix.length);
            } else {
                pps.result = pps.phoneFormatter.format(value);
            }
            owner.updateValueState();

            return;
        }

        // numeral formatter
        if (pps.numeral) {
            // Do not show prefix when noImmediatePrefix is specified
            // This mostly because we need to show user the native input placeholder
            if (pps.prefix && pps.noImmediatePrefix && value.length === 0) {
                pps.result = '';
            } else {
                pps.result = pps.numeralFormatter.format(value);
            }
            owner.updateValueState();

            return;
        }

        // date
        if (pps.date) {
            value = pps.dateFormatter.getValidatedDate(value);
        }

        // time
        if (pps.time) {
            value = pps.timeFormatter.getValidatedTime(value);
        }

        // strip delimiters
        value = Util.stripDelimiters(value, pps.delimiter, pps.delimiters);

        // strip prefix
        value = Util.getPrefixStrippedValue(value, pps.prefix, pps.prefixLength, pps.result, pps.delimiter, pps.delimiters, pps.noImmediatePrefix, pps.tailPrefix, pps.signBeforePrefix);

        // strip non-numeric characters
        value = pps.numericOnly ? Util.strip(value, /[^\d]/g) : value;

        // convert case
        value = pps.uppercase ? value.toUpperCase() : value;
        value = pps.lowercase ? value.toLowerCase() : value;

        // prevent from showing prefix when no immediate option enabled with empty input value
        if (pps.prefix) {
            if (pps.tailPrefix) {
                value = value + pps.prefix;
            } else {
                value = pps.prefix + value;
            }


            // no blocks specified, no need to do formatting
            if (pps.blocksLength === 0) {
                pps.result = value;
                owner.updateValueState();

                return;
            }
        }

        // update credit card props
        if (pps.creditCard) {
            owner.updateCreditCardPropsByValue(value);
        }

        // strip over length characters
        value = Util.headStr(value, pps.maxLength);

        // apply blocks
        pps.result = Util.getFormattedValue(
            value,
            pps.blocks, pps.blocksLength,
            pps.delimiter, pps.delimiters, pps.delimiterLazyShow
        );

        owner.updateValueState();
    },

    updateCreditCardPropsByValue: function (value) {
        var owner = this, pps = owner.properties,
            Util = Cleave.Util,
            creditCardInfo;

        // At least one of the first 4 characters has changed
        if (Util.headStr(pps.result, 4) === Util.headStr(value, 4)) {
            return;
        }

        creditCardInfo = Cleave.CreditCardDetector.getInfo(value, pps.creditCardStrictMode);

        pps.blocks = creditCardInfo.blocks;
        pps.blocksLength = pps.blocks.length;
        pps.maxLength = Util.getMaxLength(pps.blocks);

        // credit card type changed
        if (pps.creditCardType !== creditCardInfo.type) {
            pps.creditCardType = creditCardInfo.type;

            pps.onCreditCardTypeChanged.call(owner, pps.creditCardType);
        }
    },

    updateValueState: function () {
        var owner = this,
            Util = Cleave.Util,
            pps = owner.properties;

        if (!owner.element) {
            return;
        }

        var endPos = owner.element.selectionEnd;
        var oldValue = owner.element.value;
        var newValue = pps.result;

        endPos = Util.getNextCursorPosition(endPos, oldValue, newValue, pps.delimiter, pps.delimiters);

        // fix Android browser type="text" input field
        // cursor not jumping issue
        if (owner.isAndroid) {
            window.setTimeout(function () {
                owner.element.value = newValue;
                Util.setSelection(owner.element, endPos, pps.document, false);
                owner.callOnValueChanged();
            }, 1);

            return;
        }

        owner.element.value = newValue;
        if (pps.swapHiddenInput) owner.elementSwapHidden.value = owner.getRawValue();

        Util.setSelection(owner.element, endPos, pps.document, false);
        owner.callOnValueChanged();
    },

    callOnValueChanged: function () {
        var owner = this,
            pps = owner.properties;

        pps.onValueChanged.call(owner, {
            target: {
                name: owner.element.name,
                value: pps.result,
                rawValue: owner.getRawValue()
            }
        });
    },

    setPhoneRegionCode: function (phoneRegionCode) {
        var owner = this, pps = owner.properties;

        pps.phoneRegionCode = phoneRegionCode;
        owner.initPhoneFormatter();
        owner.onChange();
    },

    setRawValue: function (value) {
        var owner = this, pps = owner.properties;

        value = value !== undefined && value !== null ? value.toString() : '';

        if (pps.numeral) {
            value = value.replace('.', pps.numeralDecimalMark);
        }

        pps.postDelimiterBackspace = false;

        owner.element.value = value;
        owner.onInput(value);
    },

    getRawValue: function () {
        var owner = this,
            pps = owner.properties,
            Util = Cleave.Util,
            rawValue = owner.element.value;

        if (pps.rawValueTrimPrefix) {
            rawValue = Util.getPrefixStrippedValue(rawValue, pps.prefix, pps.prefixLength, pps.result, pps.delimiter, pps.delimiters, pps.noImmediatePrefix, pps.tailPrefix, pps.signBeforePrefix);
        }

        if (pps.numeral) {
            rawValue = pps.numeralFormatter.getRawValue(rawValue);
        } else {
            rawValue = Util.stripDelimiters(rawValue, pps.delimiter, pps.delimiters);
        }

        return rawValue;
    },

    getISOFormatDate: function () {
        var owner = this,
            pps = owner.properties;

        return pps.date ? pps.dateFormatter.getISOFormatDate() : '';
    },

    getISOFormatTime: function () {
        var owner = this,
            pps = owner.properties;

        return pps.time ? pps.timeFormatter.getISOFormatTime() : '';
    },

    getFormattedValue: function () {
        return this.element.value;
    },

    destroy: function () {
        var owner = this;

        owner.element.removeEventListener('input', owner.onChangeListener);
        owner.element.removeEventListener('keydown', owner.onKeyDownListener);
        owner.element.removeEventListener('focus', owner.onFocusListener);
        owner.element.removeEventListener('cut', owner.onCutListener);
        owner.element.removeEventListener('copy', owner.onCopyListener);
    },

    toString: function () {
        return '[Cleave Object]';
    }
};

Cleave.NumeralFormatter = NumeralFormatter_1;
Cleave.DateFormatter = DateFormatter_1;
Cleave.TimeFormatter = TimeFormatter_1;
Cleave.PhoneFormatter = PhoneFormatter_1;
Cleave.CreditCardDetector = CreditCardDetector_1;
Cleave.Util = Util_1;
Cleave.DefaultProperties = DefaultProperties_1;

// for angular directive
((typeof commonjsGlobal === 'object' && commonjsGlobal) ? commonjsGlobal : window)['Cleave'] = Cleave;

// CommonJS
var Cleave_1 = Cleave;

/* harmony default export */ __webpack_exports__["default"] = (Cleave_1);


/***/ }),
/* 15 */
/***/ (function(module) {



function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return e; }; var t, e = {}, r = Object.prototype, n = r.hasOwnProperty, o = Object.defineProperty || function (t, e, r) { t[e] = r.value; }, i = "function" == typeof Symbol ? Symbol : {}, a = i.iterator || "@@iterator", c = i.asyncIterator || "@@asyncIterator", u = i.toStringTag || "@@toStringTag"; function define(t, e, r) { return Object.defineProperty(t, e, { value: r, enumerable: !0, configurable: !0, writable: !0 }), t[e]; } try { define({}, ""); } catch (t) { define = function define(t, e, r) { return t[e] = r; }; } function wrap(t, e, r, n) { var i = e && e.prototype instanceof Generator ? e : Generator, a = Object.create(i.prototype), c = new Context(n || []); return o(a, "_invoke", { value: makeInvokeMethod(t, r, c) }), a; } function tryCatch(t, e, r) { try { return { type: "normal", arg: t.call(e, r) }; } catch (t) { return { type: "throw", arg: t }; } } e.wrap = wrap; var h = "suspendedStart", l = "suspendedYield", f = "executing", s = "completed", y = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var p = {}; define(p, a, function () { return this; }); var d = Object.getPrototypeOf, v = d && d(d(values([]))); v && v !== r && n.call(v, a) && (p = v); var g = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(p); function defineIteratorMethods(t) { ["next", "throw", "return"].forEach(function (e) { define(t, e, function (t) { return this._invoke(e, t); }); }); } function AsyncIterator(t, e) { function invoke(r, o, i, a) { var c = tryCatch(t[r], t, o); if ("throw" !== c.type) { var u = c.arg, h = u.value; return h && "object" == _typeof(h) && n.call(h, "__await") ? e.resolve(h.__await).then(function (t) { invoke("next", t, i, a); }, function (t) { invoke("throw", t, i, a); }) : e.resolve(h).then(function (t) { u.value = t, i(u); }, function (t) { return invoke("throw", t, i, a); }); } a(c.arg); } var r; o(this, "_invoke", { value: function value(t, n) { function callInvokeWithMethodAndArg() { return new e(function (e, r) { invoke(t, n, e, r); }); } return r = r ? r.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(e, r, n) { var o = h; return function (i, a) { if (o === f) throw Error("Generator is already running"); if (o === s) { if ("throw" === i) throw a; return { value: t, done: !0 }; } for (n.method = i, n.arg = a;;) { var c = n.delegate; if (c) { var u = maybeInvokeDelegate(c, n); if (u) { if (u === y) continue; return u; } } if ("next" === n.method) n.sent = n._sent = n.arg;else if ("throw" === n.method) { if (o === h) throw o = s, n.arg; n.dispatchException(n.arg); } else "return" === n.method && n.abrupt("return", n.arg); o = f; var p = tryCatch(e, r, n); if ("normal" === p.type) { if (o = n.done ? s : l, p.arg === y) continue; return { value: p.arg, done: n.done }; } "throw" === p.type && (o = s, n.method = "throw", n.arg = p.arg); } }; } function maybeInvokeDelegate(e, r) { var n = r.method, o = e.iterator[n]; if (o === t) return r.delegate = null, "throw" === n && e.iterator.return && (r.method = "return", r.arg = t, maybeInvokeDelegate(e, r), "throw" === r.method) || "return" !== n && (r.method = "throw", r.arg = new TypeError("The iterator does not provide a '" + n + "' method")), y; var i = tryCatch(o, e.iterator, r.arg); if ("throw" === i.type) return r.method = "throw", r.arg = i.arg, r.delegate = null, y; var a = i.arg; return a ? a.done ? (r[e.resultName] = a.value, r.next = e.nextLoc, "return" !== r.method && (r.method = "next", r.arg = t), r.delegate = null, y) : a : (r.method = "throw", r.arg = new TypeError("iterator result is not an object"), r.delegate = null, y); } function pushTryEntry(t) { var e = { tryLoc: t[0] }; 1 in t && (e.catchLoc = t[1]), 2 in t && (e.finallyLoc = t[2], e.afterLoc = t[3]), this.tryEntries.push(e); } function resetTryEntry(t) { var e = t.completion || {}; e.type = "normal", delete e.arg, t.completion = e; } function Context(t) { this.tryEntries = [{ tryLoc: "root" }], t.forEach(pushTryEntry, this), this.reset(!0); } function values(e) { if (e || "" === e) { var r = e[a]; if (r) return r.call(e); if ("function" == typeof e.next) return e; if (!isNaN(e.length)) { var o = -1, i = function next() { for (; ++o < e.length;) if (n.call(e, o)) return next.value = e[o], next.done = !1, next; return next.value = t, next.done = !0, next; }; return i.next = i; } } throw new TypeError(_typeof(e) + " is not iterable"); } return GeneratorFunction.prototype = GeneratorFunctionPrototype, o(g, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), o(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, u, "GeneratorFunction"), e.isGeneratorFunction = function (t) { var e = "function" == typeof t && t.constructor; return !!e && (e === GeneratorFunction || "GeneratorFunction" === (e.displayName || e.name)); }, e.mark = function (t) { return Object.setPrototypeOf ? Object.setPrototypeOf(t, GeneratorFunctionPrototype) : (t.__proto__ = GeneratorFunctionPrototype, define(t, u, "GeneratorFunction")), t.prototype = Object.create(g), t; }, e.awrap = function (t) { return { __await: t }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, c, function () { return this; }), e.AsyncIterator = AsyncIterator, e.async = function (t, r, n, o, i) { void 0 === i && (i = Promise); var a = new AsyncIterator(wrap(t, r, n, o), i); return e.isGeneratorFunction(r) ? a : a.next().then(function (t) { return t.done ? t.value : a.next(); }); }, defineIteratorMethods(g), define(g, u, "Generator"), define(g, a, function () { return this; }), define(g, "toString", function () { return "[object Generator]"; }), e.keys = function (t) { var e = Object(t), r = []; for (var n in e) r.push(n); return r.reverse(), function next() { for (; r.length;) { var t = r.pop(); if (t in e) return next.value = t, next.done = !1, next; } return next.done = !0, next; }; }, e.values = values, Context.prototype = { constructor: Context, reset: function reset(e) { if (this.prev = 0, this.next = 0, this.sent = this._sent = t, this.done = !1, this.delegate = null, this.method = "next", this.arg = t, this.tryEntries.forEach(resetTryEntry), !e) for (var r in this) "t" === r.charAt(0) && n.call(this, r) && !isNaN(+r.slice(1)) && (this[r] = t); }, stop: function stop() { this.done = !0; var t = this.tryEntries[0].completion; if ("throw" === t.type) throw t.arg; return this.rval; }, dispatchException: function dispatchException(e) { if (this.done) throw e; var r = this; function handle(n, o) { return a.type = "throw", a.arg = e, r.next = n, o && (r.method = "next", r.arg = t), !!o; } for (var o = this.tryEntries.length - 1; o >= 0; --o) { var i = this.tryEntries[o], a = i.completion; if ("root" === i.tryLoc) return handle("end"); if (i.tryLoc <= this.prev) { var c = n.call(i, "catchLoc"), u = n.call(i, "finallyLoc"); if (c && u) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } else if (c) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); } else { if (!u) throw Error("try statement without catch or finally"); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } } } }, abrupt: function abrupt(t, e) { for (var r = this.tryEntries.length - 1; r >= 0; --r) { var o = this.tryEntries[r]; if (o.tryLoc <= this.prev && n.call(o, "finallyLoc") && this.prev < o.finallyLoc) { var i = o; break; } } i && ("break" === t || "continue" === t) && i.tryLoc <= e && e <= i.finallyLoc && (i = null); var a = i ? i.completion : {}; return a.type = t, a.arg = e, i ? (this.method = "next", this.next = i.finallyLoc, y) : this.complete(a); }, complete: function complete(t, e) { if ("throw" === t.type) throw t.arg; return "break" === t.type || "continue" === t.type ? this.next = t.arg : "return" === t.type ? (this.rval = this.arg = t.arg, this.method = "return", this.next = "end") : "normal" === t.type && e && (this.next = e), y; }, finish: function finish(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.finallyLoc === t) return this.complete(r.completion, r.afterLoc), resetTryEntry(r), y; } }, catch: function _catch(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.tryLoc === t) { var n = r.completion; if ("throw" === n.type) { var o = n.arg; resetTryEntry(r); } return o; } } throw Error("illegal catch attempt"); }, delegateYield: function delegateYield(e, r, n) { return this.delegate = { iterator: values(e), resultName: r, nextLoc: n }, "next" === this.method && (this.arg = t), y; } }, e; }
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }
var paymentContextId;
var orderID;
function fetchClientToken(_x) {
  return _fetchClientToken.apply(this, arguments);
}
function _fetchClientToken() {
  _fetchClientToken = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime().mark(function _callee(billingCountry) {
    var csrfToken, klarnaContextUrl;
    return _regeneratorRuntime().wrap(function _callee$(_context) {
      while (1) switch (_context.prev = _context.next) {
        case 0:
          csrfToken = $('input[name="csrf_token"]').val();
          klarnaContextUrl = $('.klarnaCreateContextUrl').val();
          if (klarnaContextUrl) {
            _context.next = 4;
            break;
          }
          return _context.abrupt("return");
        case 4:
          ;
          return _context.abrupt("return", new Promise(function (resolve, reject) {
            var formData = $('#klarna-content .payment-form-fields').serialize();
            var dataToSend = formData;
            if (billingCountry) {
              dataToSend = formData + '&billingCountry=' + encodeURIComponent(billingCountry);
            }
            $.ajax({
              url: klarnaContextUrl,
              method: 'POST',
              dataType: 'json',
              data: dataToSend + '&csrf_token=' + csrfToken,
              success: function success(response) {
                return resolve(response);
              },
              error: function error(response) {
                if (response && response.responseJSON) {
                  $('#klarna-payments-container').html('<div class="klarna-not-available"><p style="font-size: 24px"><strong>' + response.responseJSON.errorTitle + '</strong></p><p>' + response.responseJSON.message + '</p></div>');
                  $('.klarna-tab').addClass('disable-klarna-checkout');
                  if ($('.klarna-tab').hasClass('active')) {
                    $('button.submit-payment').prop('disabled', true).addClass('disabled');
                  }
                }
                return reject(response);
              }
            });
          }));
        case 6:
        case "end":
          return _context.stop();
      }
    }, _callee);
  }));
  return _fetchClientToken.apply(this, arguments);
}
function initializeKlarna(_x2) {
  return _initializeKlarna.apply(this, arguments);
}
function _initializeKlarna() {
  _initializeKlarna = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime().mark(function _callee2(billingCountry) {
    var response, clientToken, $klarnaDataInput;
    return _regeneratorRuntime().wrap(function _callee2$(_context2) {
      while (1) switch (_context2.prev = _context2.next) {
        case 0:
          _context2.prev = 0;
          _context2.next = 3;
          return fetchClientToken(billingCountry);
        case 3:
          response = _context2.sent;
          if (!(!response || !response.id)) {
            _context2.next = 6;
            break;
          }
          return _context2.abrupt("return");
        case 6:
          $('#klarna-payments-container').html('');
          $('button.submit-payment').prop('disabled', false).removeClass('disabled');
          $('.klarna-tab').removeClass('disable-klarna-checkout');
          paymentContextId = response && response.id ? response.id : '';
          clientToken = response && response.partner_metadata ? response.partner_metadata.client_token : '';
          $klarnaDataInput = $('input[name="dwfrm_billing_klarnaForm_ckoKlarnaData"]');
          $klarnaDataInput.val(JSON.stringify({
            paymentContext_id: paymentContextId
          }));
          Klarna.Payments.init({
            client_token: clientToken
          });
          Klarna.Payments.load({
            container: '#klarna-payments-container'
          }, {}, function (res) {
            console.debug(res);
          });
          _context2.next = 20;
          break;
        case 17:
          _context2.prev = 17;
          _context2.t0 = _context2["catch"](0);
          console.error('Error occurred while initializing or loading Klarna:', _context2.t0);
        case 20:
        case "end":
          return _context2.stop();
      }
    }, _callee2, null, [[0, 17]]);
  }));
  return _initializeKlarna.apply(this, arguments);
}
function onPaymentContextApproved(_x3) {
  return _onPaymentContextApproved.apply(this, arguments);
}
function _onPaymentContextApproved() {
  _onPaymentContextApproved = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime().mark(function _callee3(res) {
    var csrfToken, klarnaOnApproveUrl;
    return _regeneratorRuntime().wrap(function _callee3$(_context3) {
      while (1) switch (_context3.prev = _context3.next) {
        case 0:
          csrfToken = $('input[name="csrf_token"]').val();
          klarnaOnApproveUrl = $('.klarnaonApproveUrl').val();
          if (klarnaOnApproveUrl) {
            _context3.next = 5;
            break;
          }
          console.log('klarna callback url is not available');
          return _context3.abrupt("return");
        case 5:
          ;
          $.spinner().start();
          $.ajax({
            url: klarnaOnApproveUrl,
            method: 'POST',
            dataType: 'json',
            data: {
              paymentContextId: paymentContextId,
              orderID: orderID,
              csrf_token: csrfToken
            },
            success: function success(response) {
              if (response.error) {
                if (response.cartError) {
                  window.location.href = response.redirectUrl;
                } else {
                  var currentURL = location.href;
                  var hasError = new URL(currentURL).searchParams.has('hasError');
                  if (hasError) {
                    location.href = currentURL;
                  } else {
                    location.href = currentURL + '&hasError=true';
                  }
                }
                if (response.errorMessage) {
                  $('.error-message').show();
                  $('.error-message-text').text(response.errorMessage);
                }
              } else {
                var redirect = $('<form>').appendTo(document.body).attr({
                  method: 'POST',
                  action: response.continueUrl
                });
                $('<input>').appendTo(redirect).attr({
                  name: 'orderID',
                  value: response.orderID
                });
                $('<input>').appendTo(redirect).attr({
                  name: 'orderToken',
                  value: response.orderToken
                });
                redirect.submit();
              }
              $.spinner().stop();
            },
            error: function error(e) {
              $.spinner().stop();
            }
          });
        case 8:
        case "end":
          return _context3.stop();
      }
    }, _callee3);
  }));
  return _onPaymentContextApproved.apply(this, arguments);
}
function authorizeKlarna(order) {
  orderID = order.orderNo;
  var billingAddress = order.billingAddress;
  var shippingAddress = order.shippingAddress;
  Klarna.Payments.authorize({}, {
    billing_address: {
      given_name: billingAddress.firstName,
      family_name: billingAddress.lastName,
      email: order.customerEmail,
      street_address: billingAddress.address1,
      postal_code: billingAddress.postalCode,
      city: billingAddress.city,
      phone: billingAddress.phone,
      country: billingAddress.countryCode
    },
    purchase_amount: order.totalGrossPrice * 100,
    shipping_address: {
      given_name: shippingAddress.firstName,
      family_name: shippingAddress.lastName,
      email: order.customerEmail,
      street_address: shippingAddress.address1,
      postal_code: shippingAddress.postalCode,
      city: shippingAddress.city,
      phone: shippingAddress.phone,
      country: shippingAddress.countryCode
    }
  }, function (res) {
    onPaymentContextApproved(res);
  });
}
$(document).ready(function () {
  var checkoutStage = $('.data-checkout-stage').data('checkout-stage');
  if (checkoutStage === 'payment' || checkoutStage === 'placeOrder') {
    initializeKlarna();
  }
});
module.exports = {
  initializeKlarna: initializeKlarna,
  authorizeKlarna: authorizeKlarna
};

/***/ }),
/* 16 */
/***/ (function(module) {



/**
 * updates the totals summary
 * @param {Array} totals - the totals data
 */
function updateTotals(totals) {
  $('.shipping-total-cost').text(totals.totalShippingCost);
  $('.tax-total').text(totals.totalTax);
  $('.sub-total').text(totals.subTotal);
  $('.grand-total-sum').text(totals.grandTotal);
  if (totals.orderLevelDiscountTotal.value > 0) {
    $('.order-discount').removeClass('hide-order-discount');
    $('.order-discount-total').text('- ' + totals.orderLevelDiscountTotal.formatted);
  } else {
    $('.order-discount').addClass('hide-order-discount');
  }
  if (totals.shippingLevelDiscountTotal.value > 0) {
    $('.shipping-discount').removeClass('hide-shipping-discount');
    $('.shipping-discount-total').text('- ' + totals.shippingLevelDiscountTotal.formatted);
  } else {
    $('.shipping-discount').addClass('hide-shipping-discount');
  }
}

/**
 * updates the order product shipping summary for an order model
 * @param {Object} order - the order model
 */
function updateOrderProductSummaryInformation(order) {
  var $productSummary = $('<div />');
  order.shipping.forEach(function (shipping) {
    shipping.productLineItems.items.forEach(function (lineItem) {
      var pli = $('[data-product-line-item=' + lineItem.UUID + ']');
      $productSummary.append(pli);
    });
    var address = shipping.shippingAddress || {};
    var selectedMethod = shipping.selectedShippingMethod;
    var nameLine = address.firstName ? address.firstName + ' ' : '';
    if (address.lastName) nameLine += address.lastName;
    var address1Line = address.address1;
    var address2Line = address.address2;
    var phoneLine = address.phone;
    var shippingCost = selectedMethod ? selectedMethod.shippingCost : '';
    var methodNameLine = selectedMethod ? selectedMethod.displayName : '';
    var methodArrivalTime = selectedMethod && selectedMethod.estimatedArrivalTime ? '( ' + selectedMethod.estimatedArrivalTime + ' )' : '';
    var tmpl = $('#pli-shipping-summary-template').clone();
    if (shipping.productLineItems.items && shipping.productLineItems.items.length > 1) {
      $('h5 > span').text(' - ' + shipping.productLineItems.items.length + ' ' + order.resources.items);
    } else {
      $('h5 > span').text('');
    }
    var stateRequiredAttr = $('#shippingState').attr('required');
    var isRequired = stateRequiredAttr !== undefined && stateRequiredAttr !== false;
    var stateExists = shipping.shippingAddress && shipping.shippingAddress.stateCode ? shipping.shippingAddress.stateCode : false;
    var stateBoolean = false;
    if (isRequired && stateExists || !isRequired) {
      stateBoolean = true;
    }
    var shippingForm = $('.multi-shipping input[name="shipmentUUID"][value="' + shipping.UUID + '"]').parent();
    if (shipping.shippingAddress && shipping.shippingAddress.firstName && shipping.shippingAddress.address1 && shipping.shippingAddress.city && stateBoolean && shipping.shippingAddress.countryCode && (shipping.shippingAddress.phone || shipping.productLineItems.items[0].fromStoreId)) {
      $('.ship-to-name', tmpl).text(nameLine);
      $('.ship-to-address1', tmpl).text(address1Line);
      $('.ship-to-address2', tmpl).text(address2Line);
      $('.ship-to-city', tmpl).text(address.city);
      if (address.stateCode) {
        $('.ship-to-st', tmpl).text(address.stateCode);
      }
      $('.ship-to-zip', tmpl).text(address.postalCode);
      $('.ship-to-phone', tmpl).text(phoneLine);
      if (!address2Line) {
        $('.ship-to-address2', tmpl).hide();
      }
      if (!phoneLine) {
        $('.ship-to-phone', tmpl).hide();
      }
      shippingForm.find('.ship-to-message').text('');
    } else {
      shippingForm.find('.ship-to-message').text(order.resources.addressIncomplete);
    }
    if (shipping.isGift) {
      $('.gift-message-summary', tmpl).text(shipping.giftMessage);
    } else {
      $('.gift-summary', tmpl).addClass('d-none');
    }

    // checking h5 title shipping to or pickup
    var $shippingAddressLabel = $('.shipping-header-text', tmpl);
    $('body').trigger('shipping:updateAddressLabelText', {
      selectedShippingMethod: selectedMethod,
      resources: order.resources,
      shippingAddressLabel: $shippingAddressLabel
    });
    if (shipping.selectedShippingMethod) {
      $('.display-name', tmpl).text(methodNameLine);
      $('.arrival-time', tmpl).text(methodArrivalTime);
      $('.price', tmpl).text(shippingCost);
    }
    var $shippingSummary = $('<div class="multi-shipping" data-shipment-summary="' + shipping.UUID + '" />');
    $shippingSummary.html(tmpl.html());
    $productSummary.append($shippingSummary);
  });
  $('.product-summary-block').html($productSummary.html());

  // Also update the line item prices, as they might have been altered
  $('.grand-total-price').text(order.totals.subTotal);
  order.items.items.forEach(function (item) {
    if (item.priceTotal && item.priceTotal.renderedPrice) {
      $('.item-total-' + item.UUID).empty().append(item.priceTotal.renderedPrice);
    }
  });
}
module.exports = {
  updateTotals: updateTotals,
  updateOrderProductSummaryInformation: updateOrderProductSummaryInformation
};

/***/ }),
/* 17 */
/***/ (function(module) {



function createTabbyContext() {
  var tabbyContextUrl = $('.tabbyCreateContextUrl').val();
  if (!tabbyContextUrl) {
    return;
  }
  var csrfToken = $('#tabby-content input[name="csrf_token"]').val();
  $.ajax({
    url: tabbyContextUrl,
    method: 'POST',
    dataType: 'json',
    data: {
      csrf_token: csrfToken
    },
    success: function success(response) {
      if (response && response.success) {
        $('button.submit-payment').prop('disabled', false).removeClass('disabled');
        $('.tabby-content .invalid-field-message').text('').hide();
        $('.tabby-tab').removeClass('disable-tabby-checkout');
      } else {
        showTabbyError(response && response.message);
      }
    },
    error: function error(xhr) {
      var msg = xhr.responseJSON && xhr.responseJSON.message ? xhr.responseJSON.message : '';
      showTabbyError(msg);
    }
  });
}
function showTabbyError(message) {
  $('.tabby-content .invalid-field-message').text(message || '').show();
  $('.tabby-tab').addClass('disable-tabby-checkout');
  if ($('.tabby-tab').hasClass('active')) {
    $('button.submit-payment').prop('disabled', true).addClass('disabled');
  }
}
$(document).on('click touch', '.payment-options a.nav-link', function () {
  if ($(this).hasClass('tabby-tab') && $(this).hasClass('disable-tabby-checkout')) {
    $('button.submit-payment').prop('disabled', true).addClass('disabled');
  } else if (!$(this).hasClass('tabby-tab') && $('.tabby-content').length) {
    $('button.submit-payment').prop('disabled', false).removeClass('disabled');
  }
});
$(document).ready(function () {
  var checkoutStage = $('.data-checkout-stage').data('checkout-stage');
  var isTabbyEnabled = $('.tabby-tab').length > 0;
  if ((checkoutStage === 'payment' || checkoutStage === 'placeOrder') && isTabbyEnabled) {
    createTabbyContext();
  }
});
$('body').on('checkout:updateCheckoutView', function () {
  if ($('.tabby-tab').length > 0) {
    $('.tabby-tab').removeClass('disable-tabby-checkout');
    $('.tabby-content .invalid-field-message').text('').hide();
    createTabbyContext();
  }
});
module.exports = {
  createTabbyContext: createTabbyContext
};

/***/ }),
/* 18 */
/***/ (function(module) {



var errorMsgContainer = $('.error-message .error-message-text');
var defaultStyle = {
  color: 'gold',
  shape: 'rect',
  layout: 'vertical',
  label: 'paypal',
  tagline: false
};

/**
 *  Gets paypal button styles
 * @param {Element} button - button element
 * @returns {Object} with button styles or if error appears with default styles
 */
function getPaypalButtonStyle(button) {
  try {
    var config = button.getAttribute('data-paypal-button-config');
    if (config) {
      var buttonConfig = JSON.parse(config).billing;
      return buttonConfig;
    }
  } catch (error) {
    return {
      style: defaultStyle
    };
  }
}

/**
 * removes any error messages displayed in the billing page
 */
function removeErrorMessages() {
  errorMsgContainer.empty();
  $('.error-message').css('display', 'none');
}

/**
 * Displays error messages
 * @param {Object} response - Response object containing error message
 */
function displayErrorMessages(response) {
  errorMsgContainer.empty();
  errorMsgContainer.text(response.message);
  errorMsgContainer.css('display', 'block');
  $('.error-message').css('display', 'block');
  hidePayPalOverlay();
}

/**
 * To close payPal overlay
 */
function hidePayPalOverlay() {
  $('[id^="paypal-overlay-uid_"]').css('display', 'none');
}

/**
 * Retrieves PayPal order ID
 * @returns {Promise} A promise that resolves with the PayPal order ID
 */
var createPayPalOrder = function createPayPalOrder() {
  return new Promise(function (resolve, reject) {
    $.ajax({
      url: $('#payPalCreateOrderUrl').val(),
      type: 'POST',
      success: function success(response) {
        if (response.success) {
          removeErrorMessages();
          var contextIdInput = $('input[name="dwfrm_billing_payPalForm_ckoPayPalPaymentContextId"]');
          contextIdInput.val(response.id);
          return resolve(response.partner_metadata.order_id);
        }
        if (response.error) {
          if (response.status || response.message) {
            displayErrorMessages(response);
          } else {
            hidePayPalOverlay();
          }
        }
        return reject(response);
      },
      error: function error(_error) {
        reject(_error);
        var errorMsg = _error && _error.responseJSON ? _error.responseJSON : '';
        if (errorMsg) {
          displayErrorMessages(errorMsg);
        } else {
          hidePayPalOverlay();
        }
      }
    });
  });
};
var onApprove = function onApprove() {
  var paypalContextId = $('#ckoPayPalPaymentContextId').val();
  return new Promise(function (resolve, reject) {
    $.ajax({
      type: 'GET',
      url: $('#payPalonApproveUrl').val(),
      dataType: 'text',
      data: {
        id: paypalContextId
      },
      success: function success(response) {
        var responseData = JSON.parse(response);
        if (responseData && responseData.success) {
          resolve(responseData);
          removeErrorMessages();
          responseData.response.paymentContext_id = paypalContextId;
          var ckoPayPalData = JSON.stringify(responseData.response);
          var $payPalDataInput = $('input[name="dwfrm_billing_payPalForm_ckoPayPalData"]');
          var $invalidFieldMessage = $('#paypal-content .invalid-field-message');
          $payPalDataInput.val(ckoPayPalData);
          if ($payPalDataInput.val() === '') {
            $invalidFieldMessage.text(window.ckoLang.payPalDataInvalid);
          }
          // trigger submit payment
          $('button.submit-payment').trigger('click');
        } else {
          displayErrorMessages(responseData);
        }
      },
      error: function error(_error2) {
        reject(_error2);
        var errorMsg = _error2 && _error2.responseJSON ? _error2.responseJSON : '';
        if (errorMsg) {
          displayErrorMessages(errorMsg);
        } else {
          hidePayPalOverlay();
        }
      }
    });
  });
};
var initPayPalButton = function initPayPalButton() {
  paypal_sdk.Buttons({
    createOrder: createPayPalOrder,
    onApprove: onApprove,
    style: getPaypalButtonStyle(document.querySelector('.js_paypal_button_on_billing_form'))
  }).render('#paypal-button-container');
};
module.exports = {
  initPayPalButton: initPayPalButton,
  createPayPalOrder: createPayPalOrder
};

/***/ })
/******/ 	]);
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/global */
/******/ 	!function() {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	!function() {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = function(exports) {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	}();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = __webpack_require__(4);
/******/ 	
/******/ })()
;