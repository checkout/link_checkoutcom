/******/ (function() { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 15:
/***/ (function(module) {



function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return e; }; var t, e = {}, r = Object.prototype, n = r.hasOwnProperty, o = Object.defineProperty || function (t, e, r) { t[e] = r.value; }, i = "function" == typeof Symbol ? Symbol : {}, a = i.iterator || "@@iterator", c = i.asyncIterator || "@@asyncIterator", u = i.toStringTag || "@@toStringTag"; function define(t, e, r) { return Object.defineProperty(t, e, { value: r, enumerable: !0, configurable: !0, writable: !0 }), t[e]; } try { define({}, ""); } catch (t) { define = function define(t, e, r) { return t[e] = r; }; } function wrap(t, e, r, n) { var i = e && e.prototype instanceof Generator ? e : Generator, a = Object.create(i.prototype), c = new Context(n || []); return o(a, "_invoke", { value: makeInvokeMethod(t, r, c) }), a; } function tryCatch(t, e, r) { try { return { type: "normal", arg: t.call(e, r) }; } catch (t) { return { type: "throw", arg: t }; } } e.wrap = wrap; var h = "suspendedStart", l = "suspendedYield", f = "executing", s = "completed", y = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var p = {}; define(p, a, function () { return this; }); var d = Object.getPrototypeOf, v = d && d(d(values([]))); v && v !== r && n.call(v, a) && (p = v); var g = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(p); function defineIteratorMethods(t) { ["next", "throw", "return"].forEach(function (e) { define(t, e, function (t) { return this._invoke(e, t); }); }); } function AsyncIterator(t, e) { function invoke(r, o, i, a) { var c = tryCatch(t[r], t, o); if ("throw" !== c.type) { var u = c.arg, h = u.value; return h && "object" == _typeof(h) && n.call(h, "__await") ? e.resolve(h.__await).then(function (t) { invoke("next", t, i, a); }, function (t) { invoke("throw", t, i, a); }) : e.resolve(h).then(function (t) { u.value = t, i(u); }, function (t) { return invoke("throw", t, i, a); }); } a(c.arg); } var r; o(this, "_invoke", { value: function value(t, n) { function callInvokeWithMethodAndArg() { return new e(function (e, r) { invoke(t, n, e, r); }); } return r = r ? r.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(e, r, n) { var o = h; return function (i, a) { if (o === f) throw Error("Generator is already running"); if (o === s) { if ("throw" === i) throw a; return { value: t, done: !0 }; } for (n.method = i, n.arg = a;;) { var c = n.delegate; if (c) { var u = maybeInvokeDelegate(c, n); if (u) { if (u === y) continue; return u; } } if ("next" === n.method) n.sent = n._sent = n.arg;else if ("throw" === n.method) { if (o === h) throw o = s, n.arg; n.dispatchException(n.arg); } else "return" === n.method && n.abrupt("return", n.arg); o = f; var p = tryCatch(e, r, n); if ("normal" === p.type) { if (o = n.done ? s : l, p.arg === y) continue; return { value: p.arg, done: n.done }; } "throw" === p.type && (o = s, n.method = "throw", n.arg = p.arg); } }; } function maybeInvokeDelegate(e, r) { var n = r.method, o = e.iterator[n]; if (o === t) return r.delegate = null, "throw" === n && e.iterator.return && (r.method = "return", r.arg = t, maybeInvokeDelegate(e, r), "throw" === r.method) || "return" !== n && (r.method = "throw", r.arg = new TypeError("The iterator does not provide a '" + n + "' method")), y; var i = tryCatch(o, e.iterator, r.arg); if ("throw" === i.type) return r.method = "throw", r.arg = i.arg, r.delegate = null, y; var a = i.arg; return a ? a.done ? (r[e.resultName] = a.value, r.next = e.nextLoc, "return" !== r.method && (r.method = "next", r.arg = t), r.delegate = null, y) : a : (r.method = "throw", r.arg = new TypeError("iterator result is not an object"), r.delegate = null, y); } function pushTryEntry(t) { var e = { tryLoc: t[0] }; 1 in t && (e.catchLoc = t[1]), 2 in t && (e.finallyLoc = t[2], e.afterLoc = t[3]), this.tryEntries.push(e); } function resetTryEntry(t) { var e = t.completion || {}; e.type = "normal", delete e.arg, t.completion = e; } function Context(t) { this.tryEntries = [{ tryLoc: "root" }], t.forEach(pushTryEntry, this), this.reset(!0); } function values(e) { if (e || "" === e) { var r = e[a]; if (r) return r.call(e); if ("function" == typeof e.next) return e; if (!isNaN(e.length)) { var o = -1, i = function next() { for (; ++o < e.length;) if (n.call(e, o)) return next.value = e[o], next.done = !1, next; return next.value = t, next.done = !0, next; }; return i.next = i; } } throw new TypeError(_typeof(e) + " is not iterable"); } return GeneratorFunction.prototype = GeneratorFunctionPrototype, o(g, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), o(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, u, "GeneratorFunction"), e.isGeneratorFunction = function (t) { var e = "function" == typeof t && t.constructor; return !!e && (e === GeneratorFunction || "GeneratorFunction" === (e.displayName || e.name)); }, e.mark = function (t) { return Object.setPrototypeOf ? Object.setPrototypeOf(t, GeneratorFunctionPrototype) : (t.__proto__ = GeneratorFunctionPrototype, define(t, u, "GeneratorFunction")), t.prototype = Object.create(g), t; }, e.awrap = function (t) { return { __await: t }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, c, function () { return this; }), e.AsyncIterator = AsyncIterator, e.async = function (t, r, n, o, i) { void 0 === i && (i = Promise); var a = new AsyncIterator(wrap(t, r, n, o), i); return e.isGeneratorFunction(r) ? a : a.next().then(function (t) { return t.done ? t.value : a.next(); }); }, defineIteratorMethods(g), define(g, u, "Generator"), define(g, a, function () { return this; }), define(g, "toString", function () { return "[object Generator]"; }), e.keys = function (t) { var e = Object(t), r = []; for (var n in e) r.push(n); return r.reverse(), function next() { for (; r.length;) { var t = r.pop(); if (t in e) return next.value = t, next.done = !1, next; } return next.done = !0, next; }; }, e.values = values, Context.prototype = { constructor: Context, reset: function reset(e) { if (this.prev = 0, this.next = 0, this.sent = this._sent = t, this.done = !1, this.delegate = null, this.method = "next", this.arg = t, this.tryEntries.forEach(resetTryEntry), !e) for (var r in this) "t" === r.charAt(0) && n.call(this, r) && !isNaN(+r.slice(1)) && (this[r] = t); }, stop: function stop() { this.done = !0; var t = this.tryEntries[0].completion; if ("throw" === t.type) throw t.arg; return this.rval; }, dispatchException: function dispatchException(e) { if (this.done) throw e; var r = this; function handle(n, o) { return a.type = "throw", a.arg = e, r.next = n, o && (r.method = "next", r.arg = t), !!o; } for (var o = this.tryEntries.length - 1; o >= 0; --o) { var i = this.tryEntries[o], a = i.completion; if ("root" === i.tryLoc) return handle("end"); if (i.tryLoc <= this.prev) { var c = n.call(i, "catchLoc"), u = n.call(i, "finallyLoc"); if (c && u) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } else if (c) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); } else { if (!u) throw Error("try statement without catch or finally"); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } } } }, abrupt: function abrupt(t, e) { for (var r = this.tryEntries.length - 1; r >= 0; --r) { var o = this.tryEntries[r]; if (o.tryLoc <= this.prev && n.call(o, "finallyLoc") && this.prev < o.finallyLoc) { var i = o; break; } } i && ("break" === t || "continue" === t) && i.tryLoc <= e && e <= i.finallyLoc && (i = null); var a = i ? i.completion : {}; return a.type = t, a.arg = e, i ? (this.method = "next", this.next = i.finallyLoc, y) : this.complete(a); }, complete: function complete(t, e) { if ("throw" === t.type) throw t.arg; return "break" === t.type || "continue" === t.type ? this.next = t.arg : "return" === t.type ? (this.rval = this.arg = t.arg, this.method = "return", this.next = "end") : "normal" === t.type && e && (this.next = e), y; }, finish: function finish(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.finallyLoc === t) return this.complete(r.completion, r.afterLoc), resetTryEntry(r), y; } }, catch: function _catch(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.tryLoc === t) { var n = r.completion; if ("throw" === n.type) { var o = n.arg; resetTryEntry(r); } return o; } } throw Error("illegal catch attempt"); }, delegateYield: function delegateYield(e, r, n) { return this.delegate = { iterator: values(e), resultName: r, nextLoc: n }, "next" === this.method && (this.arg = t), y; } }, e; }
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }
var paymentContextId;
var orderID;
function fetchClientToken(_x) {
  return _fetchClientToken.apply(this, arguments);
}
function _fetchClientToken() {
  _fetchClientToken = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime().mark(function _callee(billingCountry) {
    var csrfToken, klarnaContextUrl;
    return _regeneratorRuntime().wrap(function _callee$(_context) {
      while (1) switch (_context.prev = _context.next) {
        case 0:
          csrfToken = $('input[name="csrf_token"]').val();
          klarnaContextUrl = $('.klarnaCreateContextUrl').val();
          if (klarnaContextUrl) {
            _context.next = 4;
            break;
          }
          return _context.abrupt("return");
        case 4:
          ;
          return _context.abrupt("return", new Promise(function (resolve, reject) {
            var formData = $('#klarna-content .payment-form-fields').serialize();
            var dataToSend = formData;
            if (billingCountry) {
              dataToSend = formData + '&billingCountry=' + encodeURIComponent(billingCountry);
            }
            $.ajax({
              url: klarnaContextUrl,
              method: 'POST',
              dataType: 'json',
              data: dataToSend + '&csrf_token=' + csrfToken,
              success: function success(response) {
                return resolve(response);
              },
              error: function error(response) {
                if (response && response.responseJSON) {
                  $('#klarna-payments-container').html('<div class="klarna-not-available"><p style="font-size: 24px"><strong>' + response.responseJSON.errorTitle + '</strong></p><p>' + response.responseJSON.message + '</p></div>');
                  $('.klarna-tab').addClass('disable-klarna-checkout');
                  if ($('.klarna-tab').hasClass('active')) {
                    $('button.submit-payment').prop('disabled', true).addClass('disabled');
                  }
                }
                return reject(response);
              }
            });
          }));
        case 6:
        case "end":
          return _context.stop();
      }
    }, _callee);
  }));
  return _fetchClientToken.apply(this, arguments);
}
function initializeKlarna(_x2) {
  return _initializeKlarna.apply(this, arguments);
}
function _initializeKlarna() {
  _initializeKlarna = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime().mark(function _callee2(billingCountry) {
    var response, clientToken, $klarnaDataInput;
    return _regeneratorRuntime().wrap(function _callee2$(_context2) {
      while (1) switch (_context2.prev = _context2.next) {
        case 0:
          _context2.prev = 0;
          _context2.next = 3;
          return fetchClientToken(billingCountry);
        case 3:
          response = _context2.sent;
          if (!(!response || !response.id)) {
            _context2.next = 6;
            break;
          }
          return _context2.abrupt("return");
        case 6:
          $('#klarna-payments-container').html('');
          $('button.submit-payment').prop('disabled', false).removeClass('disabled');
          $('.klarna-tab').removeClass('disable-klarna-checkout');
          paymentContextId = response && response.id ? response.id : '';
          clientToken = response && response.partner_metadata ? response.partner_metadata.client_token : '';
          $klarnaDataInput = $('input[name="dwfrm_billing_klarnaForm_ckoKlarnaData"]');
          $klarnaDataInput.val(JSON.stringify({
            paymentContext_id: paymentContextId
          }));
          Klarna.Payments.init({
            client_token: clientToken
          });
          Klarna.Payments.load({
            container: '#klarna-payments-container'
          }, {}, function (res) {
            console.debug(res);
          });
          _context2.next = 20;
          break;
        case 17:
          _context2.prev = 17;
          _context2.t0 = _context2["catch"](0);
          console.error('Error occurred while initializing or loading Klarna:', _context2.t0);
        case 20:
        case "end":
          return _context2.stop();
      }
    }, _callee2, null, [[0, 17]]);
  }));
  return _initializeKlarna.apply(this, arguments);
}
function onPaymentContextApproved(_x3) {
  return _onPaymentContextApproved.apply(this, arguments);
}
function _onPaymentContextApproved() {
  _onPaymentContextApproved = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime().mark(function _callee3(res) {
    var csrfToken, klarnaOnApproveUrl;
    return _regeneratorRuntime().wrap(function _callee3$(_context3) {
      while (1) switch (_context3.prev = _context3.next) {
        case 0:
          csrfToken = $('input[name="csrf_token"]').val();
          klarnaOnApproveUrl = $('.klarnaonApproveUrl').val();
          if (klarnaOnApproveUrl) {
            _context3.next = 5;
            break;
          }
          console.log('klarna callback url is not available');
          return _context3.abrupt("return");
        case 5:
          ;
          $.spinner().start();
          $.ajax({
            url: klarnaOnApproveUrl,
            method: 'POST',
            dataType: 'json',
            data: {
              paymentContextId: paymentContextId,
              orderID: orderID,
              csrf_token: csrfToken
            },
            success: function success(response) {
              if (response.error) {
                if (response.cartError) {
                  window.location.href = response.redirectUrl;
                } else {
                  var currentURL = location.href;
                  var hasError = new URL(currentURL).searchParams.has('hasError');
                  if (hasError) {
                    location.href = currentURL;
                  } else {
                    location.href = currentURL + '&hasError=true';
                  }
                }
                if (response.errorMessage) {
                  $('.error-message').show();
                  $('.error-message-text').text(response.errorMessage);
                }
              } else {
                var redirect = $('<form>').appendTo(document.body).attr({
                  method: 'POST',
                  action: response.continueUrl
                });
                $('<input>').appendTo(redirect).attr({
                  name: 'orderID',
                  value: response.orderID
                });
                $('<input>').appendTo(redirect).attr({
                  name: 'orderToken',
                  value: response.orderToken
                });
                redirect.submit();
              }
              $.spinner().stop();
            },
            error: function error(e) {
              $.spinner().stop();
            }
          });
        case 8:
        case "end":
          return _context3.stop();
      }
    }, _callee3);
  }));
  return _onPaymentContextApproved.apply(this, arguments);
}
function authorizeKlarna(order) {
  orderID = order.orderNo;
  var billingAddress = order.billingAddress;
  var shippingAddress = order.shippingAddress;
  Klarna.Payments.authorize({}, {
    billing_address: {
      given_name: billingAddress.firstName,
      family_name: billingAddress.lastName,
      email: order.customerEmail,
      street_address: billingAddress.address1,
      postal_code: billingAddress.postalCode,
      city: billingAddress.city,
      phone: billingAddress.phone,
      country: billingAddress.countryCode
    },
    purchase_amount: order.totalGrossPrice * 100,
    shipping_address: {
      given_name: shippingAddress.firstName,
      family_name: shippingAddress.lastName,
      email: order.customerEmail,
      street_address: shippingAddress.address1,
      postal_code: shippingAddress.postalCode,
      city: shippingAddress.city,
      phone: shippingAddress.phone,
      country: shippingAddress.countryCode
    }
  }, function (res) {
    onPaymentContextApproved(res);
  });
}
$(document).ready(function () {
  var checkoutStage = $('.data-checkout-stage').data('checkout-stage');
  if (checkoutStage === 'payment' || checkoutStage === 'placeOrder') {
    initializeKlarna();
  }
});
module.exports = {
  initializeKlarna: initializeKlarna,
  authorizeKlarna: authorizeKlarna
};

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = __webpack_require__(15);
/******/ 	
/******/ })()
;